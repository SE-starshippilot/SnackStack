import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/InventoryManagement.tsx");import { jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/s_mar/cs32/SnackStack/client/src/pages/InventoryManagement.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import { Box, Button, TextField } from "/node_modules/.vite/deps/@mui_material.js?v=b14ee716";
import __vite__cjsImport4_react from "/node_modules/.vite/deps/react.js?v=b14ee716"; const useState = __vite__cjsImport4_react["useState"];
import { useNavigate } from "/node_modules/.vite/deps/react-router-dom.js?v=b14ee716";
import "/src/styles/InventoryManagement.css";
function InventoryManagement() {
  _s();
  const [inputValue, setInputValue] = useState("");
  const [ingredients, setIngredients] = useState(/* @__PURE__ */ new Set());
  const [clickedItems, setClickedItems] = useState([]);
  const navigate = useNavigate();
  const handleInputChange = (e) => {
    setInputValue(e.target.value);
  };
  const handleConfirmClick = () => {
    const lowerCaseItem = inputValue.toLowerCase();
    if (inputValue.trim() !== "" && ![...ingredients].some((ingredient) => ingredient.toLowerCase() === lowerCaseItem)) {
      setIngredients((prev) => new Set(prev.add(inputValue)));
      setInputValue("");
    }
  };
  const handleItemClick = (item) => {
    if (clickedItems.includes(item)) {
      setClickedItems((prevItems) => prevItems.filter((otherItem) => otherItem !== item));
    } else {
      setClickedItems((prev) => [...prev, item]);
    }
  };
  const handleDeleteItems = () => {
    setIngredients((prev) => new Set([...prev].filter((item) => !clickedItems.includes(item))));
    setClickedItems([]);
  };
  const handleDoneClick = () => {
    navigate("/");
  };
  return /* @__PURE__ */ jsxDEV("div", { children: [
    /* @__PURE__ */ jsxDEV("h1", { className: "title", children: "Inventory Management" }, void 0, false, {
      fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/pages/InventoryManagement.tsx",
      lineNumber: 37,
      columnNumber: 13
    }, this),
    /* @__PURE__ */ jsxDEV(Box, { sx: {
      margin: 2,
      display: "flex",
      justifyContent: "center"
    }, children: [
      /* @__PURE__ */ jsxDEV(TextField, { "aria-label": "add-ingredient", label: "add ingredient", variant: "outlined", value: inputValue, onChange: handleInputChange, sx: {
        marginRight: 2
      } }, void 0, false, {
        fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/pages/InventoryManagement.tsx",
        lineNumber: 45,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV(Button, { "aria-label": "add-btn", variant: "contained", color: "primary", onClick: handleConfirmClick, sx: {
        margin: 1,
        padding: 1
      }, children: "Add" }, void 0, false, {
        fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/pages/InventoryManagement.tsx",
        lineNumber: 48,
        columnNumber: 17
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/pages/InventoryManagement.tsx",
      lineNumber: 40,
      columnNumber: 13
    }, this),
    /* @__PURE__ */ jsxDEV(Box, { sx: {
      margin: 6,
      display: "flex",
      justifyContent: "center",
      flexWrap: "wrap"
    }, children: [...ingredients].map((item, index) => /* @__PURE__ */ jsxDEV(Button, { variant: "outlined", sx: {
      margin: 1,
      boxShadow: clickedItems.includes(item) ? "0px 8px 16px rgba(0, 0, 0, 0.3)" : "0px 4px 8px rgba(0, 0, 0, 0.1)",
      backgroundColor: clickedItems.includes(item) ? "#4CAF50" : "transparent",
      // default background color
      color: clickedItems.includes(item) ? "white" : "black",
      // default color for text
      transform: clickedItems.includes(item) ? "scale(0.95)" : "none",
      // default scale effect
      textTransform: "none"
    }, onClick: () => handleItemClick(item), children: item }, index, false, {
      fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/pages/InventoryManagement.tsx",
      lineNumber: 63,
      columnNumber: 56
    }, this)) }, void 0, false, {
      fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/pages/InventoryManagement.tsx",
      lineNumber: 57,
      columnNumber: 13
    }, this),
    /* @__PURE__ */ jsxDEV(Box, { sx: {
      marginTop: 10,
      display: "flex",
      justifyContent: "space-around"
    }, children: [
      /* @__PURE__ */ jsxDEV(Box, { sx: {
        marginTop: 2
      }, children: /* @__PURE__ */ jsxDEV(Button, { "aria-label": "delete-btn", variant: "contained", color: "primary", onClick: handleDeleteItems, disabled: clickedItems.length === 0, children: "DELETE" }, void 0, false, {
        fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/pages/InventoryManagement.tsx",
        lineNumber: 90,
        columnNumber: 21
      }, this) }, void 0, false, {
        fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/pages/InventoryManagement.tsx",
        lineNumber: 87,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ jsxDEV(Box, { sx: {
        marginTop: 2
      }, children: /* @__PURE__ */ jsxDEV(Button, { "aria-label": "done-btn", variant: "contained", color: "secondary", onClick: handleDoneClick, children: "Done" }, void 0, false, {
        fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/pages/InventoryManagement.tsx",
        lineNumber: 99,
        columnNumber: 21
      }, this) }, void 0, false, {
        fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/pages/InventoryManagement.tsx",
        lineNumber: 96,
        columnNumber: 17
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/pages/InventoryManagement.tsx",
      lineNumber: 81,
      columnNumber: 13
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/pages/InventoryManagement.tsx",
    lineNumber: 36,
    columnNumber: 10
  }, this);
}
_s(InventoryManagement, "mQs5ovS4nPvKgG7neIFbFLl/jHY=", false, function() {
  return [useNavigate];
});
_c = InventoryManagement;
export default InventoryManagement;
var _c;
$RefreshReg$(_c, "InventoryManagement");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/s_mar/cs32/SnackStack/client/src/pages/InventoryManagement.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBMkNZOzs7Ozs7Ozs7Ozs7Ozs7O0FBM0NaLFNBQVNBLEtBQUtDLFFBQVFDLGlCQUFpQjtBQUN2QyxTQUFTQyxnQkFBZ0I7QUFDekIsU0FBU0MsbUJBQW1CO0FBQzVCLE9BQU87QUFFUCxTQUFTQyxzQkFBc0I7QUFBQUMsS0FBQTtBQUMzQixRQUFNLENBQUNDLFlBQVlDLGFBQWEsSUFBSUwsU0FBUyxFQUFFO0FBQy9DLFFBQU0sQ0FBQ00sYUFBYUMsY0FBYyxJQUFJUCxTQUFzQixvQkFBSVEsSUFBSSxDQUFDO0FBQ3JFLFFBQU0sQ0FBQ0MsY0FBY0MsZUFBZSxJQUFJVixTQUFtQixFQUFFO0FBQzdELFFBQU1XLFdBQVdWLFlBQVk7QUFFN0IsUUFBTVcsb0JBQW9CQSxDQUFDQyxNQUEyQztBQUNsRVIsa0JBQWNRLEVBQUVDLE9BQU9DLEtBQUs7QUFBQSxFQUNoQztBQUVBLFFBQU1DLHFCQUFxQkEsTUFBTTtBQUM3QixVQUFNQyxnQkFBZ0JiLFdBQVdjLFlBQVk7QUFFN0MsUUFBSWQsV0FBV2UsS0FBSyxNQUFNLE1BQU0sQ0FBQyxDQUFDLEdBQUdiLFdBQVcsRUFBRWMsS0FBTUMsZ0JBQWVBLFdBQVdILFlBQVksTUFBTUQsYUFBYSxHQUFHO0FBQ2hIVixxQkFBZ0JlLFVBQVMsSUFBSWQsSUFBSWMsS0FBS0MsSUFBSW5CLFVBQVUsQ0FBQyxDQUFDO0FBQ3REQyxvQkFBYyxFQUFFO0FBQUEsSUFDcEI7QUFBQSxFQUNKO0FBRUEsUUFBTW1CLGtCQUFrQkEsQ0FBQ0MsU0FBaUI7QUFDdEMsUUFBSWhCLGFBQWFpQixTQUFTRCxJQUFJLEdBQUc7QUFDN0JmLHNCQUFpQmlCLGVBQWNBLFVBQVVDLE9BQVFDLGVBQWNBLGNBQWNKLElBQUksQ0FBQztBQUFBLElBQ3RGLE9BQU87QUFDSGYsc0JBQWlCWSxVQUFTLENBQUMsR0FBR0EsTUFBTUcsSUFBSSxDQUFDO0FBQUEsSUFDN0M7QUFBQSxFQUNKO0FBRUEsUUFBTUssb0JBQW9CQSxNQUFNO0FBQzVCdkIsbUJBQWdCZSxVQUFTLElBQUlkLElBQUksQ0FBQyxHQUFHYyxJQUFJLEVBQUVNLE9BQVFILFVBQVMsQ0FBQ2hCLGFBQWFpQixTQUFTRCxJQUFJLENBQUMsQ0FBQyxDQUFDO0FBQzFGZixvQkFBZ0IsRUFBRTtBQUFBLEVBQ3RCO0FBRUEsUUFBTXFCLGtCQUFrQkEsTUFBTTtBQUMxQnBCLGFBQVMsR0FBRztBQUFBLEVBQ2hCO0FBRUEsU0FDSSx1QkFBQyxTQUNHO0FBQUEsMkJBQUMsUUFBRyxXQUFVLFNBQVEsb0NBQXRCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBMEM7QUFBQSxJQUcxQyx1QkFBQyxPQUFJLElBQUk7QUFBQSxNQUNMcUIsUUFBUTtBQUFBLE1BQ1JDLFNBQVM7QUFBQSxNQUNUQyxnQkFBZ0I7QUFBQSxJQUNwQixHQUNJO0FBQUEsNkJBQUMsYUFDRyxjQUFXLGtCQUNYLE9BQU0sa0JBQ04sU0FBUSxZQUNSLE9BQU85QixZQUNQLFVBQVVRLG1CQUNWLElBQUk7QUFBQSxRQUFFdUIsYUFBYTtBQUFBLE1BQUUsS0FOekI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQU0yQjtBQUFBLE1BRTNCLHVCQUFDLFVBQ0csY0FBVyxXQUNYLFNBQVEsYUFDUixPQUFNLFdBQ04sU0FBU25CLG9CQUNULElBQUk7QUFBQSxRQUNBZ0IsUUFBUTtBQUFBLFFBQ1JJLFNBQVM7QUFBQSxNQUNiLEdBQ0gsbUJBVEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQVdBO0FBQUEsU0F4Qko7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQXlCQTtBQUFBLElBR0EsdUJBQUMsT0FBSSxJQUFJO0FBQUEsTUFDTEosUUFBUTtBQUFBLE1BQ1JDLFNBQVM7QUFBQSxNQUNUQyxnQkFBZ0I7QUFBQSxNQUNoQkcsVUFBVTtBQUFBLElBQ2QsR0FDSyxXQUFDLEdBQUcvQixXQUFXLEVBQUVnQyxJQUFJLENBQUNiLE1BQU1jLFVBQ3pCLHVCQUFDLFVBRUcsU0FBUSxZQUNSLElBQUk7QUFBQSxNQUNBUCxRQUFRO0FBQUEsTUFDUlEsV0FBVy9CLGFBQWFpQixTQUFTRCxJQUFJLElBQy9CLG9DQUNBO0FBQUEsTUFDTmdCLGlCQUFpQmhDLGFBQWFpQixTQUFTRCxJQUFJLElBQ3JDLFlBQ0E7QUFBQTtBQUFBLE1BQ05pQixPQUFPakMsYUFBYWlCLFNBQVNELElBQUksSUFDM0IsVUFDQTtBQUFBO0FBQUEsTUFDTmtCLFdBQVdsQyxhQUFhaUIsU0FBU0QsSUFBSSxJQUMvQixnQkFDQTtBQUFBO0FBQUEsTUFDTm1CLGVBQWU7QUFBQSxJQUNuQixHQUNBLFNBQVMsTUFBTXBCLGdCQUFnQkMsSUFBSSxHQUVsQ0Esa0JBcEJJYyxPQURUO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FzQkEsQ0FDSCxLQTlCTDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBK0JBO0FBQUEsSUFFQSx1QkFBQyxPQUFJLElBQUk7QUFBQSxNQUNMTSxXQUFXO0FBQUEsTUFDWFosU0FBUztBQUFBLE1BQ1RDLGdCQUFnQjtBQUFBLElBQ3BCLEdBRUk7QUFBQSw2QkFBQyxPQUFJLElBQUk7QUFBQSxRQUFFVyxXQUFXO0FBQUEsTUFBRSxHQUNwQixpQ0FBQyxVQUNHLGNBQVcsY0FDWCxTQUFRLGFBQ1IsT0FBTSxXQUNOLFNBQVNmLG1CQUNULFVBQVVyQixhQUFhcUMsV0FBVyxHQUNyQyxzQkFORDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBUUEsS0FUSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBVUE7QUFBQSxNQUdBLHVCQUFDLE9BQUksSUFBSTtBQUFBLFFBQUVELFdBQVc7QUFBQSxNQUFFLEdBQ3BCLGlDQUFDLFVBQ0csY0FBVyxZQUNYLFNBQVEsYUFDUixPQUFNLGFBQ04sU0FBU2QsaUJBQ1osb0JBTEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQVFBLEtBVEo7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQVVBO0FBQUEsU0E3Qko7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQThCQTtBQUFBLE9BL0ZKO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FnR0E7QUFFUjtBQUFDNUIsR0F2SVFELHFCQUFtQjtBQUFBLFVBSVBELFdBQVc7QUFBQTtBQUFBOEMsS0FKdkI3QztBQXlJVCxlQUFlQTtBQUFvQixJQUFBNkM7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbIkJveCIsIkJ1dHRvbiIsIlRleHRGaWVsZCIsInVzZVN0YXRlIiwidXNlTmF2aWdhdGUiLCJJbnZlbnRvcnlNYW5hZ2VtZW50IiwiX3MiLCJpbnB1dFZhbHVlIiwic2V0SW5wdXRWYWx1ZSIsImluZ3JlZGllbnRzIiwic2V0SW5ncmVkaWVudHMiLCJTZXQiLCJjbGlja2VkSXRlbXMiLCJzZXRDbGlja2VkSXRlbXMiLCJuYXZpZ2F0ZSIsImhhbmRsZUlucHV0Q2hhbmdlIiwiZSIsInRhcmdldCIsInZhbHVlIiwiaGFuZGxlQ29uZmlybUNsaWNrIiwibG93ZXJDYXNlSXRlbSIsInRvTG93ZXJDYXNlIiwidHJpbSIsInNvbWUiLCJpbmdyZWRpZW50IiwicHJldiIsImFkZCIsImhhbmRsZUl0ZW1DbGljayIsIml0ZW0iLCJpbmNsdWRlcyIsInByZXZJdGVtcyIsImZpbHRlciIsIm90aGVySXRlbSIsImhhbmRsZURlbGV0ZUl0ZW1zIiwiaGFuZGxlRG9uZUNsaWNrIiwibWFyZ2luIiwiZGlzcGxheSIsImp1c3RpZnlDb250ZW50IiwibWFyZ2luUmlnaHQiLCJwYWRkaW5nIiwiZmxleFdyYXAiLCJtYXAiLCJpbmRleCIsImJveFNoYWRvdyIsImJhY2tncm91bmRDb2xvciIsImNvbG9yIiwidHJhbnNmb3JtIiwidGV4dFRyYW5zZm9ybSIsIm1hcmdpblRvcCIsImxlbmd0aCIsIl9jIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiSW52ZW50b3J5TWFuYWdlbWVudC50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgQm94LCBCdXR0b24sIFRleHRGaWVsZCB9IGZyb20gXCJAbXVpL21hdGVyaWFsXCI7XHJcbmltcG9ydCB7IHVzZVN0YXRlIH0gZnJvbSBcInJlYWN0XCI7XHJcbmltcG9ydCB7IHVzZU5hdmlnYXRlIH0gZnJvbSBcInJlYWN0LXJvdXRlci1kb21cIjtcclxuaW1wb3J0IFwiLi4vc3R5bGVzL0ludmVudG9yeU1hbmFnZW1lbnQuY3NzXCI7XHJcblxyXG5mdW5jdGlvbiBJbnZlbnRvcnlNYW5hZ2VtZW50KCkge1xyXG4gICAgY29uc3QgW2lucHV0VmFsdWUsIHNldElucHV0VmFsdWVdID0gdXNlU3RhdGUoJycpO1xyXG4gICAgY29uc3QgW2luZ3JlZGllbnRzLCBzZXRJbmdyZWRpZW50c10gPSB1c2VTdGF0ZTxTZXQ8c3RyaW5nPj4obmV3IFNldCgpKTtcclxuICAgIGNvbnN0IFtjbGlja2VkSXRlbXMsIHNldENsaWNrZWRJdGVtc10gPSB1c2VTdGF0ZTxzdHJpbmdbXT4oW10pO1xyXG4gICAgY29uc3QgbmF2aWdhdGUgPSB1c2VOYXZpZ2F0ZSgpO1xyXG5cclxuICAgIGNvbnN0IGhhbmRsZUlucHV0Q2hhbmdlID0gKGU6IFJlYWN0LkNoYW5nZUV2ZW50PEhUTUxJbnB1dEVsZW1lbnQ+KSA9PiB7XHJcbiAgICAgICAgc2V0SW5wdXRWYWx1ZShlLnRhcmdldC52YWx1ZSk7XHJcbiAgICB9O1xyXG5cclxuICAgIGNvbnN0IGhhbmRsZUNvbmZpcm1DbGljayA9ICgpID0+IHtcclxuICAgICAgICBjb25zdCBsb3dlckNhc2VJdGVtID0gaW5wdXRWYWx1ZS50b0xvd2VyQ2FzZSgpO1xyXG5cclxuICAgICAgICBpZiAoaW5wdXRWYWx1ZS50cmltKCkgIT09ICcnICYmICFbLi4uaW5ncmVkaWVudHNdLnNvbWUoKGluZ3JlZGllbnQpID0+IGluZ3JlZGllbnQudG9Mb3dlckNhc2UoKSA9PT0gbG93ZXJDYXNlSXRlbSkpIHtcclxuICAgICAgICAgICAgc2V0SW5ncmVkaWVudHMoKHByZXYpID0+IG5ldyBTZXQocHJldi5hZGQoaW5wdXRWYWx1ZSkpKTtcclxuICAgICAgICAgICAgc2V0SW5wdXRWYWx1ZSgnJyk7XHJcbiAgICAgICAgfVxyXG4gICAgfTtcclxuXHJcbiAgICBjb25zdCBoYW5kbGVJdGVtQ2xpY2sgPSAoaXRlbTogc3RyaW5nKSA9PiB7XHJcbiAgICAgICAgaWYgKGNsaWNrZWRJdGVtcy5pbmNsdWRlcyhpdGVtKSkge1xyXG4gICAgICAgICAgICBzZXRDbGlja2VkSXRlbXMoKHByZXZJdGVtcykgPT4gcHJldkl0ZW1zLmZpbHRlcigob3RoZXJJdGVtKSA9PiBvdGhlckl0ZW0gIT09IGl0ZW0pKTtcclxuICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICBzZXRDbGlja2VkSXRlbXMoKHByZXYpID0+IFsuLi5wcmV2LCBpdGVtXSk7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIGNvbnN0IGhhbmRsZURlbGV0ZUl0ZW1zID0gKCkgPT4ge1xyXG4gICAgICAgIHNldEluZ3JlZGllbnRzKChwcmV2KSA9PiBuZXcgU2V0KFsuLi5wcmV2XS5maWx0ZXIoKGl0ZW0pID0+ICFjbGlja2VkSXRlbXMuaW5jbHVkZXMoaXRlbSkpKSk7XHJcbiAgICAgICAgc2V0Q2xpY2tlZEl0ZW1zKFtdKTtcclxuICAgIH1cclxuXHJcbiAgICBjb25zdCBoYW5kbGVEb25lQ2xpY2sgPSAoKSA9PiB7XHJcbiAgICAgICAgbmF2aWdhdGUoJy8nKTtcclxuICAgIH1cclxuXHJcbiAgICByZXR1cm4gKFxyXG4gICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgIDxoMSBjbGFzc05hbWU9XCJ0aXRsZVwiPkludmVudG9yeSBNYW5hZ2VtZW50PC9oMT5cclxuXHJcbiAgICAgICAgICAgIHsvKiBpbnB1dCBib3ggZm9yIGFkZGluZyBpbmdyZWRpZW50ICovfVxyXG4gICAgICAgICAgICA8Qm94IHN4PXt7XHJcbiAgICAgICAgICAgICAgICBtYXJnaW46IDIsXHJcbiAgICAgICAgICAgICAgICBkaXNwbGF5OiAnZmxleCcsXHJcbiAgICAgICAgICAgICAgICBqdXN0aWZ5Q29udGVudDogJ2NlbnRlcidcclxuICAgICAgICAgICAgfX0+XHJcbiAgICAgICAgICAgICAgICA8VGV4dEZpZWxkXHJcbiAgICAgICAgICAgICAgICAgICAgYXJpYS1sYWJlbD1cImFkZC1pbmdyZWRpZW50XCJcclxuICAgICAgICAgICAgICAgICAgICBsYWJlbD1cImFkZCBpbmdyZWRpZW50XCJcclxuICAgICAgICAgICAgICAgICAgICB2YXJpYW50PVwib3V0bGluZWRcIlxyXG4gICAgICAgICAgICAgICAgICAgIHZhbHVlPXtpbnB1dFZhbHVlfVxyXG4gICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVJbnB1dENoYW5nZX1cclxuICAgICAgICAgICAgICAgICAgICBzeD17eyBtYXJnaW5SaWdodDogMiB9fVxyXG4gICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgIDxCdXR0b25cclxuICAgICAgICAgICAgICAgICAgICBhcmlhLWxhYmVsPVwiYWRkLWJ0blwiXHJcbiAgICAgICAgICAgICAgICAgICAgdmFyaWFudD1cImNvbnRhaW5lZFwiXHJcbiAgICAgICAgICAgICAgICAgICAgY29sb3I9XCJwcmltYXJ5XCJcclxuICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXtoYW5kbGVDb25maXJtQ2xpY2t9XHJcbiAgICAgICAgICAgICAgICAgICAgc3g9e3tcclxuICAgICAgICAgICAgICAgICAgICAgICAgbWFyZ2luOiAxLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBwYWRkaW5nOiAxXHJcbiAgICAgICAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICBBZGRcclxuICAgICAgICAgICAgICAgIDwvQnV0dG9uPlxyXG4gICAgICAgICAgICA8L0JveD5cclxuXHJcbiAgICAgICAgICAgIHsvKiBzaG93IGluZ3JlZGllbnRzICovfVxyXG4gICAgICAgICAgICA8Qm94IHN4PXt7XHJcbiAgICAgICAgICAgICAgICBtYXJnaW46IDYsXHJcbiAgICAgICAgICAgICAgICBkaXNwbGF5OiAnZmxleCcsXHJcbiAgICAgICAgICAgICAgICBqdXN0aWZ5Q29udGVudDogJ2NlbnRlcicsIFxyXG4gICAgICAgICAgICAgICAgZmxleFdyYXA6ICd3cmFwJ1xyXG4gICAgICAgICAgICB9fT5cclxuICAgICAgICAgICAgICAgIHtbLi4uaW5ncmVkaWVudHNdLm1hcCgoaXRlbSwgaW5kZXgpID0+IChcclxuICAgICAgICAgICAgICAgICAgICA8QnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGtleT17aW5kZXh9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhcmlhbnQ9XCJvdXRsaW5lZFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHN4PXt7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBtYXJnaW46IDEsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBib3hTaGFkb3c6IGNsaWNrZWRJdGVtcy5pbmNsdWRlcyhpdGVtKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID8gJzBweCA4cHggMTZweCByZ2JhKDAsIDAsIDAsIDAuMyknXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgOiAnMHB4IDRweCA4cHggcmdiYSgwLCAwLCAwLCAwLjEpJyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGJhY2tncm91bmRDb2xvcjogY2xpY2tlZEl0ZW1zLmluY2x1ZGVzKGl0ZW0pXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPyAnIzRDQUY1MCcgLy8gYmFja2dyb3VuZCBjb2xvciBmb3IgdGhlIGNsaWNrZWQgaXRlbVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDogJ3RyYW5zcGFyZW50JywgLy8gZGVmYXVsdCBiYWNrZ3JvdW5kIGNvbG9yXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb2xvcjogY2xpY2tlZEl0ZW1zLmluY2x1ZGVzKGl0ZW0pXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPyAnd2hpdGUnIC8vIGNvbG9yIGZvciBjbGlja2VkIHRleHRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA6ICdibGFjaycsIC8vIGRlZmF1bHQgY29sb3IgZm9yIHRleHRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRyYW5zZm9ybTogY2xpY2tlZEl0ZW1zLmluY2x1ZGVzKGl0ZW0pXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPyAnc2NhbGUoMC45NSknIC8vIHNjYWxlIGVmZmVjdCBhZnRlciBjbGlja2VkXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgOiAnbm9uZScsIC8vIGRlZmF1bHQgc2NhbGUgZWZmZWN0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0ZXh0VHJhbnNmb3JtOiAnbm9uZSdcclxuICAgICAgICAgICAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gaGFuZGxlSXRlbUNsaWNrKGl0ZW0pfVxyXG4gICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAge2l0ZW19XHJcbiAgICAgICAgICAgICAgICAgICAgPC9CdXR0b24+XHJcbiAgICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgPC9Cb3g+XHJcblxyXG4gICAgICAgICAgICA8Qm94IHN4PXt7XHJcbiAgICAgICAgICAgICAgICBtYXJnaW5Ub3A6IDEwLFxyXG4gICAgICAgICAgICAgICAgZGlzcGxheTogJ2ZsZXgnLCBcclxuICAgICAgICAgICAgICAgIGp1c3RpZnlDb250ZW50OiAnc3BhY2UtYXJvdW5kJ1xyXG4gICAgICAgICAgICB9fT5cclxuICAgICAgICAgICAgICAgIHsvKiBEZWxldGUgYnV0dG9uIGZvciBjbGlja2VkIGl0ZW1zICovfVxyXG4gICAgICAgICAgICAgICAgPEJveCBzeD17eyBtYXJnaW5Ub3A6IDIgfX0+XHJcbiAgICAgICAgICAgICAgICAgICAgPEJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICAgICAgICBhcmlhLWxhYmVsPVwiZGVsZXRlLWJ0blwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhcmlhbnQ9XCJjb250YWluZWRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBjb2xvcj1cInByaW1hcnlcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXtoYW5kbGVEZWxldGVJdGVtc31cclxuICAgICAgICAgICAgICAgICAgICAgICAgZGlzYWJsZWQ9e2NsaWNrZWRJdGVtcy5sZW5ndGggPT09IDB9XHJcbiAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBERUxFVEVcclxuICAgICAgICAgICAgICAgICAgICA8L0J1dHRvbj5cclxuICAgICAgICAgICAgICAgIDwvQm94PlxyXG5cclxuICAgICAgICAgICAgICAgIHsvKiBEb25lIGJ1dHRvbiB3aWxsIGJyaW5nIHVzZXJzIGJhY2sgdG8gdGhlIGhvbWUgcGFnZSAqL31cclxuICAgICAgICAgICAgICAgIDxCb3ggc3g9e3sgbWFyZ2luVG9wOiAyIH19PlxyXG4gICAgICAgICAgICAgICAgICAgIDxCdXR0b25cclxuICAgICAgICAgICAgICAgICAgICAgICAgYXJpYS1sYWJlbD1cImRvbmUtYnRuXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgdmFyaWFudD1cImNvbnRhaW5lZFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbG9yPVwic2Vjb25kYXJ5XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17aGFuZGxlRG9uZUNsaWNrfVxyXG4gICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgICAgRG9uZVxyXG5cclxuICAgICAgICAgICAgICAgICAgICA8L0J1dHRvbj5cclxuICAgICAgICAgICAgICAgIDwvQm94PlxyXG4gICAgICAgICAgICA8L0JveD5cclxuICAgICAgICA8L2Rpdj5cclxuICAgIClcclxufVxyXG5cclxuZXhwb3J0IGRlZmF1bHQgSW52ZW50b3J5TWFuYWdlbWVudDsiXSwiZmlsZSI6IkM6L1VzZXJzL3NfbWFyL2NzMzIvU25hY2tTdGFjay9jbGllbnQvc3JjL3BhZ2VzL0ludmVudG9yeU1hbmFnZW1lbnQudHN4In0=