"use client";
import "/node_modules/.vite/deps/chunk-C6WWHQR7.js?v=b14ee716";
import {
  createSvgIcon
} from "/node_modules/.vite/deps/chunk-575B7IBN.js?v=b14ee716";
import "/node_modules/.vite/deps/chunk-WMRV7BCS.js?v=b14ee716";
import {
  require_jsx_runtime
} from "/node_modules/.vite/deps/chunk-TOXUORXJ.js?v=b14ee716";
import "/node_modules/.vite/deps/chunk-64FVIM6J.js?v=b14ee716";
import "/node_modules/.vite/deps/chunk-K5YNGTCN.js?v=b14ee716";
import {
  __toESM
} from "/node_modules/.vite/deps/chunk-ZC22LKFR.js?v=b14ee716";

// node_modules/@mui/icons-material/esm/KitchenOutlined.js
var import_jsx_runtime = __toESM(require_jsx_runtime());
var KitchenOutlined_default = createSvgIcon((0, import_jsx_runtime.jsx)("path", {
  d: "M8 5h2v3H8zm0 7h2v5H8zm10-9.99L6 2a2 2 0 0 0-2 2v16c0 1.1.9 2 2 2h12c1.1 0 2-.9 2-2V4c0-1.11-.9-1.99-2-1.99M18 20H6v-9.02h12zm0-11H6V4h12z"
}), "KitchenOutlined");
export {
  KitchenOutlined_default as default
};
//# sourceMappingURL=@mui_icons-material_KitchenOutlined.js.map
