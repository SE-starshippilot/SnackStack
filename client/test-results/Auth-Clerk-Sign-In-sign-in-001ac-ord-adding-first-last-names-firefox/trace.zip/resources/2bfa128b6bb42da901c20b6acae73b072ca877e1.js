import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/Navbar.tsx");import { jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/s_mar/cs32/SnackStack/client/src/components/Navbar.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import { Link, useLocation } from "/node_modules/.vite/deps/react-router-dom.js?v=b14ee716";
import "/src/styles/Home.css";
const navItems = [{
  name: "Home",
  path: "/"
}, {
  name: "Cook",
  path: "/cook"
}, {
  name: "Inventory",
  path: "/inventory"
}];
export const Navbar = () => {
  _s();
  const location = useLocation();
  return /* @__PURE__ */ jsxDEV("nav", { className: "navbar", children: /* @__PURE__ */ jsxDEV("div", { className: "navbar-content", children: [
    /* @__PURE__ */ jsxDEV("div", { className: "logo", children: "Snack Stack" }, void 0, false, {
      fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/components/Navbar.tsx",
      lineNumber: 19,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "nav-links", children: [
      navItems.map((item) => /* @__PURE__ */ jsxDEV(Link, { to: item.path, className: `nav-link ${location.pathname === item.path ? "active" : ""}`, children: item.name }, item.path, false, {
        fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/components/Navbar.tsx",
        lineNumber: 21,
        columnNumber: 33
      }, this)),
      /* @__PURE__ */ jsxDEV("button", { className: "nav-link", children: "Account" }, void 0, false, {
        fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/components/Navbar.tsx",
        lineNumber: 24,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/components/Navbar.tsx",
      lineNumber: 20,
      columnNumber: 9
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/components/Navbar.tsx",
    lineNumber: 18,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/components/Navbar.tsx",
    lineNumber: 17,
    columnNumber: 10
  }, this);
};
_s(Navbar, "pkHmaVRPskBaU4tMJuJJpV42k1I=", false, function() {
  return [useLocation];
});
_c = Navbar;
var _c;
$RefreshReg$(_c, "Navbar");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/s_mar/cs32/SnackStack/client/src/components/Navbar.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBY1E7Ozs7Ozs7Ozs7Ozs7Ozs7QUFkUixTQUFTQSxNQUFNQyxtQkFBbUI7QUFDbEMsT0FBTztBQUVQLE1BQU1DLFdBQVcsQ0FDZjtBQUFBLEVBQUVDLE1BQU07QUFBQSxFQUFRQyxNQUFNO0FBQUksR0FDMUI7QUFBQSxFQUFFRCxNQUFNO0FBQUEsRUFBUUMsTUFBTTtBQUFRLEdBQzlCO0FBQUEsRUFBRUQsTUFBTTtBQUFBLEVBQWFDLE1BQU07QUFBYSxDQUFDO0FBR3BDLGFBQU1DLFNBQVNBLE1BQU07QUFBQUMsS0FBQTtBQUMxQixRQUFNQyxXQUFXTixZQUFZO0FBQzdCLFNBQ0UsdUJBQUMsU0FBSSxXQUFVLFVBQ2IsaUNBQUMsU0FBSSxXQUFVLGtCQUNiO0FBQUEsMkJBQUMsU0FBSSxXQUFVLFFBQU8sMkJBQXRCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBaUM7QUFBQSxJQUNqQyx1QkFBQyxTQUFJLFdBQVUsYUFDWkM7QUFBQUEsZUFBU00sSUFBS0MsVUFDYix1QkFBQyxRQUVDLElBQUlBLEtBQUtMLE1BQ1QsV0FBVyxZQUNURyxTQUFTRyxhQUFhRCxLQUFLTCxPQUFPLFdBQVcsRUFBRSxJQUdoREssZUFBS04sUUFORE0sS0FBS0wsTUFEWjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBUUEsQ0FDRDtBQUFBLE1BQ0QsdUJBQUMsWUFBTyxXQUFVLFlBQVcsdUJBQTdCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBb0M7QUFBQSxTQVp0QztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBYUE7QUFBQSxPQWZGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FnQkEsS0FqQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQWtCQTtBQUVKO0FBQUVFLEdBdkJXRCxRQUFNO0FBQUEsVUFDQUosV0FBVztBQUFBO0FBQUFVLEtBRGpCTjtBQUFNLElBQUFNO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJMaW5rIiwidXNlTG9jYXRpb24iLCJuYXZJdGVtcyIsIm5hbWUiLCJwYXRoIiwiTmF2YmFyIiwiX3MiLCJsb2NhdGlvbiIsIm1hcCIsIml0ZW0iLCJwYXRobmFtZSIsIl9jIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiTmF2YmFyLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBMaW5rLCB1c2VMb2NhdGlvbiB9IGZyb20gXCJyZWFjdC1yb3V0ZXItZG9tXCI7XHJcbmltcG9ydCBcIi4uL3N0eWxlcy9Ib21lLmNzc1wiO1xyXG5cclxuY29uc3QgbmF2SXRlbXMgPSBbXHJcbiAgeyBuYW1lOiBcIkhvbWVcIiwgcGF0aDogXCIvXCIgfSxcclxuICB7IG5hbWU6IFwiQ29va1wiLCBwYXRoOiBcIi9jb29rXCIgfSxcclxuICB7IG5hbWU6IFwiSW52ZW50b3J5XCIsIHBhdGg6IFwiL2ludmVudG9yeVwiIH0sXHJcbl07XHJcblxyXG5leHBvcnQgY29uc3QgTmF2YmFyID0gKCkgPT4ge1xyXG4gIGNvbnN0IGxvY2F0aW9uID0gdXNlTG9jYXRpb24oKTtcclxuICByZXR1cm4gKFxyXG4gICAgPG5hdiBjbGFzc05hbWU9XCJuYXZiYXJcIj5cclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJuYXZiYXItY29udGVudFwiPlxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibG9nb1wiPlNuYWNrIFN0YWNrPC9kaXY+XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJuYXYtbGlua3NcIj5cclxuICAgICAgICAgIHtuYXZJdGVtcy5tYXAoKGl0ZW0pID0+IChcclxuICAgICAgICAgICAgPExpbmtcclxuICAgICAgICAgICAgICBrZXk9e2l0ZW0ucGF0aH1cclxuICAgICAgICAgICAgICB0bz17aXRlbS5wYXRofVxyXG4gICAgICAgICAgICAgIGNsYXNzTmFtZT17YG5hdi1saW5rICR7XHJcbiAgICAgICAgICAgICAgICBsb2NhdGlvbi5wYXRobmFtZSA9PT0gaXRlbS5wYXRoID8gXCJhY3RpdmVcIiA6IFwiXCJcclxuICAgICAgICAgICAgICB9YH1cclxuICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgIHtpdGVtLm5hbWV9XHJcbiAgICAgICAgICAgIDwvTGluaz5cclxuICAgICAgICAgICkpfVxyXG4gICAgICAgICAgPGJ1dHRvbiBjbGFzc05hbWU9XCJuYXYtbGlua1wiPkFjY291bnQ8L2J1dHRvbj5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgPC9kaXY+XHJcbiAgICA8L25hdj5cclxuICApO1xyXG59O1xyXG4iXSwiZmlsZSI6IkM6L1VzZXJzL3NfbWFyL2NzMzIvU25hY2tTdGFjay9jbGllbnQvc3JjL2NvbXBvbmVudHMvTmF2YmFyLnRzeCJ9