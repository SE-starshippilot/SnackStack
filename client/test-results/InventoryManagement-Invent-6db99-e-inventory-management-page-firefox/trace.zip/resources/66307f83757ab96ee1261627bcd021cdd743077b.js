import {
  require_react
} from "/node_modules/.vite/deps/chunk-K5YNGTCN.js?v=4d3a3d4b";
import "/node_modules/.vite/deps/chunk-ZC22LKFR.js?v=4d3a3d4b";
export default require_react();
//# sourceMappingURL=react.js.map
