import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/RecipeTableRow/ExpandedRecipeDetails.tsx");import { jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/s_mar/cs32/SnackStack/client/src/components/RecipeTableRow/ExpandedRecipeDetails.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=4d3a3d4b"; const React = __vite__cjsImport3_react.__esModule ? __vite__cjsImport3_react.default : __vite__cjsImport3_react;
import { Box, Typography, Table, TableBody, TableHead, TableRow, TableCell } from "/node_modules/.vite/deps/@mui_material.js?v=4d3a3d4b";
import { COLORS, TYPOGRAPHY } from "/src/styles/constants.ts";
const TABLE_COLUMN_WIDTHS = {
  ingredient: "55%",
  quantity: "25%",
  unit: "20%"
};
const tableStyles = {
  maxWidth: "600px",
  borderCollapse: "collapse",
  "& th, & td": {
    fontSize: "0.875rem",
    fontFamily: "inherit",
    borderBottom: "none"
  },
  "& thead th": {
    borderBottom: `1px solid ${COLORS.border}`,
    fontWeight: TYPOGRAPHY.fontWeights.semiBold
  },
  border: `1px solid ${COLORS.border}`
};
const ExpandedRecipeDetailsComponent = ({
  recipe
}) => {
  return /* @__PURE__ */ jsxDEV(Box, { sx: {
    margin: 2
  }, children: [
    /* @__PURE__ */ jsxDEV(Typography, { variant: "h6", gutterBottom: true, component: "div", sx: {
      color: COLORS.text.primary,
      fontWeight: TYPOGRAPHY.fontWeights.semiBold
    }, children: "Recipe Details" }, void 0, false, {
      fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/components/RecipeTableRow/ExpandedRecipeDetails.tsx",
      lineNumber: 33,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(Box, { sx: {
      mb: 2
    }, children: /* @__PURE__ */ jsxDEV(Table, { size: "small", sx: tableStyles, children: [
      /* @__PURE__ */ jsxDEV(TableHead, { children: /* @__PURE__ */ jsxDEV(TableRow, { children: [
        /* @__PURE__ */ jsxDEV(TableCell, { sx: {
          width: TABLE_COLUMN_WIDTHS.ingredient
        }, children: "Ingredient" }, void 0, false, {
          fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/components/RecipeTableRow/ExpandedRecipeDetails.tsx",
          lineNumber: 45,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV(TableCell, { sx: {
          width: TABLE_COLUMN_WIDTHS.quantity
        }, children: "Quantity" }, void 0, false, {
          fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/components/RecipeTableRow/ExpandedRecipeDetails.tsx",
          lineNumber: 50,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV(TableCell, { sx: {
          width: TABLE_COLUMN_WIDTHS.unit
        }, children: "Unit" }, void 0, false, {
          fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/components/RecipeTableRow/ExpandedRecipeDetails.tsx",
          lineNumber: 55,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/components/RecipeTableRow/ExpandedRecipeDetails.tsx",
        lineNumber: 44,
        columnNumber: 13
      }, this) }, void 0, false, {
        fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/components/RecipeTableRow/ExpandedRecipeDetails.tsx",
        lineNumber: 43,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV(TableBody, { children: recipe.recipeIngredients.map((ingredient, index) => /* @__PURE__ */ jsxDEV(TableRow, { children: [
        /* @__PURE__ */ jsxDEV(TableCell, { sx: {
          width: TABLE_COLUMN_WIDTHS.ingredient
        }, children: [
          ingredient.ingredientName,
          ingredient.note && /* @__PURE__ */ jsxDEV("span", { style: {
            marginLeft: "8px",
            color: COLORS.text.secondary,
            fontStyle: "italic"
          }, children: [
            "(Note: ",
            ingredient.note,
            ")"
          ] }, void 0, true, {
            fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/components/RecipeTableRow/ExpandedRecipeDetails.tsx",
            lineNumber: 68,
            columnNumber: 39
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/components/RecipeTableRow/ExpandedRecipeDetails.tsx",
          lineNumber: 64,
          columnNumber: 17
        }, this),
        /* @__PURE__ */ jsxDEV(TableCell, { sx: {
          width: TABLE_COLUMN_WIDTHS.quantity
        }, children: ingredient.quantity }, void 0, false, {
          fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/components/RecipeTableRow/ExpandedRecipeDetails.tsx",
          lineNumber: 76,
          columnNumber: 17
        }, this),
        /* @__PURE__ */ jsxDEV(TableCell, { sx: {
          width: TABLE_COLUMN_WIDTHS.unit
        }, children: ingredient.unit }, void 0, false, {
          fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/components/RecipeTableRow/ExpandedRecipeDetails.tsx",
          lineNumber: 81,
          columnNumber: 17
        }, this)
      ] }, index, true, {
        fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/components/RecipeTableRow/ExpandedRecipeDetails.tsx",
        lineNumber: 63,
        columnNumber: 66
      }, this)) }, void 0, false, {
        fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/components/RecipeTableRow/ExpandedRecipeDetails.tsx",
        lineNumber: 62,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/components/RecipeTableRow/ExpandedRecipeDetails.tsx",
      lineNumber: 42,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/components/RecipeTableRow/ExpandedRecipeDetails.tsx",
      lineNumber: 39,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(Box, { children: [
      /* @__PURE__ */ jsxDEV(Typography, { variant: "subtitle1", gutterBottom: true, component: "div", sx: {
        color: COLORS.text.primary,
        fontWeight: TYPOGRAPHY.fontWeights.semiBold
      }, children: "Steps" }, void 0, false, {
        fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/components/RecipeTableRow/ExpandedRecipeDetails.tsx",
        lineNumber: 91,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(Box, { component: "ol", sx: {
        mt: 1,
        pl: 2,
        color: COLORS.text.primary
      }, children: recipe.recipeSteps.map((step, index) => /* @__PURE__ */ jsxDEV("li", { style: {
        marginBottom: "8px"
      }, children: step }, index, false, {
        fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/components/RecipeTableRow/ExpandedRecipeDetails.tsx",
        lineNumber: 102,
        columnNumber: 52
      }, this)) }, void 0, false, {
        fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/components/RecipeTableRow/ExpandedRecipeDetails.tsx",
        lineNumber: 97,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/components/RecipeTableRow/ExpandedRecipeDetails.tsx",
      lineNumber: 90,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/components/RecipeTableRow/ExpandedRecipeDetails.tsx",
    lineNumber: 30,
    columnNumber: 10
  }, this);
};
_c = ExpandedRecipeDetailsComponent;
export const ExpandedRecipeDetails = React.memo(ExpandedRecipeDetailsComponent, (prevProps, nextProps) => {
  return prevProps.recipe.id === nextProps.recipe.id;
});
_c2 = ExpandedRecipeDetails;
var _c, _c2;
$RefreshReg$(_c, "ExpandedRecipeDetailsComponent");
$RefreshReg$(_c2, "ExpandedRecipeDetails");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/s_mar/cs32/SnackStack/client/src/components/RecipeTableRow/ExpandedRecipeDetails.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBMkNNO0FBM0NOLE9BQU9BLG9CQUFrQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFDekIsU0FDRUMsS0FDQUMsWUFDQUMsT0FDQUMsV0FDQUMsV0FDQUMsVUFDQUMsaUJBQ0s7QUFFUCxTQUFTQyxRQUFRQyxrQkFBa0I7QUFFbkMsTUFBTUMsc0JBQXNCO0FBQUEsRUFDMUJDLFlBQVk7QUFBQSxFQUNaQyxVQUFVO0FBQUEsRUFDVkMsTUFBTTtBQUNSO0FBRUEsTUFBTUMsY0FBYztBQUFBLEVBQ2xCQyxVQUFVO0FBQUEsRUFDVkMsZ0JBQWdCO0FBQUEsRUFDaEIsY0FBYztBQUFBLElBQ1pDLFVBQVU7QUFBQSxJQUNWQyxZQUFZO0FBQUEsSUFDWkMsY0FBYztBQUFBLEVBQ2hCO0FBQUEsRUFDQSxjQUFjO0FBQUEsSUFDWkEsY0FBYyxhQUFhWCxPQUFPWSxNQUFNO0FBQUEsSUFDeENDLFlBQVlaLFdBQVdhLFlBQVlDO0FBQUFBLEVBQ3JDO0FBQUEsRUFDQUgsUUFBUSxhQUFhWixPQUFPWSxNQUFNO0FBQ3BDO0FBTUEsTUFBTUksaUNBQXVFQSxDQUFDO0FBQUEsRUFDNUVDO0FBQ0YsTUFBTTtBQUNKLFNBQ0UsdUJBQUMsT0FBSSxJQUFJO0FBQUEsSUFBRUMsUUFBUTtBQUFBLEVBQUUsR0FDbkI7QUFBQSwyQkFBQyxjQUNDLFNBQVEsTUFDUixjQUFZLE1BQ1osV0FBVSxPQUNWLElBQUk7QUFBQSxNQUNGQyxPQUFPbkIsT0FBT29CLEtBQUtDO0FBQUFBLE1BQ25CUixZQUFZWixXQUFXYSxZQUFZQztBQUFBQSxJQUNyQyxHQUNELDhCQVJEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FVQTtBQUFBLElBQ0EsdUJBQUMsT0FBSSxJQUFJO0FBQUEsTUFBRU8sSUFBSTtBQUFBLElBQUUsR0FDZixpQ0FBQyxTQUFNLE1BQUssU0FBUSxJQUFJaEIsYUFDdEI7QUFBQSw2QkFBQyxhQUNDLGlDQUFDLFlBQ0M7QUFBQSwrQkFBQyxhQUFVLElBQUk7QUFBQSxVQUFFaUIsT0FBT3JCLG9CQUFvQkM7QUFBQUEsUUFBVyxHQUFHLDBCQUExRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQSxRQUNBLHVCQUFDLGFBQVUsSUFBSTtBQUFBLFVBQUVvQixPQUFPckIsb0JBQW9CRTtBQUFBQSxRQUFTLEdBQUcsd0JBQXhEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFFBQ0EsdUJBQUMsYUFBVSxJQUFJO0FBQUEsVUFBRW1CLE9BQU9yQixvQkFBb0JHO0FBQUFBLFFBQUssR0FBRyxvQkFBcEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsV0FURjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBVUEsS0FYRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBWUE7QUFBQSxNQUNBLHVCQUFDLGFBQ0VZLGlCQUFPTyxrQkFBa0JDLElBQUksQ0FBQ3RCLFlBQVl1QixVQUN6Qyx1QkFBQyxZQUNDO0FBQUEsK0JBQUMsYUFBVSxJQUFJO0FBQUEsVUFBRUgsT0FBT3JCLG9CQUFvQkM7QUFBQUEsUUFBVyxHQUNwREE7QUFBQUEscUJBQVd3QjtBQUFBQSxVQUNYeEIsV0FBV3lCLFFBQ1YsdUJBQUMsVUFDQyxPQUFPO0FBQUEsWUFDTEMsWUFBWTtBQUFBLFlBQ1pWLE9BQU9uQixPQUFPb0IsS0FBS1U7QUFBQUEsWUFDbkJDLFdBQVc7QUFBQSxVQUNiLEdBQ0Q7QUFBQTtBQUFBLFlBQ1M1QixXQUFXeUI7QUFBQUEsWUFBSztBQUFBLGVBUDFCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBUUE7QUFBQSxhQVhKO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFhQTtBQUFBLFFBQ0EsdUJBQUMsYUFBVSxJQUFJO0FBQUEsVUFBRUwsT0FBT3JCLG9CQUFvQkU7QUFBQUEsUUFBUyxHQUNsREQscUJBQVdDLFlBRGQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsUUFDQSx1QkFBQyxhQUFVLElBQUk7QUFBQSxVQUFFbUIsT0FBT3JCLG9CQUFvQkc7QUFBQUEsUUFBSyxHQUM5Q0YscUJBQVdFLFFBRGQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsV0FwQmFxQixPQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFxQkEsQ0FDRCxLQXhCSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBeUJBO0FBQUEsU0F2Q0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQXdDQSxLQXpDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBMENBO0FBQUEsSUFDQSx1QkFBQyxPQUNDO0FBQUEsNkJBQUMsY0FDQyxTQUFRLGFBQ1IsY0FBWSxNQUNaLFdBQVUsT0FDVixJQUFJO0FBQUEsUUFDRlAsT0FBT25CLE9BQU9vQixLQUFLQztBQUFBQSxRQUNuQlIsWUFBWVosV0FBV2EsWUFBWUM7QUFBQUEsTUFDckMsR0FDRCxxQkFSRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBVUE7QUFBQSxNQUNBLHVCQUFDLE9BQUksV0FBVSxNQUFLLElBQUk7QUFBQSxRQUFFaUIsSUFBSTtBQUFBLFFBQUdDLElBQUk7QUFBQSxRQUFHZCxPQUFPbkIsT0FBT29CLEtBQUtDO0FBQUFBLE1BQVEsR0FDaEVKLGlCQUFPaUIsWUFBWVQsSUFBSSxDQUFDVSxNQUFNVCxVQUM3Qix1QkFBQyxRQUFlLE9BQU87QUFBQSxRQUFFVSxjQUFjO0FBQUEsTUFBTSxHQUMxQ0Qsa0JBRE1ULE9BQVQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBLENBQ0QsS0FMSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBTUE7QUFBQSxTQWxCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBbUJBO0FBQUEsT0ExRUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQTJFQTtBQUVKO0FBQUVXLEtBakZJckI7QUFtRkMsYUFBTXNCLHdCQUF3QjlDLE1BQU0rQyxLQUN6Q3ZCLGdDQUNBLENBQUN3QixXQUFXQyxjQUFjO0FBQ3hCLFNBQU9ELFVBQVV2QixPQUFPeUIsT0FBT0QsVUFBVXhCLE9BQU95QjtBQUNsRCxDQUNGO0FBQUVDLE1BTFdMO0FBQXFCLElBQUFELElBQUFNO0FBQUFDLGFBQUFQLElBQUE7QUFBQU8sYUFBQUQsS0FBQSIsIm5hbWVzIjpbIlJlYWN0IiwiQm94IiwiVHlwb2dyYXBoeSIsIlRhYmxlIiwiVGFibGVCb2R5IiwiVGFibGVIZWFkIiwiVGFibGVSb3ciLCJUYWJsZUNlbGwiLCJDT0xPUlMiLCJUWVBPR1JBUEhZIiwiVEFCTEVfQ09MVU1OX1dJRFRIUyIsImluZ3JlZGllbnQiLCJxdWFudGl0eSIsInVuaXQiLCJ0YWJsZVN0eWxlcyIsIm1heFdpZHRoIiwiYm9yZGVyQ29sbGFwc2UiLCJmb250U2l6ZSIsImZvbnRGYW1pbHkiLCJib3JkZXJCb3R0b20iLCJib3JkZXIiLCJmb250V2VpZ2h0IiwiZm9udFdlaWdodHMiLCJzZW1pQm9sZCIsIkV4cGFuZGVkUmVjaXBlRGV0YWlsc0NvbXBvbmVudCIsInJlY2lwZSIsIm1hcmdpbiIsImNvbG9yIiwidGV4dCIsInByaW1hcnkiLCJtYiIsIndpZHRoIiwicmVjaXBlSW5ncmVkaWVudHMiLCJtYXAiLCJpbmRleCIsImluZ3JlZGllbnROYW1lIiwibm90ZSIsIm1hcmdpbkxlZnQiLCJzZWNvbmRhcnkiLCJmb250U3R5bGUiLCJtdCIsInBsIiwicmVjaXBlU3RlcHMiLCJzdGVwIiwibWFyZ2luQm90dG9tIiwiX2MiLCJFeHBhbmRlZFJlY2lwZURldGFpbHMiLCJtZW1vIiwicHJldlByb3BzIiwibmV4dFByb3BzIiwiaWQiLCJfYzIiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJFeHBhbmRlZFJlY2lwZURldGFpbHMudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBSZWFjdCBmcm9tIFwicmVhY3RcIjtcclxuaW1wb3J0IHtcclxuICBCb3gsXHJcbiAgVHlwb2dyYXBoeSxcclxuICBUYWJsZSxcclxuICBUYWJsZUJvZHksXHJcbiAgVGFibGVIZWFkLFxyXG4gIFRhYmxlUm93LFxyXG4gIFRhYmxlQ2VsbCxcclxufSBmcm9tIFwiQG11aS9tYXRlcmlhbFwiO1xyXG5pbXBvcnQgeyBSZWNpcGUgfSBmcm9tIFwiLi4vLi4vdHlwZXMvcmVjaXBlXCI7XHJcbmltcG9ydCB7IENPTE9SUywgVFlQT0dSQVBIWSB9IGZyb20gXCIuLi8uLi9zdHlsZXMvY29uc3RhbnRzXCI7XHJcblxyXG5jb25zdCBUQUJMRV9DT0xVTU5fV0lEVEhTID0ge1xyXG4gIGluZ3JlZGllbnQ6IFwiNTUlXCIsXHJcbiAgcXVhbnRpdHk6IFwiMjUlXCIsXHJcbiAgdW5pdDogXCIyMCVcIixcclxufSBhcyBjb25zdDtcclxuXHJcbmNvbnN0IHRhYmxlU3R5bGVzID0ge1xyXG4gIG1heFdpZHRoOiBcIjYwMHB4XCIsXHJcbiAgYm9yZGVyQ29sbGFwc2U6IFwiY29sbGFwc2VcIixcclxuICBcIiYgdGgsICYgdGRcIjoge1xyXG4gICAgZm9udFNpemU6IFwiMC44NzVyZW1cIixcclxuICAgIGZvbnRGYW1pbHk6IFwiaW5oZXJpdFwiLFxyXG4gICAgYm9yZGVyQm90dG9tOiBcIm5vbmVcIixcclxuICB9LFxyXG4gIFwiJiB0aGVhZCB0aFwiOiB7XHJcbiAgICBib3JkZXJCb3R0b206IGAxcHggc29saWQgJHtDT0xPUlMuYm9yZGVyfWAsXHJcbiAgICBmb250V2VpZ2h0OiBUWVBPR1JBUEhZLmZvbnRXZWlnaHRzLnNlbWlCb2xkLFxyXG4gIH0sXHJcbiAgYm9yZGVyOiBgMXB4IHNvbGlkICR7Q09MT1JTLmJvcmRlcn1gLFxyXG59O1xyXG5cclxuaW50ZXJmYWNlIEV4cGFuZGVkUmVjaXBlRGV0YWlsc1Byb3BzIHtcclxuICByZWNpcGU6IFJlY2lwZTtcclxufVxyXG5cclxuY29uc3QgRXhwYW5kZWRSZWNpcGVEZXRhaWxzQ29tcG9uZW50OiBSZWFjdC5GQzxFeHBhbmRlZFJlY2lwZURldGFpbHNQcm9wcz4gPSAoe1xyXG4gIHJlY2lwZSxcclxufSkgPT4ge1xyXG4gIHJldHVybiAoXHJcbiAgICA8Qm94IHN4PXt7IG1hcmdpbjogMiB9fT5cclxuICAgICAgPFR5cG9ncmFwaHlcclxuICAgICAgICB2YXJpYW50PVwiaDZcIlxyXG4gICAgICAgIGd1dHRlckJvdHRvbVxyXG4gICAgICAgIGNvbXBvbmVudD1cImRpdlwiXHJcbiAgICAgICAgc3g9e3tcclxuICAgICAgICAgIGNvbG9yOiBDT0xPUlMudGV4dC5wcmltYXJ5LFxyXG4gICAgICAgICAgZm9udFdlaWdodDogVFlQT0dSQVBIWS5mb250V2VpZ2h0cy5zZW1pQm9sZCxcclxuICAgICAgICB9fVxyXG4gICAgICA+XHJcbiAgICAgICAgUmVjaXBlIERldGFpbHNcclxuICAgICAgPC9UeXBvZ3JhcGh5PlxyXG4gICAgICA8Qm94IHN4PXt7IG1iOiAyIH19PlxyXG4gICAgICAgIDxUYWJsZSBzaXplPVwic21hbGxcIiBzeD17dGFibGVTdHlsZXN9PlxyXG4gICAgICAgICAgPFRhYmxlSGVhZD5cclxuICAgICAgICAgICAgPFRhYmxlUm93PlxyXG4gICAgICAgICAgICAgIDxUYWJsZUNlbGwgc3g9e3sgd2lkdGg6IFRBQkxFX0NPTFVNTl9XSURUSFMuaW5ncmVkaWVudCB9fT5cclxuICAgICAgICAgICAgICAgIEluZ3JlZGllbnRcclxuICAgICAgICAgICAgICA8L1RhYmxlQ2VsbD5cclxuICAgICAgICAgICAgICA8VGFibGVDZWxsIHN4PXt7IHdpZHRoOiBUQUJMRV9DT0xVTU5fV0lEVEhTLnF1YW50aXR5IH19PlxyXG4gICAgICAgICAgICAgICAgUXVhbnRpdHlcclxuICAgICAgICAgICAgICA8L1RhYmxlQ2VsbD5cclxuICAgICAgICAgICAgICA8VGFibGVDZWxsIHN4PXt7IHdpZHRoOiBUQUJMRV9DT0xVTU5fV0lEVEhTLnVuaXQgfX0+XHJcbiAgICAgICAgICAgICAgICBVbml0XHJcbiAgICAgICAgICAgICAgPC9UYWJsZUNlbGw+XHJcbiAgICAgICAgICAgIDwvVGFibGVSb3c+XHJcbiAgICAgICAgICA8L1RhYmxlSGVhZD5cclxuICAgICAgICAgIDxUYWJsZUJvZHk+XHJcbiAgICAgICAgICAgIHtyZWNpcGUucmVjaXBlSW5ncmVkaWVudHMubWFwKChpbmdyZWRpZW50LCBpbmRleCkgPT4gKFxyXG4gICAgICAgICAgICAgIDxUYWJsZVJvdyBrZXk9e2luZGV4fT5cclxuICAgICAgICAgICAgICAgIDxUYWJsZUNlbGwgc3g9e3sgd2lkdGg6IFRBQkxFX0NPTFVNTl9XSURUSFMuaW5ncmVkaWVudCB9fT5cclxuICAgICAgICAgICAgICAgICAge2luZ3JlZGllbnQuaW5ncmVkaWVudE5hbWV9XHJcbiAgICAgICAgICAgICAgICAgIHtpbmdyZWRpZW50Lm5vdGUgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgIDxzcGFuXHJcbiAgICAgICAgICAgICAgICAgICAgICBzdHlsZT17e1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBtYXJnaW5MZWZ0OiBcIjhweFwiLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBjb2xvcjogQ09MT1JTLnRleHQuc2Vjb25kYXJ5LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBmb250U3R5bGU6IFwiaXRhbGljXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgIChOb3RlOiB7aW5ncmVkaWVudC5ub3RlfSlcclxuICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICA8L1RhYmxlQ2VsbD5cclxuICAgICAgICAgICAgICAgIDxUYWJsZUNlbGwgc3g9e3sgd2lkdGg6IFRBQkxFX0NPTFVNTl9XSURUSFMucXVhbnRpdHkgfX0+XHJcbiAgICAgICAgICAgICAgICAgIHtpbmdyZWRpZW50LnF1YW50aXR5fVxyXG4gICAgICAgICAgICAgICAgPC9UYWJsZUNlbGw+XHJcbiAgICAgICAgICAgICAgICA8VGFibGVDZWxsIHN4PXt7IHdpZHRoOiBUQUJMRV9DT0xVTU5fV0lEVEhTLnVuaXQgfX0+XHJcbiAgICAgICAgICAgICAgICAgIHtpbmdyZWRpZW50LnVuaXR9XHJcbiAgICAgICAgICAgICAgICA8L1RhYmxlQ2VsbD5cclxuICAgICAgICAgICAgICA8L1RhYmxlUm93PlxyXG4gICAgICAgICAgICApKX1cclxuICAgICAgICAgIDwvVGFibGVCb2R5PlxyXG4gICAgICAgIDwvVGFibGU+XHJcbiAgICAgIDwvQm94PlxyXG4gICAgICA8Qm94PlxyXG4gICAgICAgIDxUeXBvZ3JhcGh5XHJcbiAgICAgICAgICB2YXJpYW50PVwic3VidGl0bGUxXCJcclxuICAgICAgICAgIGd1dHRlckJvdHRvbVxyXG4gICAgICAgICAgY29tcG9uZW50PVwiZGl2XCJcclxuICAgICAgICAgIHN4PXt7XHJcbiAgICAgICAgICAgIGNvbG9yOiBDT0xPUlMudGV4dC5wcmltYXJ5LFxyXG4gICAgICAgICAgICBmb250V2VpZ2h0OiBUWVBPR1JBUEhZLmZvbnRXZWlnaHRzLnNlbWlCb2xkLFxyXG4gICAgICAgICAgfX1cclxuICAgICAgICA+XHJcbiAgICAgICAgICBTdGVwc1xyXG4gICAgICAgIDwvVHlwb2dyYXBoeT5cclxuICAgICAgICA8Qm94IGNvbXBvbmVudD1cIm9sXCIgc3g9e3sgbXQ6IDEsIHBsOiAyLCBjb2xvcjogQ09MT1JTLnRleHQucHJpbWFyeSB9fT5cclxuICAgICAgICAgIHtyZWNpcGUucmVjaXBlU3RlcHMubWFwKChzdGVwLCBpbmRleCkgPT4gKFxyXG4gICAgICAgICAgICA8bGkga2V5PXtpbmRleH0gc3R5bGU9e3sgbWFyZ2luQm90dG9tOiBcIjhweFwiIH19PlxyXG4gICAgICAgICAgICAgIHtzdGVwfVxyXG4gICAgICAgICAgICA8L2xpPlxyXG4gICAgICAgICAgKSl9XHJcbiAgICAgICAgPC9Cb3g+XHJcbiAgICAgIDwvQm94PlxyXG4gICAgPC9Cb3g+XHJcbiAgKTtcclxufTtcclxuXHJcbmV4cG9ydCBjb25zdCBFeHBhbmRlZFJlY2lwZURldGFpbHMgPSBSZWFjdC5tZW1vKFxyXG4gIEV4cGFuZGVkUmVjaXBlRGV0YWlsc0NvbXBvbmVudCxcclxuICAocHJldlByb3BzLCBuZXh0UHJvcHMpID0+IHtcclxuICAgIHJldHVybiBwcmV2UHJvcHMucmVjaXBlLmlkID09PSBuZXh0UHJvcHMucmVjaXBlLmlkO1xyXG4gIH1cclxuKTtcclxuIl0sImZpbGUiOiJDOi9Vc2Vycy9zX21hci9jczMyL1NuYWNrU3RhY2svY2xpZW50L3NyYy9jb21wb25lbnRzL1JlY2lwZVRhYmxlUm93L0V4cGFuZGVkUmVjaXBlRGV0YWlscy50c3gifQ==