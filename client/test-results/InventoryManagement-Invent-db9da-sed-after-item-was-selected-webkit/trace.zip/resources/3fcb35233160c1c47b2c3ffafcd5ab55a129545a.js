import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/RecipeTableRow/FavoriteButton.tsx");import { jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/s_mar/cs32/SnackStack/client/src/components/RecipeTableRow/FavoriteButton.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=4d3a3d4b"; const React = __vite__cjsImport3_react.__esModule ? __vite__cjsImport3_react.default : __vite__cjsImport3_react;
import { IconButton } from "/node_modules/.vite/deps/@mui_material.js?v=4d3a3d4b";
import FavoriteIcon from "/node_modules/.vite/deps/@mui_icons-material_Favorite.js?v=4d3a3d4b";
import FavoriteBorderIcon from "/node_modules/.vite/deps/@mui_icons-material_FavoriteBorder.js?v=4d3a3d4b";
const FavoriteButtonComponent = ({
  recipe,
  onToggleFavorite
}) => {
  const handleClick = (event) => {
    event.stopPropagation();
    onToggleFavorite(recipe);
  };
  return /* @__PURE__ */ jsxDEV(IconButton, { onClick: handleClick, size: "small", sx: {
    color: recipe.isFavorite ? "#e57373" : "rgba(0, 0, 0, 0.54)"
  }, children: recipe.isFavorite ? /* @__PURE__ */ jsxDEV(FavoriteIcon, {}, void 0, false, {
    fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/components/RecipeTableRow/FavoriteButton.tsx",
    lineNumber: 21,
    columnNumber: 28
  }, this) : /* @__PURE__ */ jsxDEV(FavoriteBorderIcon, {}, void 0, false, {
    fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/components/RecipeTableRow/FavoriteButton.tsx",
    lineNumber: 21,
    columnNumber: 47
  }, this) }, void 0, false, {
    fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/components/RecipeTableRow/FavoriteButton.tsx",
    lineNumber: 18,
    columnNumber: 10
  }, this);
};
_c = FavoriteButtonComponent;
export const FavoriteButton = React.memo(FavoriteButtonComponent, (prevProps, nextProps) => {
  return prevProps.recipe.id === nextProps.recipe.id && prevProps.recipe.isFavorite === nextProps.recipe.isFavorite;
});
_c2 = FavoriteButton;
var _c, _c2;
$RefreshReg$(_c, "FavoriteButtonComponent");
$RefreshReg$(_c2, "FavoriteButton");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/s_mar/cs32/SnackStack/client/src/components/RecipeTableRow/FavoriteButton.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBMEIyQjtBQTFCM0IsT0FBT0Esb0JBQWtCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUN6QixTQUFTQyxrQkFBa0I7QUFDM0IsT0FBT0Msa0JBQWtCO0FBQ3pCLE9BQU9DLHdCQUF3QjtBQVEvQixNQUFNQywwQkFBeURBLENBQUM7QUFBQSxFQUM5REM7QUFBQUEsRUFDQUM7QUFDRixNQUFNO0FBQ0osUUFBTUMsY0FBY0EsQ0FBQ0MsVUFBNEI7QUFDL0NBLFVBQU1DLGdCQUFnQjtBQUN0QkgscUJBQWlCRCxNQUFNO0FBQUEsRUFDekI7QUFFQSxTQUNFLHVCQUFDLGNBQ0MsU0FBU0UsYUFDVCxNQUFLLFNBQ0wsSUFBSTtBQUFBLElBQUVHLE9BQU9MLE9BQU9NLGFBQWEsWUFBWTtBQUFBLEVBQXNCLEdBRWxFTixpQkFBT00sYUFBYSx1QkFBQyxrQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBQWEsSUFBTSx1QkFBQyx3QkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBQW1CLEtBTDdEO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FNQTtBQUVKO0FBQUVDLEtBbEJJUjtBQW9CQyxhQUFNUyxpQkFBaUJiLE1BQU1jLEtBQ2xDVix5QkFDQSxDQUFDVyxXQUFXQyxjQUFjO0FBQ3hCLFNBQ0VELFVBQVVWLE9BQU9ZLE9BQU9ELFVBQVVYLE9BQU9ZLE1BQ3pDRixVQUFVVixPQUFPTSxlQUFlSyxVQUFVWCxPQUFPTTtBQUVyRCxDQUNGO0FBQUVPLE1BUldMO0FBQWMsSUFBQUQsSUFBQU07QUFBQUMsYUFBQVAsSUFBQTtBQUFBTyxhQUFBRCxLQUFBIiwibmFtZXMiOlsiUmVhY3QiLCJJY29uQnV0dG9uIiwiRmF2b3JpdGVJY29uIiwiRmF2b3JpdGVCb3JkZXJJY29uIiwiRmF2b3JpdGVCdXR0b25Db21wb25lbnQiLCJyZWNpcGUiLCJvblRvZ2dsZUZhdm9yaXRlIiwiaGFuZGxlQ2xpY2siLCJldmVudCIsInN0b3BQcm9wYWdhdGlvbiIsImNvbG9yIiwiaXNGYXZvcml0ZSIsIl9jIiwiRmF2b3JpdGVCdXR0b24iLCJtZW1vIiwicHJldlByb3BzIiwibmV4dFByb3BzIiwiaWQiLCJfYzIiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJGYXZvcml0ZUJ1dHRvbi50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFJlYWN0IGZyb20gXCJyZWFjdFwiO1xyXG5pbXBvcnQgeyBJY29uQnV0dG9uIH0gZnJvbSBcIkBtdWkvbWF0ZXJpYWxcIjtcclxuaW1wb3J0IEZhdm9yaXRlSWNvbiBmcm9tIFwiQG11aS9pY29ucy1tYXRlcmlhbC9GYXZvcml0ZVwiO1xyXG5pbXBvcnQgRmF2b3JpdGVCb3JkZXJJY29uIGZyb20gXCJAbXVpL2ljb25zLW1hdGVyaWFsL0Zhdm9yaXRlQm9yZGVyXCI7XHJcbmltcG9ydCB7IFJlY2lwZSB9IGZyb20gXCIuLi8uLi90eXBlcy9yZWNpcGVcIjtcclxuXHJcbmludGVyZmFjZSBGYXZvcml0ZUJ1dHRvblByb3BzIHtcclxuICByZWNpcGU6IFJlY2lwZTtcclxuICBvblRvZ2dsZUZhdm9yaXRlOiAocmVjaXBlOiBSZWNpcGUpID0+IHZvaWQ7XHJcbn1cclxuXHJcbmNvbnN0IEZhdm9yaXRlQnV0dG9uQ29tcG9uZW50OiBSZWFjdC5GQzxGYXZvcml0ZUJ1dHRvblByb3BzPiA9ICh7XHJcbiAgcmVjaXBlLFxyXG4gIG9uVG9nZ2xlRmF2b3JpdGUsXHJcbn0pID0+IHtcclxuICBjb25zdCBoYW5kbGVDbGljayA9IChldmVudDogUmVhY3QuTW91c2VFdmVudCkgPT4ge1xyXG4gICAgZXZlbnQuc3RvcFByb3BhZ2F0aW9uKCk7XHJcbiAgICBvblRvZ2dsZUZhdm9yaXRlKHJlY2lwZSk7XHJcbiAgfTtcclxuXHJcbiAgcmV0dXJuIChcclxuICAgIDxJY29uQnV0dG9uXHJcbiAgICAgIG9uQ2xpY2s9e2hhbmRsZUNsaWNrfVxyXG4gICAgICBzaXplPVwic21hbGxcIlxyXG4gICAgICBzeD17eyBjb2xvcjogcmVjaXBlLmlzRmF2b3JpdGUgPyBcIiNlNTczNzNcIiA6IFwicmdiYSgwLCAwLCAwLCAwLjU0KVwiIH19XHJcbiAgICA+XHJcbiAgICAgIHtyZWNpcGUuaXNGYXZvcml0ZSA/IDxGYXZvcml0ZUljb24gLz4gOiA8RmF2b3JpdGVCb3JkZXJJY29uIC8+fVxyXG4gICAgPC9JY29uQnV0dG9uPlxyXG4gICk7XHJcbn07XHJcblxyXG5leHBvcnQgY29uc3QgRmF2b3JpdGVCdXR0b24gPSBSZWFjdC5tZW1vKFxyXG4gIEZhdm9yaXRlQnV0dG9uQ29tcG9uZW50LFxyXG4gIChwcmV2UHJvcHMsIG5leHRQcm9wcykgPT4ge1xyXG4gICAgcmV0dXJuIChcclxuICAgICAgcHJldlByb3BzLnJlY2lwZS5pZCA9PT0gbmV4dFByb3BzLnJlY2lwZS5pZCAmJlxyXG4gICAgICBwcmV2UHJvcHMucmVjaXBlLmlzRmF2b3JpdGUgPT09IG5leHRQcm9wcy5yZWNpcGUuaXNGYXZvcml0ZVxyXG4gICAgKTtcclxuICB9XHJcbik7XHJcbiJdLCJmaWxlIjoiQzovVXNlcnMvc19tYXIvY3MzMi9TbmFja1N0YWNrL2NsaWVudC9zcmMvY29tcG9uZW50cy9SZWNpcGVUYWJsZVJvdy9GYXZvcml0ZUJ1dHRvbi50c3gifQ==