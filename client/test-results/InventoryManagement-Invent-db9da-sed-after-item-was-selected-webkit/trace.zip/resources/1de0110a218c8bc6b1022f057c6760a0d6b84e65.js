"use client";
import "/node_modules/.vite/deps/chunk-C6WWHQR7.js?v=4d3a3d4b";
import "/node_modules/.vite/deps/chunk-JQS66VEU.js?v=4d3a3d4b";
import {
  createSvgIcon
} from "/node_modules/.vite/deps/chunk-MLPXR4TV.js?v=4d3a3d4b";
import "/node_modules/.vite/deps/chunk-JFUJMKGI.js?v=4d3a3d4b";
import "/node_modules/.vite/deps/chunk-NTONOVYZ.js?v=4d3a3d4b";
import "/node_modules/.vite/deps/chunk-ZZNIRIXO.js?v=4d3a3d4b";
import "/node_modules/.vite/deps/chunk-TSMFREGN.js?v=4d3a3d4b";
import "/node_modules/.vite/deps/chunk-64FVIM6J.js?v=4d3a3d4b";
import {
  require_jsx_runtime
} from "/node_modules/.vite/deps/chunk-TOXUORXJ.js?v=4d3a3d4b";
import "/node_modules/.vite/deps/chunk-K5YNGTCN.js?v=4d3a3d4b";
import {
  __toESM
} from "/node_modules/.vite/deps/chunk-ZC22LKFR.js?v=4d3a3d4b";

// node_modules/@mui/icons-material/esm/Description.js
var import_jsx_runtime = __toESM(require_jsx_runtime());
var Description_default = createSvgIcon((0, import_jsx_runtime.jsx)("path", {
  d: "M14 2H6c-1.1 0-1.99.9-1.99 2L4 20c0 1.1.89 2 1.99 2H18c1.1 0 2-.9 2-2V8zm2 16H8v-2h8zm0-4H8v-2h8zm-3-5V3.5L18.5 9z"
}), "Description");
export {
  Description_default as default
};
//# sourceMappingURL=@mui_icons-material_Description.js.map
