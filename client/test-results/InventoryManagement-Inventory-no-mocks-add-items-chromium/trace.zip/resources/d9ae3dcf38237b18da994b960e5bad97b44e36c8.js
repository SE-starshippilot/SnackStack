"use client";
import "/node_modules/.vite/deps/chunk-C6WWHQR7.js?v=4d3a3d4b";
import "/node_modules/.vite/deps/chunk-JQS66VEU.js?v=4d3a3d4b";
import {
  createSvgIcon
} from "/node_modules/.vite/deps/chunk-MLPXR4TV.js?v=4d3a3d4b";
import "/node_modules/.vite/deps/chunk-JFUJMKGI.js?v=4d3a3d4b";
import "/node_modules/.vite/deps/chunk-NTONOVYZ.js?v=4d3a3d4b";
import "/node_modules/.vite/deps/chunk-ZZNIRIXO.js?v=4d3a3d4b";
import "/node_modules/.vite/deps/chunk-TSMFREGN.js?v=4d3a3d4b";
import "/node_modules/.vite/deps/chunk-64FVIM6J.js?v=4d3a3d4b";
import {
  require_jsx_runtime
} from "/node_modules/.vite/deps/chunk-TOXUORXJ.js?v=4d3a3d4b";
import "/node_modules/.vite/deps/chunk-K5YNGTCN.js?v=4d3a3d4b";
import {
  __toESM
} from "/node_modules/.vite/deps/chunk-ZC22LKFR.js?v=4d3a3d4b";

// node_modules/@mui/icons-material/esm/ExpandMore.js
var import_jsx_runtime = __toESM(require_jsx_runtime());
var ExpandMore_default = createSvgIcon((0, import_jsx_runtime.jsx)("path", {
  d: "M16.59 8.59 12 13.17 7.41 8.59 6 10l6 6 6-6z"
}), "ExpandMore");
export {
  ExpandMore_default as default
};
//# sourceMappingURL=@mui_icons-material_ExpandMore.js.map
