import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/Footer.tsx");import { jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/s_mar/cs32/SnackStack/client/src/components/Footer.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import "/src/styles/Home.css";
export const Footer = () => /* @__PURE__ */ jsxDEV("footer", { className: "footer", children: /* @__PURE__ */ jsxDEV("div", { className: "footer-content", children: /* @__PURE__ */ jsxDEV("p", { children: "© 2025 Snack Stack. All rights reserved." }, void 0, false, {
  fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/components/Footer.tsx",
  lineNumber: 4,
  columnNumber: 7
}, this) }, void 0, false, {
  fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/components/Footer.tsx",
  lineNumber: 3,
  columnNumber: 5
}, this) }, void 0, false, {
  fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/components/Footer.tsx",
  lineNumber: 2,
  columnNumber: 29
}, this);
_c = Footer;
var _c;
$RefreshReg$(_c, "Footer");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/s_mar/cs32/SnackStack/client/src/components/Footer.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBS007QUFMTixPQUFPLG9CQUFvQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFFcEIsYUFBTUEsU0FBU0EsTUFDcEIsdUJBQUMsWUFBTyxXQUFVLFVBQ2hCLGlDQUFDLFNBQUksV0FBVSxrQkFDYixpQ0FBQyxPQUFFLHdEQUFIO0FBQUE7QUFBQTtBQUFBO0FBQUEsT0FBMkMsS0FEN0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxPQUVBLEtBSEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxPQUlBO0FBQ0FDLEtBTldEO0FBQU0sSUFBQUM7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbIkZvb3RlciIsIl9jIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiRm9vdGVyLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgXCIuLi9zdHlsZXMvSG9tZS5jc3NcIjtcclxuXHJcbmV4cG9ydCBjb25zdCBGb290ZXIgPSAoKSA9PiAoXHJcbiAgPGZvb3RlciBjbGFzc05hbWU9XCJmb290ZXJcIj5cclxuICAgIDxkaXYgY2xhc3NOYW1lPVwiZm9vdGVyLWNvbnRlbnRcIj5cclxuICAgICAgPHA+wqkgMjAyNSBTbmFjayBTdGFjay4gQWxsIHJpZ2h0cyByZXNlcnZlZC48L3A+XHJcbiAgICA8L2Rpdj5cclxuICA8L2Zvb3Rlcj5cclxuKTtcclxuIl0sImZpbGUiOiJDOi9Vc2Vycy9zX21hci9jczMyL1NuYWNrU3RhY2svY2xpZW50L3NyYy9jb21wb25lbnRzL0Zvb3Rlci50c3gifQ==