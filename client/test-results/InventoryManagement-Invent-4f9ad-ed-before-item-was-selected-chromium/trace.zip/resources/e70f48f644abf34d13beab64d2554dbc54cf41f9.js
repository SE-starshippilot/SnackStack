import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/ProtectedRoute.tsx");import { Fragment, jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/s_mar/cs32/SnackStack/client/src/components/ProtectedRoute.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=4d3a3d4b"; const useState = __vite__cjsImport3_react["useState"]; const useEffect = __vite__cjsImport3_react["useEffect"];
import { useLocation } from "/node_modules/.vite/deps/react-router-dom.js?v=4d3a3d4b";
import { useUser } from "/node_modules/.vite/deps/@clerk_clerk-react.js?v=4d3a3d4b";
import { useUserContext } from "/src/contexts/UserContext.tsx";
import { useProfileCheck } from "/src/hooks/useProfileCheck.ts";
import LoginPromptModal from "/src/components/LoginPromptModal.tsx";
import { Navigate } from "/node_modules/.vite/deps/react-router-dom.js?v=4d3a3d4b";
export default function ProtectedRoute({
  children,
  requireLogin = true,
  loginMessage
}) {
  _s();
  const {
    isLoaded,
    isSignedIn
  } = useUser();
  const {
    isProfileComplete
  } = useUserContext();
  const location = useLocation();
  const [showLoginPrompt, setShowLoginPrompt] = useState(false);
  useProfileCheck();
  useEffect(() => {
    if (isLoaded && !isSignedIn && requireLogin) {
      setShowLoginPrompt(true);
    }
  }, [isLoaded, isSignedIn, requireLogin]);
  if (!isLoaded) {
    return /* @__PURE__ */ jsxDEV("div", { children: "Loading..." }, void 0, false, {
      fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/components/ProtectedRoute.tsx",
      lineNumber: 40,
      columnNumber: 12
    }, this);
  }
  if (!isSignedIn && requireLogin) {
    return /* @__PURE__ */ jsxDEV(LoginPromptModal, { open: showLoginPrompt, onClose: () => setShowLoginPrompt(false), message: loginMessage, returnTo: location.pathname }, void 0, false, {
      fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/components/ProtectedRoute.tsx",
      lineNumber: 44,
      columnNumber: 12
    }, this);
  }
  if (isSignedIn && !isProfileComplete) {
    return /* @__PURE__ */ jsxDEV(Navigate, { to: "/complete-profile", replace: true }, void 0, false, {
      fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/components/ProtectedRoute.tsx",
      lineNumber: 47,
      columnNumber: 12
    }, this);
  }
  return /* @__PURE__ */ jsxDEV(Fragment, { children }, void 0, false, {
    fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/components/ProtectedRoute.tsx",
    lineNumber: 49,
    columnNumber: 10
  }, this);
}
_s(ProtectedRoute, "m6C8+OY1aO+Lsi50oLOggngjMxQ=", false, function() {
  return [useUser, useUserContext, useLocation, useProfileCheck];
});
_c = ProtectedRoute;
var _c;
$RefreshReg$(_c, "ProtectedRoute");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/s_mar/cs32/SnackStack/client/src/components/ProtectedRoute.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBbUNXLFNBbUJGLFVBbkJFOzs7Ozs7Ozs7Ozs7Ozs7O0FBbkNYLFNBQVNBLFVBQVVDLGlCQUFpQjtBQUNwQyxTQUFTQyxtQkFBbUI7QUFDNUIsU0FBU0MsZUFBZTtBQUN4QixTQUFTQyxzQkFBc0I7QUFDL0IsU0FBU0MsdUJBQXVCO0FBQ2hDLE9BQU9DLHNCQUFzQjtBQUM3QixTQUFTQyxnQkFBZ0I7QUFRekIsd0JBQXdCQyxlQUFlO0FBQUEsRUFDckNDO0FBQUFBLEVBQ0FDLGVBQWU7QUFBQSxFQUNmQztBQUNtQixHQUFHO0FBQUFDLEtBQUE7QUFDdEIsUUFBTTtBQUFBLElBQUVDO0FBQUFBLElBQVVDO0FBQUFBLEVBQVcsSUFBSVgsUUFBUTtBQUN6QyxRQUFNO0FBQUEsSUFBRVk7QUFBQUEsRUFBa0IsSUFBSVgsZUFBZTtBQUM3QyxRQUFNWSxXQUFXZCxZQUFZO0FBQzdCLFFBQU0sQ0FBQ2UsaUJBQWlCQyxrQkFBa0IsSUFBSWxCLFNBQVMsS0FBSztBQUc1REssa0JBQWdCO0FBR2hCSixZQUFVLE1BQU07QUFDZCxRQUFJWSxZQUFZLENBQUNDLGNBQWNKLGNBQWM7QUFDM0NRLHlCQUFtQixJQUFJO0FBQUEsSUFDekI7QUFBQSxFQUNGLEdBQUcsQ0FBQ0wsVUFBVUMsWUFBWUosWUFBWSxDQUFDO0FBRXZDLE1BQUksQ0FBQ0csVUFBVTtBQUNiLFdBQU8sdUJBQUMsU0FBSSwwQkFBTDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQWU7QUFBQSxFQUN4QjtBQUVBLE1BQUksQ0FBQ0MsY0FBY0osY0FBYztBQUUvQixXQUNFLHVCQUFDLG9CQUNDLE1BQU1PLGlCQUNOLFNBQVMsTUFBTUMsbUJBQW1CLEtBQUssR0FDdkMsU0FBU1AsY0FDVCxVQUFVSyxTQUFTRyxZQUpyQjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBSThCO0FBQUEsRUFHbEM7QUFFQSxNQUFJTCxjQUFjLENBQUNDLG1CQUFtQjtBQUNwQyxXQUFPLHVCQUFDLFlBQVMsSUFBRyxxQkFBb0IsU0FBTyxRQUF4QztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQXdDO0FBQUEsRUFDakQ7QUFFQSxTQUFPLG1DQUFHTixZQUFIO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FBWTtBQUNyQjtBQUFDRyxHQXpDdUJKLGdCQUFjO0FBQUEsVUFLSEwsU0FDSEMsZ0JBQ2JGLGFBSWpCRyxlQUFlO0FBQUE7QUFBQWUsS0FYT1o7QUFBYyxJQUFBWTtBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsidXNlU3RhdGUiLCJ1c2VFZmZlY3QiLCJ1c2VMb2NhdGlvbiIsInVzZVVzZXIiLCJ1c2VVc2VyQ29udGV4dCIsInVzZVByb2ZpbGVDaGVjayIsIkxvZ2luUHJvbXB0TW9kYWwiLCJOYXZpZ2F0ZSIsIlByb3RlY3RlZFJvdXRlIiwiY2hpbGRyZW4iLCJyZXF1aXJlTG9naW4iLCJsb2dpbk1lc3NhZ2UiLCJfcyIsImlzTG9hZGVkIiwiaXNTaWduZWRJbiIsImlzUHJvZmlsZUNvbXBsZXRlIiwibG9jYXRpb24iLCJzaG93TG9naW5Qcm9tcHQiLCJzZXRTaG93TG9naW5Qcm9tcHQiLCJwYXRobmFtZSIsIl9jIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiUHJvdGVjdGVkUm91dGUudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZVN0YXRlLCB1c2VFZmZlY3QgfSBmcm9tIFwicmVhY3RcIjtcclxuaW1wb3J0IHsgdXNlTG9jYXRpb24gfSBmcm9tIFwicmVhY3Qtcm91dGVyLWRvbVwiO1xyXG5pbXBvcnQgeyB1c2VVc2VyIH0gZnJvbSBcIkBjbGVyay9jbGVyay1yZWFjdFwiO1xyXG5pbXBvcnQgeyB1c2VVc2VyQ29udGV4dCB9IGZyb20gXCIuLi9jb250ZXh0cy9Vc2VyQ29udGV4dFwiO1xyXG5pbXBvcnQgeyB1c2VQcm9maWxlQ2hlY2sgfSBmcm9tIFwiLi4vaG9va3MvdXNlUHJvZmlsZUNoZWNrXCI7XHJcbmltcG9ydCBMb2dpblByb21wdE1vZGFsIGZyb20gXCIuL0xvZ2luUHJvbXB0TW9kYWxcIjtcclxuaW1wb3J0IHsgTmF2aWdhdGUgfSBmcm9tIFwicmVhY3Qtcm91dGVyLWRvbVwiO1xyXG5cclxuaW50ZXJmYWNlIFByb3RlY3RlZFJvdXRlUHJvcHMge1xyXG4gIGNoaWxkcmVuOiBSZWFjdC5SZWFjdE5vZGU7XHJcbiAgcmVxdWlyZUxvZ2luPzogYm9vbGVhbjtcclxuICBsb2dpbk1lc3NhZ2U/OiBzdHJpbmc7XHJcbn1cclxuXHJcbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIFByb3RlY3RlZFJvdXRlKHsgXHJcbiAgY2hpbGRyZW4sIFxyXG4gIHJlcXVpcmVMb2dpbiA9IHRydWUsXHJcbiAgbG9naW5NZXNzYWdlXHJcbn06IFByb3RlY3RlZFJvdXRlUHJvcHMpIHtcclxuICBjb25zdCB7IGlzTG9hZGVkLCBpc1NpZ25lZEluIH0gPSB1c2VVc2VyKCk7XHJcbiAgY29uc3QgeyBpc1Byb2ZpbGVDb21wbGV0ZSB9ID0gdXNlVXNlckNvbnRleHQoKTtcclxuICBjb25zdCBsb2NhdGlvbiA9IHVzZUxvY2F0aW9uKCk7XHJcbiAgY29uc3QgW3Nob3dMb2dpblByb21wdCwgc2V0U2hvd0xvZ2luUHJvbXB0XSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICBcclxuICAvLyBVc2UgdGhlIGhvb2sgdG8gY2hlY2sgcHJvZmlsZVxyXG4gIHVzZVByb2ZpbGVDaGVjaygpO1xyXG5cclxuICAvLyBTaG93IGxvZ2luIHByb21wdCB3aGVuIHVzZXIgaXMgbm90IHNpZ25lZCBpblxyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBpZiAoaXNMb2FkZWQgJiYgIWlzU2lnbmVkSW4gJiYgcmVxdWlyZUxvZ2luKSB7XHJcbiAgICAgIHNldFNob3dMb2dpblByb21wdCh0cnVlKTtcclxuICAgIH1cclxuICB9LCBbaXNMb2FkZWQsIGlzU2lnbmVkSW4sIHJlcXVpcmVMb2dpbl0pO1xyXG5cclxuICBpZiAoIWlzTG9hZGVkKSB7XHJcbiAgICByZXR1cm4gPGRpdj5Mb2FkaW5nLi4uPC9kaXY+O1xyXG4gIH1cclxuXHJcbiAgaWYgKCFpc1NpZ25lZEluICYmIHJlcXVpcmVMb2dpbikge1xyXG4gICAgLy8gUmV0dXJuIHRoZSBsb2dpbiBwcm9tcHQgbW9kYWwgaW5zdGVhZCBvZiByZWRpcmVjdGluZ1xyXG4gICAgcmV0dXJuIChcclxuICAgICAgPExvZ2luUHJvbXB0TW9kYWxcclxuICAgICAgICBvcGVuPXtzaG93TG9naW5Qcm9tcHR9XHJcbiAgICAgICAgb25DbG9zZT17KCkgPT4gc2V0U2hvd0xvZ2luUHJvbXB0KGZhbHNlKX1cclxuICAgICAgICBtZXNzYWdlPXtsb2dpbk1lc3NhZ2V9XHJcbiAgICAgICAgcmV0dXJuVG89e2xvY2F0aW9uLnBhdGhuYW1lfVxyXG4gICAgICAvPlxyXG4gICAgKTtcclxuICB9XHJcblxyXG4gIGlmIChpc1NpZ25lZEluICYmICFpc1Byb2ZpbGVDb21wbGV0ZSkge1xyXG4gICAgcmV0dXJuIDxOYXZpZ2F0ZSB0bz1cIi9jb21wbGV0ZS1wcm9maWxlXCIgcmVwbGFjZSAvPjtcclxuICB9XHJcblxyXG4gIHJldHVybiA8PntjaGlsZHJlbn08Lz47XHJcbn0iXSwiZmlsZSI6IkM6L1VzZXJzL3NfbWFyL2NzMzIvU25hY2tTdGFjay9jbGllbnQvc3JjL2NvbXBvbmVudHMvUHJvdGVjdGVkUm91dGUudHN4In0=