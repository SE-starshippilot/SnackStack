import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/RecipeGeneration.tsx");import { jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/s_mar/cs32/SnackStack/client/src/pages/RecipeGeneration.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import { Box, Button, Chip, CircularProgress, Container, Slider, TextField, Typography } from "/node_modules/.vite/deps/@mui_material.js?v=4d3a3d4b";
import { styled } from "/node_modules/.vite/deps/@mui_material_styles.js?v=4d3a3d4b";
import __vite__cjsImport5_react from "/node_modules/.vite/deps/react.js?v=4d3a3d4b"; const useState = __vite__cjsImport5_react["useState"];
import "/src/styles/RecipeGeneration.css";
import { useNavigate } from "/node_modules/.vite/deps/react-router-dom.js?v=4d3a3d4b";
import { useUserContext } from "/src/contexts/UserContext.tsx";
import axios from "/node_modules/.vite/deps/axios.js?v=4d3a3d4b";
const recipeTypes = [{
  id: "MAIN",
  label: "Main"
}, {
  id: "APPETIZER",
  label: "Appetizer"
}, {
  id: "DESSERT",
  label: "Dessert"
}, {
  id: "BREAKFAST",
  label: "Breakfast"
}, {
  id: "SNACK",
  label: "Snack"
}];
const defaultPreferences = ["American", "Italian", "Chinese", "Mexican", "Japanese", "Indian", "Middle Eastern", "Thai"];
const defaultAllergies = ["Gluten", "Dairy", "Nuts", "Eggs", "Soy", "Shellfish"];
const PrettoSlider = styled(Slider)({
  color: "#52af77",
  height: 8,
  maxWidth: 300,
  "& .MuiSlider-track": {
    border: "none"
  },
  "& .MuiSlider-thumb": {
    height: 24,
    width: 24,
    backgroundColor: "#fff",
    border: "2px solid currentColor",
    "&:focus, &:hover, &.Mui-active, &.Mui-focusVisible": {
      boxShadow: "inherit"
    },
    "&::before": {
      display: "none"
    }
  },
  "& .MuiSlider-valueLabel": {
    lineHeight: 1.2,
    fontSize: 12,
    background: "unset",
    padding: 0,
    width: 32,
    height: 32,
    borderRadius: "50% 50% 50% 0",
    backgroundColor: "#52af77",
    transformOrigin: "bottom left",
    transform: "translate(50%, -100%) rotate(-45deg) scale(0)",
    "&::before": {
      display: "none"
    },
    "&.MuiSlider-valueLabelOpen": {
      transform: "translate(50%, -100%) rotate(-45deg) scale(1)"
    },
    "& > *": {
      transform: "rotate(45deg)"
    }
  }
});
_c = PrettoSlider;
function RecipeGeneration() {
  _s();
  const {
    dbUserId
  } = useUserContext();
  const navigate = useNavigate();
  const [isLoading, setIsLoading] = useState(false);
  const [formData, setFormData] = useState({
    servings: 1,
    recipeType: "",
    notes: ""
  });
  const [errors, setErrors] = useState({
    servings: false,
    recipeType: false
  });
  const [preferences, setPreferences] = useState([]);
  const [preferenceOptions, setPreferenceOptions] = useState([...defaultPreferences]);
  const [customPreferences, setCustomPreferences] = useState([]);
  const [preferenceInput, setPreferenceInput] = useState("");
  const [allergies, setAllergies] = useState([]);
  const [allergyOptions, setAllergyOptions] = useState([...defaultAllergies]);
  const [customAllergies, setCustomAllergies] = useState([]);
  const [allergyInput, setAllergyInput] = useState("");
  const handleChipToggle = (value, list, setList) => {
    setList((prev) => prev.includes(value) ? prev.filter((v) => v !== value) : [...prev, value]);
  };
  const handleAddChip = (value, options, setOptions, custom, setCustom, selected, setSelected, setInput) => {
    const trimmed = value.trim();
    if (trimmed && !options.includes(trimmed) && !custom.includes(trimmed)) {
      setOptions((prev) => [...prev, trimmed]);
      setCustom((prev) => [...prev, trimmed]);
      setSelected((prev) => [...prev, trimmed]);
      setInput("");
    }
  };
  const handleDeleteCustom = (item, setOptions, setSelected, setCustom) => {
    setOptions((prev) => prev.filter((v) => v !== item));
    setSelected((prev) => prev.filter((v) => v !== item));
    setCustom((prev) => prev.filter((v) => v !== item));
  };
  const handleSubmit = async (e) => {
    e.preventDefault();
    const newErrors = {
      servings: formData.servings < 1,
      recipeType: !formData.recipeType
    };
    setErrors(newErrors);
    if (newErrors.servings || newErrors.recipeType)
      return;
    if (!dbUserId) {
      alert("Please sign in first.");
      return;
    }
    setIsLoading(true);
    try {
      const payload = {
        servings: formData.servings,
        recipeType: formData.recipeType,
        mealOrigin: preferences,
        allergies,
        notes: formData.notes
      };
      const {
        data
      } = await axios.post(`http://localhost:8080/api/recipes/user/${dbUserId}`, payload, {
        headers: {
          "Content-Type": "application/json"
        }
      });
      navigate("/recipes", {
        state: {
          recipes: data
        }
      });
    } catch (err) {
      console.error(err);
      alert(err?.response?.data?.message ?? "Something went wrong while generating recipes.");
    } finally {
      setIsLoading(false);
    }
  };
  return /* @__PURE__ */ jsxDEV(Container, { maxWidth: "md", sx: {
    width: "900px",
    px: {
      xs: 2,
      sm: 3,
      md: 4
    }
  }, children: /* @__PURE__ */ jsxDEV(Box, { width: "100%", children: [
    /* @__PURE__ */ jsxDEV(Typography, { variant: "h5", fontWeight: 600, textAlign: "center", gutterBottom: true, children: "Generate Your Perfect Recipe" }, void 0, false, {
      fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/pages/RecipeGeneration.tsx",
      lineNumber: 162,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV(Typography, { variant: "body2", textAlign: "center", color: "text.secondary", mb: 2, children: "Based on your preferences, dietary needs, and available ingredients." }, void 0, false, {
      fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/pages/RecipeGeneration.tsx",
      lineNumber: 165,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV("form", { onSubmit: handleSubmit, className: "form-container", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "form-section", children: [
        /* @__PURE__ */ jsxDEV(Typography, { variant: "subtitle1", fontWeight: 600, children: [
          "How many servings? ",
          /* @__PURE__ */ jsxDEV("span", { className: "required", children: "*" }, void 0, false, {
            fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/pages/RecipeGeneration.tsx",
            lineNumber: 172,
            columnNumber: 34
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/pages/RecipeGeneration.tsx",
          lineNumber: 171,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV(Box, { display: "flex", alignItems: "center", gap: 2, children: [
          /* @__PURE__ */ jsxDEV(PrettoSlider, { value: formData.servings, onChange: (_, val) => setFormData((prev) => ({
            ...prev,
            servings: val
          })), valueLabelDisplay: "auto", defaultValue: 1, min: 0, max: 10, color: errors.servings ? "error" : "success" }, void 0, false, {
            fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/pages/RecipeGeneration.tsx",
            lineNumber: 175,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV(Typography, { "data-testid": "serving-value", children: formData.servings }, void 0, false, {
            fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/pages/RecipeGeneration.tsx",
            lineNumber: 179,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/pages/RecipeGeneration.tsx",
          lineNumber: 174,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/pages/RecipeGeneration.tsx",
        lineNumber: 170,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "form-section", children: [
        /* @__PURE__ */ jsxDEV(Typography, { variant: "subtitle1", fontWeight: 600, children: [
          "What kind of meal? ",
          /* @__PURE__ */ jsxDEV("span", { className: "required", children: "*" }, void 0, false, {
            fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/pages/RecipeGeneration.tsx",
            lineNumber: 187,
            columnNumber: 34
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/pages/RecipeGeneration.tsx",
          lineNumber: 186,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV(Box, { display: "flex", gap: 1, flexWrap: "wrap", children: recipeTypes.map((type) => /* @__PURE__ */ jsxDEV(Chip, { className: "custom-chip", label: type.label, variant: formData.recipeType === type.id ? "filled" : "outlined", color: formData.recipeType === type.id ? "success" : "default", onClick: () => setFormData((prev) => ({
          ...prev,
          recipeType: type.id
        })) }, type.id, false, {
          fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/pages/RecipeGeneration.tsx",
          lineNumber: 190,
          columnNumber: 40
        }, this)) }, void 0, false, {
          fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/pages/RecipeGeneration.tsx",
          lineNumber: 189,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/pages/RecipeGeneration.tsx",
        lineNumber: 185,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "form-section", children: [
        /* @__PURE__ */ jsxDEV(Typography, { variant: "subtitle1", fontWeight: 600, children: "Preferences" }, void 0, false, {
          fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/pages/RecipeGeneration.tsx",
          lineNumber: 198,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV(Box, { className: "chip-row", children: preferenceOptions.map((pref) => /* @__PURE__ */ jsxDEV(Chip, { className: "custom-chip", label: pref, variant: preferences.includes(pref) ? "filled" : "outlined", color: preferences.includes(pref) ? "success" : void 0, onClick: () => handleChipToggle(pref, preferences, setPreferences), onDelete: customPreferences.includes(pref) ? () => handleDeleteCustom(pref, setPreferenceOptions, setCustomPreferences, setPreferences) : void 0 }, pref, false, {
          fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/pages/RecipeGeneration.tsx",
          lineNumber: 202,
          columnNumber: 46
        }, this)) }, void 0, false, {
          fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/pages/RecipeGeneration.tsx",
          lineNumber: 201,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV(Box, { display: "flex", gap: 1, sx: {
          height: 40,
          alignItems: "center"
        }, children: [
          /* @__PURE__ */ jsxDEV(TextField, { label: "Add Preference", size: "small", value: preferenceInput, color: "success", focused: true, onChange: (e) => setPreferenceInput(e.target.value) }, void 0, false, {
            fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/pages/RecipeGeneration.tsx",
            lineNumber: 208,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV(Button, { variant: "outlined", color: "success", "aria-label": "add-preference", onClick: () => handleAddChip(preferenceInput, preferenceOptions, setPreferenceOptions, customPreferences, setCustomPreferences, preferences, setPreferences, setPreferenceInput), children: "Add" }, void 0, false, {
            fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/pages/RecipeGeneration.tsx",
            lineNumber: 209,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/pages/RecipeGeneration.tsx",
          lineNumber: 204,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/pages/RecipeGeneration.tsx",
        lineNumber: 197,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "form-section", children: [
        /* @__PURE__ */ jsxDEV(Typography, { variant: "subtitle1", fontWeight: 600, children: "Allergies" }, void 0, false, {
          fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/pages/RecipeGeneration.tsx",
          lineNumber: 216,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV(Box, { className: "chip-row", children: allergyOptions.map((allergy) => /* @__PURE__ */ jsxDEV(Chip, { className: "custom-chip", label: allergy, variant: allergies.includes(allergy) ? "filled" : "outlined", color: allergies.includes(allergy) ? "success" : void 0, onClick: () => handleChipToggle(allergy, allergies, setAllergies), onDelete: customAllergies.includes(allergy) ? () => handleDeleteCustom(allergy, setAllergyOptions, setCustomAllergies, setAllergies) : void 0 }, allergy, false, {
          fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/pages/RecipeGeneration.tsx",
          lineNumber: 220,
          columnNumber: 46
        }, this)) }, void 0, false, {
          fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/pages/RecipeGeneration.tsx",
          lineNumber: 219,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV(Box, { display: "flex", gap: 1, mt: 1, children: [
          /* @__PURE__ */ jsxDEV(TextField, { label: "Add Allergy", size: "small", focused: true, color: "success", value: allergyInput, onChange: (e) => setAllergyInput(e.target.value) }, void 0, false, {
            fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/pages/RecipeGeneration.tsx",
            lineNumber: 223,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV(Button, { variant: "outlined", color: "success", "aria-label": "add-allergy", onClick: () => handleAddChip(allergyInput, allergyOptions, setAllergyOptions, customAllergies, setCustomAllergies, allergies, setAllergies, setAllergyInput), children: "Add" }, void 0, false, {
            fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/pages/RecipeGeneration.tsx",
            lineNumber: 224,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/pages/RecipeGeneration.tsx",
          lineNumber: 222,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/pages/RecipeGeneration.tsx",
        lineNumber: 215,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "form-section", children: [
        /* @__PURE__ */ jsxDEV(Typography, { variant: "subtitle1", fontWeight: 600, children: "Notes (Optional)" }, void 0, false, {
          fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/pages/RecipeGeneration.tsx",
          lineNumber: 231,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV(TextField, { multiline: true, rows: 3, placeholder: "Any specific preferences or instructions?", fullWidth: true, color: "success", value: formData.notes, onChange: (e) => setFormData({
          ...formData,
          notes: e.target.value
        }) }, void 0, false, {
          fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/pages/RecipeGeneration.tsx",
          lineNumber: 234,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/pages/RecipeGeneration.tsx",
        lineNumber: 230,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV(Box, { textAlign: "center", mt: 4, children: /* @__PURE__ */ jsxDEV(Button, { type: "submit", variant: "contained", color: "success", sx: {
        px: 4,
        py: 1.5,
        fontWeight: 500
      }, disabled: isLoading, children: isLoading ? /* @__PURE__ */ jsxDEV(CircularProgress, { size: 24, sx: {
        color: "#fff"
      } }, void 0, false, {
        fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/pages/RecipeGeneration.tsx",
        lineNumber: 246,
        columnNumber: 28
      }, this) : "Generate Recipe" }, void 0, false, {
        fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/pages/RecipeGeneration.tsx",
        lineNumber: 241,
        columnNumber: 13
      }, this) }, void 0, false, {
        fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/pages/RecipeGeneration.tsx",
        lineNumber: 240,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/pages/RecipeGeneration.tsx",
      lineNumber: 169,
      columnNumber: 9
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/pages/RecipeGeneration.tsx",
    lineNumber: 161,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/pages/RecipeGeneration.tsx",
    lineNumber: 153,
    columnNumber: 10
  }, this);
}
_s(RecipeGeneration, "zjjxfwQUUYEyzUeBu5Rc39MlL0E=", false, function() {
  return [useUserContext, useNavigate];
});
_c2 = RecipeGeneration;
export default RecipeGeneration;
var _c, _c2;
$RefreshReg$(_c, "PrettoSlider");
$RefreshReg$(_c2, "RecipeGeneration");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/s_mar/cs32/SnackStack/client/src/pages/RecipeGeneration.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBc01ROzs7Ozs7Ozs7Ozs7Ozs7O0FBdE1SLFNBQ0VBLEtBQ0FDLFFBQ0FDLE1BQ0FDLGtCQUNBQyxXQUNBQyxRQUNBQyxXQUNBQyxrQkFDSztBQUNQLFNBQVNDLGNBQWM7QUFDdkIsU0FBZ0JDLGdCQUFnQjtBQUNoQyxPQUFPO0FBQ1AsU0FBU0MsbUJBQW1CO0FBQzVCLFNBQVNDLHNCQUFzQjtBQUUvQixPQUFPQyxXQUFXO0FBRWxCLE1BQU1DLGNBQWMsQ0FDbEI7QUFBQSxFQUFFQyxJQUFJO0FBQUEsRUFBUUMsT0FBTztBQUFPLEdBQzVCO0FBQUEsRUFBRUQsSUFBSTtBQUFBLEVBQWFDLE9BQU87QUFBWSxHQUN0QztBQUFBLEVBQUVELElBQUk7QUFBQSxFQUFXQyxPQUFPO0FBQVUsR0FDbEM7QUFBQSxFQUFFRCxJQUFJO0FBQUEsRUFBYUMsT0FBTztBQUFZLEdBQ3RDO0FBQUEsRUFBRUQsSUFBSTtBQUFBLEVBQVNDLE9BQU87QUFBUSxDQUFDO0FBR2pDLE1BQU1DLHFCQUFxQixDQUN6QixZQUNBLFdBQ0EsV0FDQSxXQUNBLFlBQ0EsVUFDQSxrQkFDQSxNQUFNO0FBR1IsTUFBTUMsbUJBQW1CLENBQ3ZCLFVBQ0EsU0FDQSxRQUNBLFFBQ0EsT0FDQSxXQUFXO0FBR2IsTUFBTUMsZUFBZVYsT0FBT0gsTUFBTSxFQUFFO0FBQUEsRUFDbENjLE9BQU87QUFBQSxFQUNQQyxRQUFRO0FBQUEsRUFDUkMsVUFBVTtBQUFBLEVBQ1Ysc0JBQXNCO0FBQUEsSUFBRUMsUUFBUTtBQUFBLEVBQU87QUFBQSxFQUN2QyxzQkFBc0I7QUFBQSxJQUNwQkYsUUFBUTtBQUFBLElBQ1JHLE9BQU87QUFBQSxJQUNQQyxpQkFBaUI7QUFBQSxJQUNqQkYsUUFBUTtBQUFBLElBQ1Isc0RBQXNEO0FBQUEsTUFDcERHLFdBQVc7QUFBQSxJQUNiO0FBQUEsSUFDQSxhQUFhO0FBQUEsTUFBRUMsU0FBUztBQUFBLElBQU87QUFBQSxFQUNqQztBQUFBLEVBQ0EsMkJBQTJCO0FBQUEsSUFDekJDLFlBQVk7QUFBQSxJQUNaQyxVQUFVO0FBQUEsSUFDVkMsWUFBWTtBQUFBLElBQ1pDLFNBQVM7QUFBQSxJQUNUUCxPQUFPO0FBQUEsSUFDUEgsUUFBUTtBQUFBLElBQ1JXLGNBQWM7QUFBQSxJQUNkUCxpQkFBaUI7QUFBQSxJQUNqQlEsaUJBQWlCO0FBQUEsSUFDakJDLFdBQVc7QUFBQSxJQUNYLGFBQWE7QUFBQSxNQUFFUCxTQUFTO0FBQUEsSUFBTztBQUFBLElBQy9CLDhCQUE4QjtBQUFBLE1BQzVCTyxXQUFXO0FBQUEsSUFDYjtBQUFBLElBQ0EsU0FBUztBQUFBLE1BQ1BBLFdBQVc7QUFBQSxJQUNiO0FBQUEsRUFDRjtBQUNGLENBQUM7QUFBRUMsS0FsQ0doQjtBQW9DTixTQUFTaUIsbUJBQW1CO0FBQUFDLEtBQUE7QUFDMUIsUUFBTTtBQUFBLElBQUVDO0FBQUFBLEVBQVMsSUFBSTFCLGVBQWU7QUFDcEMsUUFBTTJCLFdBQVc1QixZQUFZO0FBRTdCLFFBQU0sQ0FBQzZCLFdBQVdDLFlBQVksSUFBSS9CLFNBQVMsS0FBSztBQUNoRCxRQUFNLENBQUNnQyxVQUFVQyxXQUFXLElBQUlqQyxTQUFTO0FBQUEsSUFDdkNrQyxVQUFVO0FBQUEsSUFDVkMsWUFBWTtBQUFBLElBQ1pDLE9BQU87QUFBQSxFQUNULENBQUM7QUFDRCxRQUFNLENBQUNDLFFBQVFDLFNBQVMsSUFBSXRDLFNBQVM7QUFBQSxJQUFFa0MsVUFBVTtBQUFBLElBQU9DLFlBQVk7QUFBQSxFQUFNLENBQUM7QUFFM0UsUUFBTSxDQUFDSSxhQUFhQyxjQUFjLElBQUl4QyxTQUFtQixFQUFFO0FBQzNELFFBQU0sQ0FBQ3lDLG1CQUFtQkMsb0JBQW9CLElBQUkxQyxTQUFtQixDQUNuRSxHQUFHTyxrQkFBa0IsQ0FDdEI7QUFDRCxRQUFNLENBQUNvQyxtQkFBbUJDLG9CQUFvQixJQUFJNUMsU0FBbUIsRUFBRTtBQUN2RSxRQUFNLENBQUM2QyxpQkFBaUJDLGtCQUFrQixJQUFJOUMsU0FBaUIsRUFBRTtBQUVqRSxRQUFNLENBQUMrQyxXQUFXQyxZQUFZLElBQUloRCxTQUFtQixFQUFFO0FBQ3ZELFFBQU0sQ0FBQ2lELGdCQUFnQkMsaUJBQWlCLElBQUlsRCxTQUFtQixDQUM3RCxHQUFHUSxnQkFBZ0IsQ0FDcEI7QUFDRCxRQUFNLENBQUMyQyxpQkFBaUJDLGtCQUFrQixJQUFJcEQsU0FBbUIsRUFBRTtBQUNuRSxRQUFNLENBQUNxRCxjQUFjQyxlQUFlLElBQUl0RCxTQUFpQixFQUFFO0FBRTNELFFBQU11RCxtQkFBbUJBLENBQ3ZCQyxPQUNBQyxNQUNBQyxZQUNHO0FBQ0hBLFlBQVNDLFVBQ1BBLEtBQUtDLFNBQVNKLEtBQUssSUFBSUcsS0FBS0UsT0FBUUMsT0FBTUEsTUFBTU4sS0FBSyxJQUFJLENBQUMsR0FBR0csTUFBTUgsS0FBSyxDQUMxRTtBQUFBLEVBQ0Y7QUFFQSxRQUFNTyxnQkFBZ0JBLENBQ3BCUCxPQUNBUSxTQUNBQyxZQUNBQyxRQUNBQyxXQUNBQyxVQUNBQyxhQUNBQyxhQUNHO0FBQ0gsVUFBTUMsVUFBVWYsTUFBTWdCLEtBQUs7QUFDM0IsUUFBSUQsV0FBVyxDQUFDUCxRQUFRSixTQUFTVyxPQUFPLEtBQUssQ0FBQ0wsT0FBT04sU0FBU1csT0FBTyxHQUFHO0FBQ3RFTixpQkFBWU4sVUFBUyxDQUFDLEdBQUdBLE1BQU1ZLE9BQU8sQ0FBQztBQUN2Q0osZ0JBQVdSLFVBQVMsQ0FBQyxHQUFHQSxNQUFNWSxPQUFPLENBQUM7QUFDdENGLGtCQUFhVixVQUFTLENBQUMsR0FBR0EsTUFBTVksT0FBTyxDQUFDO0FBQ3hDRCxlQUFTLEVBQUU7QUFBQSxJQUNiO0FBQUEsRUFDRjtBQUVBLFFBQU1HLHFCQUFxQkEsQ0FDekJDLE1BQ0FULFlBQ0FJLGFBQ0FGLGNBQ0c7QUFDSEYsZUFBWU4sVUFBU0EsS0FBS0UsT0FBUUMsT0FBTUEsTUFBTVksSUFBSSxDQUFDO0FBQ25ETCxnQkFBYVYsVUFBU0EsS0FBS0UsT0FBUUMsT0FBTUEsTUFBTVksSUFBSSxDQUFDO0FBQ3BEUCxjQUFXUixVQUFTQSxLQUFLRSxPQUFRQyxPQUFNQSxNQUFNWSxJQUFJLENBQUM7QUFBQSxFQUNwRDtBQUVBLFFBQU1DLGVBQWUsT0FBT0MsTUFBdUI7QUFDakRBLE1BQUVDLGVBQWU7QUFFakIsVUFBTUMsWUFBWTtBQUFBLE1BQ2hCNUMsVUFBVUYsU0FBU0UsV0FBVztBQUFBLE1BQzlCQyxZQUFZLENBQUNILFNBQVNHO0FBQUFBLElBQ3hCO0FBQ0FHLGNBQVV3QyxTQUFTO0FBQ25CLFFBQUlBLFVBQVU1QyxZQUFZNEMsVUFBVTNDO0FBQVk7QUFFaEQsUUFBSSxDQUFDUCxVQUFVO0FBQ2JtRCxZQUFNLHVCQUF1QjtBQUM3QjtBQUFBLElBQ0Y7QUFFQWhELGlCQUFhLElBQUk7QUFDakIsUUFBSTtBQUNGLFlBQU1pRCxVQUFVO0FBQUEsUUFDZDlDLFVBQVVGLFNBQVNFO0FBQUFBLFFBQ25CQyxZQUFZSCxTQUFTRztBQUFBQSxRQUNyQjhDLFlBQVkxQztBQUFBQSxRQUNaUTtBQUFBQSxRQUNBWCxPQUFPSixTQUFTSTtBQUFBQSxNQUNsQjtBQUVBLFlBQU07QUFBQSxRQUFFOEM7QUFBQUEsTUFBSyxJQUFJLE1BQU0vRSxNQUFNZ0YsS0FDM0IsMENBQTBDdkQsUUFBUSxJQUNsRG9ELFNBQ0E7QUFBQSxRQUFFSSxTQUFTO0FBQUEsVUFBRSxnQkFBZ0I7QUFBQSxRQUFtQjtBQUFBLE1BQUUsQ0FDcEQ7QUFHQXZELGVBQVMsWUFBWTtBQUFBLFFBQUV3RCxPQUFPO0FBQUEsVUFBRUMsU0FBU0o7QUFBQUEsUUFBSztBQUFBLE1BQTBCLENBQUM7QUFBQSxJQUMzRSxTQUFTSyxLQUFVO0FBQ2pCQyxjQUFRQyxNQUFNRixHQUFHO0FBQ2pCUixZQUNFUSxLQUFLRyxVQUFVUixNQUFNUyxXQUNuQixnREFDSjtBQUFBLElBQ0YsVUFBQztBQUNDNUQsbUJBQWEsS0FBSztBQUFBLElBQ3BCO0FBQUEsRUFDRjtBQUVBLFNBQ0UsdUJBQUMsYUFDQyxVQUFTLE1BQ1QsSUFBSTtBQUFBLElBQUVqQixPQUFPO0FBQUEsSUFBUzhFLElBQUk7QUFBQSxNQUFFQyxJQUFJO0FBQUEsTUFBR0MsSUFBSTtBQUFBLE1BQUdDLElBQUk7QUFBQSxJQUFFO0FBQUEsRUFBRSxHQUVsRCxpQ0FBQyxPQUFJLE9BQU0sUUFDVDtBQUFBLDJCQUFDLGNBQ0MsU0FBUSxNQUNSLFlBQVksS0FDWixXQUFVLFVBQ1YsY0FBWSxNQUNiLDRDQUxEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FPQTtBQUFBLElBQ0EsdUJBQUMsY0FDQyxTQUFRLFNBQ1IsV0FBVSxVQUNWLE9BQU0sa0JBQ04sSUFBSSxHQUNMLG9GQUxEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FPQTtBQUFBLElBRUEsdUJBQUMsVUFBSyxVQUFVcEIsY0FBYyxXQUFVLGtCQUN0QztBQUFBLDZCQUFDLFNBQUksV0FBVSxnQkFDYjtBQUFBLCtCQUFDLGNBQVcsU0FBUSxhQUFZLFlBQVksS0FBSztBQUFBO0FBQUEsVUFDNUIsdUJBQUMsVUFBSyxXQUFVLFlBQVcsaUJBQTNCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTRCO0FBQUEsYUFEakQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsUUFDQSx1QkFBQyxPQUFJLFNBQVEsUUFBTyxZQUFXLFVBQVMsS0FBSyxHQUMzQztBQUFBLGlDQUFDLGdCQUNDLE9BQU8zQyxTQUFTRSxVQUNoQixVQUFVLENBQUM4RCxHQUFHQyxRQUNaaEUsWUFBYTBCLFdBQVU7QUFBQSxZQUFFLEdBQUdBO0FBQUFBLFlBQU16QixVQUFVK0Q7QUFBQUEsVUFBYyxFQUFFLEdBRTlELG1CQUFrQixRQUNsQixjQUFjLEdBQ2QsS0FBSyxHQUNMLEtBQUssSUFDTCxPQUFPNUQsT0FBT0gsV0FBVyxVQUFVLGFBVHJDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBUytDO0FBQUEsVUFFL0MsdUJBQUMsY0FBVyxlQUFZLGlCQUNyQkYsbUJBQVNFLFlBRFo7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLGFBZEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQWVBO0FBQUEsV0FuQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQW9CQTtBQUFBLE1BRUEsdUJBQUMsU0FBSSxXQUFVLGdCQUNiO0FBQUEsK0JBQUMsY0FBVyxTQUFRLGFBQVksWUFBWSxLQUFLO0FBQUE7QUFBQSxVQUM1Qix1QkFBQyxVQUFLLFdBQVUsWUFBVyxpQkFBM0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBNEI7QUFBQSxhQURqRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQSxRQUNBLHVCQUFDLE9BQUksU0FBUSxRQUFPLEtBQUssR0FBRyxVQUFTLFFBQ2xDOUIsc0JBQVk4RixJQUFLQyxVQUNoQix1QkFBQyxRQUNDLFdBQVUsZUFFVixPQUFPQSxLQUFLN0YsT0FDWixTQUNFMEIsU0FBU0csZUFBZWdFLEtBQUs5RixLQUFLLFdBQVcsWUFFL0MsT0FBTzJCLFNBQVNHLGVBQWVnRSxLQUFLOUYsS0FBSyxZQUFZLFdBQ3JELFNBQVMsTUFDUDRCLFlBQWEwQixXQUFVO0FBQUEsVUFBRSxHQUFHQTtBQUFBQSxVQUFNeEIsWUFBWWdFLEtBQUs5RjtBQUFBQSxRQUFHLEVBQUUsS0FQckQ4RixLQUFLOUYsSUFGWjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBVUcsQ0FFSixLQWRIO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFlQTtBQUFBLFdBbkJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFvQkE7QUFBQSxNQUVBLHVCQUFDLFNBQUksV0FBVSxnQkFDYjtBQUFBLCtCQUFDLGNBQVcsU0FBUSxhQUFZLFlBQVksS0FBSywyQkFBakQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsUUFDQSx1QkFBQyxPQUFJLFdBQVUsWUFDWm9DLDRCQUFrQnlELElBQUtFLFVBQ3RCLHVCQUFDLFFBQ0MsV0FBVSxlQUVWLE9BQU9BLE1BQ1AsU0FBUzdELFlBQVlxQixTQUFTd0MsSUFBSSxJQUFJLFdBQVcsWUFDakQsT0FBTzdELFlBQVlxQixTQUFTd0MsSUFBSSxJQUFJLFlBQVlDLFFBQ2hELFNBQVMsTUFDUDlDLGlCQUFpQjZDLE1BQU03RCxhQUFhQyxjQUFjLEdBRXBELFVBQ0VHLGtCQUFrQmlCLFNBQVN3QyxJQUFJLElBQzNCLE1BQ0UzQixtQkFDRTJCLE1BQ0ExRCxzQkFDQUUsc0JBQ0FKLGNBQ0YsSUFDRjZELFVBaEJERCxNQUZQO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFtQkcsQ0FFSixLQXZCSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBd0JBO0FBQUEsUUFDQSx1QkFBQyxPQUNDLFNBQVEsUUFDUixLQUFLLEdBQ0wsSUFBSTtBQUFBLFVBQUV6RixRQUFRO0FBQUEsVUFBSTJGLFlBQVk7QUFBQSxRQUFTLEdBRXZDO0FBQUEsaUNBQUMsYUFDQyxPQUFNLGtCQUNOLE1BQUssU0FDTCxPQUFPekQsaUJBQ1AsT0FBTSxXQUNOLFNBQU8sTUFDUCxVQUFXK0IsT0FBTTlCLG1CQUFtQjhCLEVBQUUyQixPQUFPL0MsS0FBSyxLQU5wRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQU1zRDtBQUFBLFVBRXRELHVCQUFDLFVBQ0MsU0FBUSxZQUNSLE9BQU0sV0FDTixjQUFXLGtCQUNYLFNBQVMsTUFDUE8sY0FDRWxCLGlCQUNBSixtQkFDQUMsc0JBQ0FDLG1CQUNBQyxzQkFDQUwsYUFDQUMsZ0JBQ0FNLGtCQUNGLEdBRUgsbUJBaEJEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBa0JBO0FBQUEsYUEvQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQWdDQTtBQUFBLFdBN0RGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUE4REE7QUFBQSxNQUVBLHVCQUFDLFNBQUksV0FBVSxnQkFDYjtBQUFBLCtCQUFDLGNBQVcsU0FBUSxhQUFZLFlBQVksS0FBSyx5QkFBakQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsUUFDQSx1QkFBQyxPQUFJLFdBQVUsWUFDWkcseUJBQWVpRCxJQUFLTSxhQUNuQix1QkFBQyxRQUNDLFdBQVUsZUFFVixPQUFPQSxTQUNQLFNBQVN6RCxVQUFVYSxTQUFTNEMsT0FBTyxJQUFJLFdBQVcsWUFDbEQsT0FBT3pELFVBQVVhLFNBQVM0QyxPQUFPLElBQUksWUFBWUgsUUFDakQsU0FBUyxNQUNQOUMsaUJBQWlCaUQsU0FBU3pELFdBQVdDLFlBQVksR0FFbkQsVUFDRUcsZ0JBQWdCUyxTQUFTNEMsT0FBTyxJQUM1QixNQUNFL0IsbUJBQ0UrQixTQUNBdEQsbUJBQ0FFLG9CQUNBSixZQUNGLElBQ0ZxRCxVQWhCREcsU0FGUDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBbUJHLENBRUosS0F2Qkg7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQXdCQTtBQUFBLFFBQ0EsdUJBQUMsT0FBSSxTQUFRLFFBQU8sS0FBSyxHQUFHLElBQUksR0FDOUI7QUFBQSxpQ0FBQyxhQUNDLE9BQU0sZUFDTixNQUFLLFNBQ0wsU0FBTyxNQUNQLE9BQU0sV0FDTixPQUFPbkQsY0FDUCxVQUFXdUIsT0FBTXRCLGdCQUFnQnNCLEVBQUUyQixPQUFPL0MsS0FBSyxLQU5qRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQU1tRDtBQUFBLFVBRW5ELHVCQUFDLFVBQ0MsU0FBUSxZQUNSLE9BQU0sV0FDTixjQUFXLGVBQ1gsU0FBUyxNQUNQTyxjQUNFVixjQUNBSixnQkFDQUMsbUJBQ0FDLGlCQUNBQyxvQkFDQUwsV0FDQUMsY0FDQU0sZUFDRixHQUVILG1CQWhCRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQWtCQTtBQUFBLGFBM0JGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUE0QkE7QUFBQSxXQXpERjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBMERBO0FBQUEsTUFFQSx1QkFBQyxTQUFJLFdBQVUsZ0JBQ2I7QUFBQSwrQkFBQyxjQUFXLFNBQVEsYUFBWSxZQUFZLEtBQUssZ0NBQWpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFFBQ0EsdUJBQUMsYUFDQyxXQUFTLE1BQ1QsTUFBTSxHQUNOLGFBQVksNkNBQ1osV0FBUyxNQUNULE9BQU0sV0FDTixPQUFPdEIsU0FBU0ksT0FDaEIsVUFBV3dDLE9BQ1QzQyxZQUFZO0FBQUEsVUFBRSxHQUFHRDtBQUFBQSxVQUFVSSxPQUFPd0MsRUFBRTJCLE9BQU8vQztBQUFBQSxRQUFNLENBQUMsS0FSdEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVNHO0FBQUEsV0FiTDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBZUE7QUFBQSxNQUVBLHVCQUFDLE9BQUksV0FBVSxVQUFTLElBQUksR0FDMUIsaUNBQUMsVUFDQyxNQUFLLFVBQ0wsU0FBUSxhQUNSLE9BQU0sV0FDTixJQUFJO0FBQUEsUUFBRW9DLElBQUk7QUFBQSxRQUFHYSxJQUFJO0FBQUEsUUFBS0MsWUFBWTtBQUFBLE1BQUksR0FDdEMsVUFBVTVFLFdBRVRBLHNCQUNDLHVCQUFDLG9CQUFpQixNQUFNLElBQUksSUFBSTtBQUFBLFFBQUVwQixPQUFPO0FBQUEsTUFBTyxLQUFoRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQWtELElBRWxELHFCQVZKO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFZQSxLQWJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFjQTtBQUFBLFNBeE1GO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0F5TUE7QUFBQSxPQTNORjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBNE5BLEtBaE9GO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FpT0E7QUFFSjtBQUFDaUIsR0FsVlFELGtCQUFnQjtBQUFBLFVBQ0Z4QixnQkFDSkQsV0FBVztBQUFBO0FBQUEwRyxNQUZyQmpGO0FBb1ZULGVBQWVBO0FBQWlCLElBQUFELElBQUFrRjtBQUFBQyxhQUFBbkYsSUFBQTtBQUFBbUYsYUFBQUQsS0FBQSIsIm5hbWVzIjpbIkJveCIsIkJ1dHRvbiIsIkNoaXAiLCJDaXJjdWxhclByb2dyZXNzIiwiQ29udGFpbmVyIiwiU2xpZGVyIiwiVGV4dEZpZWxkIiwiVHlwb2dyYXBoeSIsInN0eWxlZCIsInVzZVN0YXRlIiwidXNlTmF2aWdhdGUiLCJ1c2VVc2VyQ29udGV4dCIsImF4aW9zIiwicmVjaXBlVHlwZXMiLCJpZCIsImxhYmVsIiwiZGVmYXVsdFByZWZlcmVuY2VzIiwiZGVmYXVsdEFsbGVyZ2llcyIsIlByZXR0b1NsaWRlciIsImNvbG9yIiwiaGVpZ2h0IiwibWF4V2lkdGgiLCJib3JkZXIiLCJ3aWR0aCIsImJhY2tncm91bmRDb2xvciIsImJveFNoYWRvdyIsImRpc3BsYXkiLCJsaW5lSGVpZ2h0IiwiZm9udFNpemUiLCJiYWNrZ3JvdW5kIiwicGFkZGluZyIsImJvcmRlclJhZGl1cyIsInRyYW5zZm9ybU9yaWdpbiIsInRyYW5zZm9ybSIsIl9jIiwiUmVjaXBlR2VuZXJhdGlvbiIsIl9zIiwiZGJVc2VySWQiLCJuYXZpZ2F0ZSIsImlzTG9hZGluZyIsInNldElzTG9hZGluZyIsImZvcm1EYXRhIiwic2V0Rm9ybURhdGEiLCJzZXJ2aW5ncyIsInJlY2lwZVR5cGUiLCJub3RlcyIsImVycm9ycyIsInNldEVycm9ycyIsInByZWZlcmVuY2VzIiwic2V0UHJlZmVyZW5jZXMiLCJwcmVmZXJlbmNlT3B0aW9ucyIsInNldFByZWZlcmVuY2VPcHRpb25zIiwiY3VzdG9tUHJlZmVyZW5jZXMiLCJzZXRDdXN0b21QcmVmZXJlbmNlcyIsInByZWZlcmVuY2VJbnB1dCIsInNldFByZWZlcmVuY2VJbnB1dCIsImFsbGVyZ2llcyIsInNldEFsbGVyZ2llcyIsImFsbGVyZ3lPcHRpb25zIiwic2V0QWxsZXJneU9wdGlvbnMiLCJjdXN0b21BbGxlcmdpZXMiLCJzZXRDdXN0b21BbGxlcmdpZXMiLCJhbGxlcmd5SW5wdXQiLCJzZXRBbGxlcmd5SW5wdXQiLCJoYW5kbGVDaGlwVG9nZ2xlIiwidmFsdWUiLCJsaXN0Iiwic2V0TGlzdCIsInByZXYiLCJpbmNsdWRlcyIsImZpbHRlciIsInYiLCJoYW5kbGVBZGRDaGlwIiwib3B0aW9ucyIsInNldE9wdGlvbnMiLCJjdXN0b20iLCJzZXRDdXN0b20iLCJzZWxlY3RlZCIsInNldFNlbGVjdGVkIiwic2V0SW5wdXQiLCJ0cmltbWVkIiwidHJpbSIsImhhbmRsZURlbGV0ZUN1c3RvbSIsIml0ZW0iLCJoYW5kbGVTdWJtaXQiLCJlIiwicHJldmVudERlZmF1bHQiLCJuZXdFcnJvcnMiLCJhbGVydCIsInBheWxvYWQiLCJtZWFsT3JpZ2luIiwiZGF0YSIsInBvc3QiLCJoZWFkZXJzIiwic3RhdGUiLCJyZWNpcGVzIiwiZXJyIiwiY29uc29sZSIsImVycm9yIiwicmVzcG9uc2UiLCJtZXNzYWdlIiwicHgiLCJ4cyIsInNtIiwibWQiLCJfIiwidmFsIiwibWFwIiwidHlwZSIsInByZWYiLCJ1bmRlZmluZWQiLCJhbGlnbkl0ZW1zIiwidGFyZ2V0IiwiYWxsZXJneSIsInB5IiwiZm9udFdlaWdodCIsIl9jMiIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIlJlY2lwZUdlbmVyYXRpb24udHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7XHJcbiAgQm94LFxyXG4gIEJ1dHRvbixcclxuICBDaGlwLFxyXG4gIENpcmN1bGFyUHJvZ3Jlc3MsXHJcbiAgQ29udGFpbmVyLFxyXG4gIFNsaWRlcixcclxuICBUZXh0RmllbGQsXHJcbiAgVHlwb2dyYXBoeSxcclxufSBmcm9tIFwiQG11aS9tYXRlcmlhbFwiO1xyXG5pbXBvcnQgeyBzdHlsZWQgfSBmcm9tIFwiQG11aS9tYXRlcmlhbC9zdHlsZXNcIjtcclxuaW1wb3J0IFJlYWN0LCB7IHVzZVN0YXRlIH0gZnJvbSBcInJlYWN0XCI7XHJcbmltcG9ydCBcIi4uL3N0eWxlcy9yZWNpcGVHZW5lcmF0aW9uLmNzc1wiO1xyXG5pbXBvcnQgeyB1c2VOYXZpZ2F0ZSB9IGZyb20gXCJyZWFjdC1yb3V0ZXItZG9tXCI7XHJcbmltcG9ydCB7IHVzZVVzZXJDb250ZXh0IH0gZnJvbSBcIi4uL2NvbnRleHRzL1VzZXJDb250ZXh0XCI7XHJcbmltcG9ydCB7IExvY2F0aW9uU3RhdGUgfSBmcm9tIFwiLi4vdHlwZXMvcmVjaXBlXCI7XHJcbmltcG9ydCBheGlvcyBmcm9tIFwiYXhpb3NcIjtcclxuXHJcbmNvbnN0IHJlY2lwZVR5cGVzID0gW1xyXG4gIHsgaWQ6IFwiTUFJTlwiLCBsYWJlbDogXCJNYWluXCIgfSxcclxuICB7IGlkOiBcIkFQUEVUSVpFUlwiLCBsYWJlbDogXCJBcHBldGl6ZXJcIiB9LFxyXG4gIHsgaWQ6IFwiREVTU0VSVFwiLCBsYWJlbDogXCJEZXNzZXJ0XCIgfSxcclxuICB7IGlkOiBcIkJSRUFLRkFTVFwiLCBsYWJlbDogXCJCcmVha2Zhc3RcIiB9LFxyXG4gIHsgaWQ6IFwiU05BQ0tcIiwgbGFiZWw6IFwiU25hY2tcIiB9LFxyXG5dO1xyXG5cclxuY29uc3QgZGVmYXVsdFByZWZlcmVuY2VzID0gW1xyXG4gIFwiQW1lcmljYW5cIixcclxuICBcIkl0YWxpYW5cIixcclxuICBcIkNoaW5lc2VcIixcclxuICBcIk1leGljYW5cIixcclxuICBcIkphcGFuZXNlXCIsXHJcbiAgXCJJbmRpYW5cIixcclxuICBcIk1pZGRsZSBFYXN0ZXJuXCIsXHJcbiAgXCJUaGFpXCIsXHJcbl07XHJcblxyXG5jb25zdCBkZWZhdWx0QWxsZXJnaWVzID0gW1xyXG4gIFwiR2x1dGVuXCIsXHJcbiAgXCJEYWlyeVwiLFxyXG4gIFwiTnV0c1wiLFxyXG4gIFwiRWdnc1wiLFxyXG4gIFwiU295XCIsXHJcbiAgXCJTaGVsbGZpc2hcIixcclxuXTtcclxuXHJcbmNvbnN0IFByZXR0b1NsaWRlciA9IHN0eWxlZChTbGlkZXIpKHtcclxuICBjb2xvcjogXCIjNTJhZjc3XCIsXHJcbiAgaGVpZ2h0OiA4LFxyXG4gIG1heFdpZHRoOiAzMDAsXHJcbiAgXCImIC5NdWlTbGlkZXItdHJhY2tcIjogeyBib3JkZXI6IFwibm9uZVwiIH0sXHJcbiAgXCImIC5NdWlTbGlkZXItdGh1bWJcIjoge1xyXG4gICAgaGVpZ2h0OiAyNCxcclxuICAgIHdpZHRoOiAyNCxcclxuICAgIGJhY2tncm91bmRDb2xvcjogXCIjZmZmXCIsXHJcbiAgICBib3JkZXI6IFwiMnB4IHNvbGlkIGN1cnJlbnRDb2xvclwiLFxyXG4gICAgXCImOmZvY3VzLCAmOmhvdmVyLCAmLk11aS1hY3RpdmUsICYuTXVpLWZvY3VzVmlzaWJsZVwiOiB7XHJcbiAgICAgIGJveFNoYWRvdzogXCJpbmhlcml0XCIsXHJcbiAgICB9LFxyXG4gICAgXCImOjpiZWZvcmVcIjogeyBkaXNwbGF5OiBcIm5vbmVcIiB9LFxyXG4gIH0sXHJcbiAgXCImIC5NdWlTbGlkZXItdmFsdWVMYWJlbFwiOiB7XHJcbiAgICBsaW5lSGVpZ2h0OiAxLjIsXHJcbiAgICBmb250U2l6ZTogMTIsXHJcbiAgICBiYWNrZ3JvdW5kOiBcInVuc2V0XCIsXHJcbiAgICBwYWRkaW5nOiAwLFxyXG4gICAgd2lkdGg6IDMyLFxyXG4gICAgaGVpZ2h0OiAzMixcclxuICAgIGJvcmRlclJhZGl1czogXCI1MCUgNTAlIDUwJSAwXCIsXHJcbiAgICBiYWNrZ3JvdW5kQ29sb3I6IFwiIzUyYWY3N1wiLFxyXG4gICAgdHJhbnNmb3JtT3JpZ2luOiBcImJvdHRvbSBsZWZ0XCIsXHJcbiAgICB0cmFuc2Zvcm06IFwidHJhbnNsYXRlKDUwJSwgLTEwMCUpIHJvdGF0ZSgtNDVkZWcpIHNjYWxlKDApXCIsXHJcbiAgICBcIiY6OmJlZm9yZVwiOiB7IGRpc3BsYXk6IFwibm9uZVwiIH0sXHJcbiAgICBcIiYuTXVpU2xpZGVyLXZhbHVlTGFiZWxPcGVuXCI6IHtcclxuICAgICAgdHJhbnNmb3JtOiBcInRyYW5zbGF0ZSg1MCUsIC0xMDAlKSByb3RhdGUoLTQ1ZGVnKSBzY2FsZSgxKVwiLFxyXG4gICAgfSxcclxuICAgIFwiJiA+ICpcIjoge1xyXG4gICAgICB0cmFuc2Zvcm06IFwicm90YXRlKDQ1ZGVnKVwiLFxyXG4gICAgfSxcclxuICB9LFxyXG59KTtcclxuXHJcbmZ1bmN0aW9uIFJlY2lwZUdlbmVyYXRpb24oKSB7XHJcbiAgY29uc3QgeyBkYlVzZXJJZCB9ID0gdXNlVXNlckNvbnRleHQoKTtcclxuICBjb25zdCBuYXZpZ2F0ZSA9IHVzZU5hdmlnYXRlKCk7XHJcblxyXG4gIGNvbnN0IFtpc0xvYWRpbmcsIHNldElzTG9hZGluZ10gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3QgW2Zvcm1EYXRhLCBzZXRGb3JtRGF0YV0gPSB1c2VTdGF0ZSh7XHJcbiAgICBzZXJ2aW5nczogMSxcclxuICAgIHJlY2lwZVR5cGU6IFwiXCIsXHJcbiAgICBub3RlczogXCJcIixcclxuICB9KTtcclxuICBjb25zdCBbZXJyb3JzLCBzZXRFcnJvcnNdID0gdXNlU3RhdGUoeyBzZXJ2aW5nczogZmFsc2UsIHJlY2lwZVR5cGU6IGZhbHNlIH0pO1xyXG5cclxuICBjb25zdCBbcHJlZmVyZW5jZXMsIHNldFByZWZlcmVuY2VzXSA9IHVzZVN0YXRlPHN0cmluZ1tdPihbXSk7XHJcbiAgY29uc3QgW3ByZWZlcmVuY2VPcHRpb25zLCBzZXRQcmVmZXJlbmNlT3B0aW9uc10gPSB1c2VTdGF0ZTxzdHJpbmdbXT4oW1xyXG4gICAgLi4uZGVmYXVsdFByZWZlcmVuY2VzLFxyXG4gIF0pO1xyXG4gIGNvbnN0IFtjdXN0b21QcmVmZXJlbmNlcywgc2V0Q3VzdG9tUHJlZmVyZW5jZXNdID0gdXNlU3RhdGU8c3RyaW5nW10+KFtdKTtcclxuICBjb25zdCBbcHJlZmVyZW5jZUlucHV0LCBzZXRQcmVmZXJlbmNlSW5wdXRdID0gdXNlU3RhdGU8c3RyaW5nPihcIlwiKTtcclxuXHJcbiAgY29uc3QgW2FsbGVyZ2llcywgc2V0QWxsZXJnaWVzXSA9IHVzZVN0YXRlPHN0cmluZ1tdPihbXSk7XHJcbiAgY29uc3QgW2FsbGVyZ3lPcHRpb25zLCBzZXRBbGxlcmd5T3B0aW9uc10gPSB1c2VTdGF0ZTxzdHJpbmdbXT4oW1xyXG4gICAgLi4uZGVmYXVsdEFsbGVyZ2llcyxcclxuICBdKTtcclxuICBjb25zdCBbY3VzdG9tQWxsZXJnaWVzLCBzZXRDdXN0b21BbGxlcmdpZXNdID0gdXNlU3RhdGU8c3RyaW5nW10+KFtdKTtcclxuICBjb25zdCBbYWxsZXJneUlucHV0LCBzZXRBbGxlcmd5SW5wdXRdID0gdXNlU3RhdGU8c3RyaW5nPihcIlwiKTtcclxuXHJcbiAgY29uc3QgaGFuZGxlQ2hpcFRvZ2dsZSA9IChcclxuICAgIHZhbHVlOiBzdHJpbmcsXHJcbiAgICBsaXN0OiBzdHJpbmdbXSxcclxuICAgIHNldExpc3Q6IFJlYWN0LkRpc3BhdGNoPFJlYWN0LlNldFN0YXRlQWN0aW9uPHN0cmluZ1tdPj5cclxuICApID0+IHtcclxuICAgIHNldExpc3QoKHByZXYpID0+XHJcbiAgICAgIHByZXYuaW5jbHVkZXModmFsdWUpID8gcHJldi5maWx0ZXIoKHYpID0+IHYgIT09IHZhbHVlKSA6IFsuLi5wcmV2LCB2YWx1ZV1cclxuICAgICk7XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgaGFuZGxlQWRkQ2hpcCA9IChcclxuICAgIHZhbHVlOiBzdHJpbmcsXHJcbiAgICBvcHRpb25zOiBzdHJpbmdbXSxcclxuICAgIHNldE9wdGlvbnM6IFJlYWN0LkRpc3BhdGNoPFJlYWN0LlNldFN0YXRlQWN0aW9uPHN0cmluZ1tdPj4sXHJcbiAgICBjdXN0b206IHN0cmluZ1tdLFxyXG4gICAgc2V0Q3VzdG9tOiBSZWFjdC5EaXNwYXRjaDxSZWFjdC5TZXRTdGF0ZUFjdGlvbjxzdHJpbmdbXT4+LFxyXG4gICAgc2VsZWN0ZWQ6IHN0cmluZ1tdLFxyXG4gICAgc2V0U2VsZWN0ZWQ6IFJlYWN0LkRpc3BhdGNoPFJlYWN0LlNldFN0YXRlQWN0aW9uPHN0cmluZ1tdPj4sXHJcbiAgICBzZXRJbnB1dDogUmVhY3QuRGlzcGF0Y2g8UmVhY3QuU2V0U3RhdGVBY3Rpb248c3RyaW5nPj5cclxuICApID0+IHtcclxuICAgIGNvbnN0IHRyaW1tZWQgPSB2YWx1ZS50cmltKCk7XHJcbiAgICBpZiAodHJpbW1lZCAmJiAhb3B0aW9ucy5pbmNsdWRlcyh0cmltbWVkKSAmJiAhY3VzdG9tLmluY2x1ZGVzKHRyaW1tZWQpKSB7XHJcbiAgICAgIHNldE9wdGlvbnMoKHByZXYpID0+IFsuLi5wcmV2LCB0cmltbWVkXSk7XHJcbiAgICAgIHNldEN1c3RvbSgocHJldikgPT4gWy4uLnByZXYsIHRyaW1tZWRdKTtcclxuICAgICAgc2V0U2VsZWN0ZWQoKHByZXYpID0+IFsuLi5wcmV2LCB0cmltbWVkXSk7XHJcbiAgICAgIHNldElucHV0KFwiXCIpO1xyXG4gICAgfVxyXG4gIH07XHJcblxyXG4gIGNvbnN0IGhhbmRsZURlbGV0ZUN1c3RvbSA9IChcclxuICAgIGl0ZW06IHN0cmluZyxcclxuICAgIHNldE9wdGlvbnM6IFJlYWN0LkRpc3BhdGNoPFJlYWN0LlNldFN0YXRlQWN0aW9uPHN0cmluZ1tdPj4sXHJcbiAgICBzZXRTZWxlY3RlZDogUmVhY3QuRGlzcGF0Y2g8UmVhY3QuU2V0U3RhdGVBY3Rpb248c3RyaW5nW10+PixcclxuICAgIHNldEN1c3RvbTogUmVhY3QuRGlzcGF0Y2g8UmVhY3QuU2V0U3RhdGVBY3Rpb248c3RyaW5nW10+PlxyXG4gICkgPT4ge1xyXG4gICAgc2V0T3B0aW9ucygocHJldikgPT4gcHJldi5maWx0ZXIoKHYpID0+IHYgIT09IGl0ZW0pKTtcclxuICAgIHNldFNlbGVjdGVkKChwcmV2KSA9PiBwcmV2LmZpbHRlcigodikgPT4gdiAhPT0gaXRlbSkpO1xyXG4gICAgc2V0Q3VzdG9tKChwcmV2KSA9PiBwcmV2LmZpbHRlcigodikgPT4gdiAhPT0gaXRlbSkpO1xyXG4gIH07XHJcblxyXG4gIGNvbnN0IGhhbmRsZVN1Ym1pdCA9IGFzeW5jIChlOiBSZWFjdC5Gb3JtRXZlbnQpID0+IHtcclxuICAgIGUucHJldmVudERlZmF1bHQoKTtcclxuXHJcbiAgICBjb25zdCBuZXdFcnJvcnMgPSB7XHJcbiAgICAgIHNlcnZpbmdzOiBmb3JtRGF0YS5zZXJ2aW5ncyA8IDEsXHJcbiAgICAgIHJlY2lwZVR5cGU6ICFmb3JtRGF0YS5yZWNpcGVUeXBlLFxyXG4gICAgfTtcclxuICAgIHNldEVycm9ycyhuZXdFcnJvcnMpO1xyXG4gICAgaWYgKG5ld0Vycm9ycy5zZXJ2aW5ncyB8fCBuZXdFcnJvcnMucmVjaXBlVHlwZSkgcmV0dXJuO1xyXG5cclxuICAgIGlmICghZGJVc2VySWQpIHtcclxuICAgICAgYWxlcnQoXCJQbGVhc2Ugc2lnbiBpbiBmaXJzdC5cIik7XHJcbiAgICAgIHJldHVybjtcclxuICAgIH1cclxuXHJcbiAgICBzZXRJc0xvYWRpbmcodHJ1ZSk7XHJcbiAgICB0cnkge1xyXG4gICAgICBjb25zdCBwYXlsb2FkID0ge1xyXG4gICAgICAgIHNlcnZpbmdzOiBmb3JtRGF0YS5zZXJ2aW5ncyxcclxuICAgICAgICByZWNpcGVUeXBlOiBmb3JtRGF0YS5yZWNpcGVUeXBlLFxyXG4gICAgICAgIG1lYWxPcmlnaW46IHByZWZlcmVuY2VzLFxyXG4gICAgICAgIGFsbGVyZ2llcyxcclxuICAgICAgICBub3RlczogZm9ybURhdGEubm90ZXMsXHJcbiAgICAgIH07XHJcblxyXG4gICAgICBjb25zdCB7IGRhdGEgfSA9IGF3YWl0IGF4aW9zLnBvc3QoXHJcbiAgICAgICAgYGh0dHA6Ly9sb2NhbGhvc3Q6ODA4MC9hcGkvcmVjaXBlcy91c2VyLyR7ZGJVc2VySWR9YCxcclxuICAgICAgICBwYXlsb2FkLFxyXG4gICAgICAgIHsgaGVhZGVyczogeyBcIkNvbnRlbnQtVHlwZVwiOiBcImFwcGxpY2F0aW9uL2pzb25cIiB9IH1cclxuICAgICAgKTtcclxuXHJcbiAgICAgIC8qIFRoZSBjb250cm9sbGVyIHdyYXBzIHJlc3VsdHMgYXMgeyByZWNpcGVzOiBb4oCmXSB9ICovXHJcbiAgICAgIG5hdmlnYXRlKFwiL3JlY2lwZXNcIiwgeyBzdGF0ZTogeyByZWNpcGVzOiBkYXRhIH0gc2F0aXNmaWVzIExvY2F0aW9uU3RhdGUgfSk7XHJcbiAgICB9IGNhdGNoIChlcnI6IGFueSkge1xyXG4gICAgICBjb25zb2xlLmVycm9yKGVycik7XHJcbiAgICAgIGFsZXJ0KFxyXG4gICAgICAgIGVycj8ucmVzcG9uc2U/LmRhdGE/Lm1lc3NhZ2UgPz9cclxuICAgICAgICAgIFwiU29tZXRoaW5nIHdlbnQgd3Jvbmcgd2hpbGUgZ2VuZXJhdGluZyByZWNpcGVzLlwiXHJcbiAgICAgICk7XHJcbiAgICB9IGZpbmFsbHkge1xyXG4gICAgICBzZXRJc0xvYWRpbmcoZmFsc2UpO1xyXG4gICAgfVxyXG4gIH07XHJcblxyXG4gIHJldHVybiAoXHJcbiAgICA8Q29udGFpbmVyXHJcbiAgICAgIG1heFdpZHRoPVwibWRcIlxyXG4gICAgICBzeD17eyB3aWR0aDogXCI5MDBweFwiLCBweDogeyB4czogMiwgc206IDMsIG1kOiA0IH0gfX1cclxuICAgID5cclxuICAgICAgPEJveCB3aWR0aD1cIjEwMCVcIj5cclxuICAgICAgICA8VHlwb2dyYXBoeVxyXG4gICAgICAgICAgdmFyaWFudD1cImg1XCJcclxuICAgICAgICAgIGZvbnRXZWlnaHQ9ezYwMH1cclxuICAgICAgICAgIHRleHRBbGlnbj1cImNlbnRlclwiXHJcbiAgICAgICAgICBndXR0ZXJCb3R0b21cclxuICAgICAgICA+XHJcbiAgICAgICAgICBHZW5lcmF0ZSBZb3VyIFBlcmZlY3QgUmVjaXBlXHJcbiAgICAgICAgPC9UeXBvZ3JhcGh5PlxyXG4gICAgICAgIDxUeXBvZ3JhcGh5XHJcbiAgICAgICAgICB2YXJpYW50PVwiYm9keTJcIlxyXG4gICAgICAgICAgdGV4dEFsaWduPVwiY2VudGVyXCJcclxuICAgICAgICAgIGNvbG9yPVwidGV4dC5zZWNvbmRhcnlcIlxyXG4gICAgICAgICAgbWI9ezJ9XHJcbiAgICAgICAgPlxyXG4gICAgICAgICAgQmFzZWQgb24geW91ciBwcmVmZXJlbmNlcywgZGlldGFyeSBuZWVkcywgYW5kIGF2YWlsYWJsZSBpbmdyZWRpZW50cy5cclxuICAgICAgICA8L1R5cG9ncmFwaHk+XHJcblxyXG4gICAgICAgIDxmb3JtIG9uU3VibWl0PXtoYW5kbGVTdWJtaXR9IGNsYXNzTmFtZT1cImZvcm0tY29udGFpbmVyXCI+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZvcm0tc2VjdGlvblwiPlxyXG4gICAgICAgICAgICA8VHlwb2dyYXBoeSB2YXJpYW50PVwic3VidGl0bGUxXCIgZm9udFdlaWdodD17NjAwfT5cclxuICAgICAgICAgICAgICBIb3cgbWFueSBzZXJ2aW5ncz8gPHNwYW4gY2xhc3NOYW1lPVwicmVxdWlyZWRcIj4qPC9zcGFuPlxyXG4gICAgICAgICAgICA8L1R5cG9ncmFwaHk+XHJcbiAgICAgICAgICAgIDxCb3ggZGlzcGxheT1cImZsZXhcIiBhbGlnbkl0ZW1zPVwiY2VudGVyXCIgZ2FwPXsyfT5cclxuICAgICAgICAgICAgICA8UHJldHRvU2xpZGVyXHJcbiAgICAgICAgICAgICAgICB2YWx1ZT17Zm9ybURhdGEuc2VydmluZ3N9XHJcbiAgICAgICAgICAgICAgICBvbkNoYW5nZT17KF8sIHZhbCkgPT5cclxuICAgICAgICAgICAgICAgICAgc2V0Rm9ybURhdGEoKHByZXYpID0+ICh7IC4uLnByZXYsIHNlcnZpbmdzOiB2YWwgYXMgbnVtYmVyIH0pKVxyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgdmFsdWVMYWJlbERpc3BsYXk9XCJhdXRvXCJcclxuICAgICAgICAgICAgICAgIGRlZmF1bHRWYWx1ZT17MX1cclxuICAgICAgICAgICAgICAgIG1pbj17MH1cclxuICAgICAgICAgICAgICAgIG1heD17MTB9XHJcbiAgICAgICAgICAgICAgICBjb2xvcj17ZXJyb3JzLnNlcnZpbmdzID8gXCJlcnJvclwiIDogXCJzdWNjZXNzXCJ9XHJcbiAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICA8VHlwb2dyYXBoeSBkYXRhLXRlc3RpZD1cInNlcnZpbmctdmFsdWVcIj5cclxuICAgICAgICAgICAgICAgIHtmb3JtRGF0YS5zZXJ2aW5nc31cclxuICAgICAgICAgICAgICA8L1R5cG9ncmFwaHk+XHJcbiAgICAgICAgICAgIDwvQm94PlxyXG4gICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmb3JtLXNlY3Rpb25cIj5cclxuICAgICAgICAgICAgPFR5cG9ncmFwaHkgdmFyaWFudD1cInN1YnRpdGxlMVwiIGZvbnRXZWlnaHQ9ezYwMH0+XHJcbiAgICAgICAgICAgICAgV2hhdCBraW5kIG9mIG1lYWw/IDxzcGFuIGNsYXNzTmFtZT1cInJlcXVpcmVkXCI+Kjwvc3Bhbj5cclxuICAgICAgICAgICAgPC9UeXBvZ3JhcGh5PlxyXG4gICAgICAgICAgICA8Qm94IGRpc3BsYXk9XCJmbGV4XCIgZ2FwPXsxfSBmbGV4V3JhcD1cIndyYXBcIj5cclxuICAgICAgICAgICAgICB7cmVjaXBlVHlwZXMubWFwKCh0eXBlKSA9PiAoXHJcbiAgICAgICAgICAgICAgICA8Q2hpcFxyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJjdXN0b20tY2hpcFwiXHJcbiAgICAgICAgICAgICAgICAgIGtleT17dHlwZS5pZH1cclxuICAgICAgICAgICAgICAgICAgbGFiZWw9e3R5cGUubGFiZWx9XHJcbiAgICAgICAgICAgICAgICAgIHZhcmlhbnQ9e1xyXG4gICAgICAgICAgICAgICAgICAgIGZvcm1EYXRhLnJlY2lwZVR5cGUgPT09IHR5cGUuaWQgPyBcImZpbGxlZFwiIDogXCJvdXRsaW5lZFwiXHJcbiAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgY29sb3I9e2Zvcm1EYXRhLnJlY2lwZVR5cGUgPT09IHR5cGUuaWQgPyBcInN1Y2Nlc3NcIiA6IFwiZGVmYXVsdFwifVxyXG4gICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PlxyXG4gICAgICAgICAgICAgICAgICAgIHNldEZvcm1EYXRhKChwcmV2KSA9PiAoeyAuLi5wcmV2LCByZWNpcGVUeXBlOiB0eXBlLmlkIH0pKVxyXG4gICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICA8L0JveD5cclxuICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZm9ybS1zZWN0aW9uXCI+XHJcbiAgICAgICAgICAgIDxUeXBvZ3JhcGh5IHZhcmlhbnQ9XCJzdWJ0aXRsZTFcIiBmb250V2VpZ2h0PXs2MDB9PlxyXG4gICAgICAgICAgICAgIFByZWZlcmVuY2VzXHJcbiAgICAgICAgICAgIDwvVHlwb2dyYXBoeT5cclxuICAgICAgICAgICAgPEJveCBjbGFzc05hbWU9XCJjaGlwLXJvd1wiPlxyXG4gICAgICAgICAgICAgIHtwcmVmZXJlbmNlT3B0aW9ucy5tYXAoKHByZWYpID0+IChcclxuICAgICAgICAgICAgICAgIDxDaGlwXHJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImN1c3RvbS1jaGlwXCJcclxuICAgICAgICAgICAgICAgICAga2V5PXtwcmVmfVxyXG4gICAgICAgICAgICAgICAgICBsYWJlbD17cHJlZn1cclxuICAgICAgICAgICAgICAgICAgdmFyaWFudD17cHJlZmVyZW5jZXMuaW5jbHVkZXMocHJlZikgPyBcImZpbGxlZFwiIDogXCJvdXRsaW5lZFwifVxyXG4gICAgICAgICAgICAgICAgICBjb2xvcj17cHJlZmVyZW5jZXMuaW5jbHVkZXMocHJlZikgPyBcInN1Y2Nlc3NcIiA6IHVuZGVmaW5lZH1cclxuICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT5cclxuICAgICAgICAgICAgICAgICAgICBoYW5kbGVDaGlwVG9nZ2xlKHByZWYsIHByZWZlcmVuY2VzLCBzZXRQcmVmZXJlbmNlcylcclxuICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICBvbkRlbGV0ZT17XHJcbiAgICAgICAgICAgICAgICAgICAgY3VzdG9tUHJlZmVyZW5jZXMuaW5jbHVkZXMocHJlZilcclxuICAgICAgICAgICAgICAgICAgICAgID8gKCkgPT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICBoYW5kbGVEZWxldGVDdXN0b20oXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBwcmVmLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgc2V0UHJlZmVyZW5jZU9wdGlvbnMsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBzZXRDdXN0b21QcmVmZXJlbmNlcyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNldFByZWZlcmVuY2VzXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgKVxyXG4gICAgICAgICAgICAgICAgICAgICAgOiB1bmRlZmluZWRcclxuICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgPC9Cb3g+XHJcbiAgICAgICAgICAgIDxCb3hcclxuICAgICAgICAgICAgICBkaXNwbGF5PVwiZmxleFwiXHJcbiAgICAgICAgICAgICAgZ2FwPXsxfVxyXG4gICAgICAgICAgICAgIHN4PXt7IGhlaWdodDogNDAsIGFsaWduSXRlbXM6IFwiY2VudGVyXCIgfX1cclxuICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgIDxUZXh0RmllbGRcclxuICAgICAgICAgICAgICAgIGxhYmVsPVwiQWRkIFByZWZlcmVuY2VcIlxyXG4gICAgICAgICAgICAgICAgc2l6ZT1cInNtYWxsXCJcclxuICAgICAgICAgICAgICAgIHZhbHVlPXtwcmVmZXJlbmNlSW5wdXR9XHJcbiAgICAgICAgICAgICAgICBjb2xvcj1cInN1Y2Nlc3NcIlxyXG4gICAgICAgICAgICAgICAgZm9jdXNlZFxyXG4gICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRQcmVmZXJlbmNlSW5wdXQoZS50YXJnZXQudmFsdWUpfVxyXG4gICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgPEJ1dHRvblxyXG4gICAgICAgICAgICAgICAgdmFyaWFudD1cIm91dGxpbmVkXCJcclxuICAgICAgICAgICAgICAgIGNvbG9yPVwic3VjY2Vzc1wiXHJcbiAgICAgICAgICAgICAgICBhcmlhLWxhYmVsPVwiYWRkLXByZWZlcmVuY2VcIlxyXG4gICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT5cclxuICAgICAgICAgICAgICAgICAgaGFuZGxlQWRkQ2hpcChcclxuICAgICAgICAgICAgICAgICAgICBwcmVmZXJlbmNlSW5wdXQsXHJcbiAgICAgICAgICAgICAgICAgICAgcHJlZmVyZW5jZU9wdGlvbnMsXHJcbiAgICAgICAgICAgICAgICAgICAgc2V0UHJlZmVyZW5jZU9wdGlvbnMsXHJcbiAgICAgICAgICAgICAgICAgICAgY3VzdG9tUHJlZmVyZW5jZXMsXHJcbiAgICAgICAgICAgICAgICAgICAgc2V0Q3VzdG9tUHJlZmVyZW5jZXMsXHJcbiAgICAgICAgICAgICAgICAgICAgcHJlZmVyZW5jZXMsXHJcbiAgICAgICAgICAgICAgICAgICAgc2V0UHJlZmVyZW5jZXMsXHJcbiAgICAgICAgICAgICAgICAgICAgc2V0UHJlZmVyZW5jZUlucHV0XHJcbiAgICAgICAgICAgICAgICAgIClcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICBBZGRcclxuICAgICAgICAgICAgICA8L0J1dHRvbj5cclxuICAgICAgICAgICAgPC9Cb3g+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZvcm0tc2VjdGlvblwiPlxyXG4gICAgICAgICAgICA8VHlwb2dyYXBoeSB2YXJpYW50PVwic3VidGl0bGUxXCIgZm9udFdlaWdodD17NjAwfT5cclxuICAgICAgICAgICAgICBBbGxlcmdpZXNcclxuICAgICAgICAgICAgPC9UeXBvZ3JhcGh5PlxyXG4gICAgICAgICAgICA8Qm94IGNsYXNzTmFtZT1cImNoaXAtcm93XCI+XHJcbiAgICAgICAgICAgICAge2FsbGVyZ3lPcHRpb25zLm1hcCgoYWxsZXJneSkgPT4gKFxyXG4gICAgICAgICAgICAgICAgPENoaXBcclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiY3VzdG9tLWNoaXBcIlxyXG4gICAgICAgICAgICAgICAgICBrZXk9e2FsbGVyZ3l9XHJcbiAgICAgICAgICAgICAgICAgIGxhYmVsPXthbGxlcmd5fVxyXG4gICAgICAgICAgICAgICAgICB2YXJpYW50PXthbGxlcmdpZXMuaW5jbHVkZXMoYWxsZXJneSkgPyBcImZpbGxlZFwiIDogXCJvdXRsaW5lZFwifVxyXG4gICAgICAgICAgICAgICAgICBjb2xvcj17YWxsZXJnaWVzLmluY2x1ZGVzKGFsbGVyZ3kpID8gXCJzdWNjZXNzXCIgOiB1bmRlZmluZWR9XHJcbiAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+XHJcbiAgICAgICAgICAgICAgICAgICAgaGFuZGxlQ2hpcFRvZ2dsZShhbGxlcmd5LCBhbGxlcmdpZXMsIHNldEFsbGVyZ2llcylcclxuICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICBvbkRlbGV0ZT17XHJcbiAgICAgICAgICAgICAgICAgICAgY3VzdG9tQWxsZXJnaWVzLmluY2x1ZGVzKGFsbGVyZ3kpXHJcbiAgICAgICAgICAgICAgICAgICAgICA/ICgpID0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgaGFuZGxlRGVsZXRlQ3VzdG9tKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgYWxsZXJneSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNldEFsbGVyZ3lPcHRpb25zLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgc2V0Q3VzdG9tQWxsZXJnaWVzLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgc2V0QWxsZXJnaWVzXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgKVxyXG4gICAgICAgICAgICAgICAgICAgICAgOiB1bmRlZmluZWRcclxuICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgPC9Cb3g+XHJcbiAgICAgICAgICAgIDxCb3ggZGlzcGxheT1cImZsZXhcIiBnYXA9ezF9IG10PXsxfT5cclxuICAgICAgICAgICAgICA8VGV4dEZpZWxkXHJcbiAgICAgICAgICAgICAgICBsYWJlbD1cIkFkZCBBbGxlcmd5XCJcclxuICAgICAgICAgICAgICAgIHNpemU9XCJzbWFsbFwiXHJcbiAgICAgICAgICAgICAgICBmb2N1c2VkXHJcbiAgICAgICAgICAgICAgICBjb2xvcj1cInN1Y2Nlc3NcIlxyXG4gICAgICAgICAgICAgICAgdmFsdWU9e2FsbGVyZ3lJbnB1dH1cclxuICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0QWxsZXJneUlucHV0KGUudGFyZ2V0LnZhbHVlKX1cclxuICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgIDxCdXR0b25cclxuICAgICAgICAgICAgICAgIHZhcmlhbnQ9XCJvdXRsaW5lZFwiXHJcbiAgICAgICAgICAgICAgICBjb2xvcj1cInN1Y2Nlc3NcIlxyXG4gICAgICAgICAgICAgICAgYXJpYS1sYWJlbD1cImFkZC1hbGxlcmd5XCJcclxuICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+XHJcbiAgICAgICAgICAgICAgICAgIGhhbmRsZUFkZENoaXAoXHJcbiAgICAgICAgICAgICAgICAgICAgYWxsZXJneUlucHV0LFxyXG4gICAgICAgICAgICAgICAgICAgIGFsbGVyZ3lPcHRpb25zLFxyXG4gICAgICAgICAgICAgICAgICAgIHNldEFsbGVyZ3lPcHRpb25zLFxyXG4gICAgICAgICAgICAgICAgICAgIGN1c3RvbUFsbGVyZ2llcyxcclxuICAgICAgICAgICAgICAgICAgICBzZXRDdXN0b21BbGxlcmdpZXMsXHJcbiAgICAgICAgICAgICAgICAgICAgYWxsZXJnaWVzLFxyXG4gICAgICAgICAgICAgICAgICAgIHNldEFsbGVyZ2llcyxcclxuICAgICAgICAgICAgICAgICAgICBzZXRBbGxlcmd5SW5wdXRcclxuICAgICAgICAgICAgICAgICAgKVxyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgIEFkZFxyXG4gICAgICAgICAgICAgIDwvQnV0dG9uPlxyXG4gICAgICAgICAgICA8L0JveD5cclxuICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZm9ybS1zZWN0aW9uXCI+XHJcbiAgICAgICAgICAgIDxUeXBvZ3JhcGh5IHZhcmlhbnQ9XCJzdWJ0aXRsZTFcIiBmb250V2VpZ2h0PXs2MDB9PlxyXG4gICAgICAgICAgICAgIE5vdGVzIChPcHRpb25hbClcclxuICAgICAgICAgICAgPC9UeXBvZ3JhcGh5PlxyXG4gICAgICAgICAgICA8VGV4dEZpZWxkXHJcbiAgICAgICAgICAgICAgbXVsdGlsaW5lXHJcbiAgICAgICAgICAgICAgcm93cz17M31cclxuICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkFueSBzcGVjaWZpYyBwcmVmZXJlbmNlcyBvciBpbnN0cnVjdGlvbnM/XCJcclxuICAgICAgICAgICAgICBmdWxsV2lkdGhcclxuICAgICAgICAgICAgICBjb2xvcj1cInN1Y2Nlc3NcIlxyXG4gICAgICAgICAgICAgIHZhbHVlPXtmb3JtRGF0YS5ub3Rlc31cclxuICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+XHJcbiAgICAgICAgICAgICAgICBzZXRGb3JtRGF0YSh7IC4uLmZvcm1EYXRhLCBub3RlczogZS50YXJnZXQudmFsdWUgfSlcclxuICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICA8Qm94IHRleHRBbGlnbj1cImNlbnRlclwiIG10PXs0fT5cclxuICAgICAgICAgICAgPEJ1dHRvblxyXG4gICAgICAgICAgICAgIHR5cGU9XCJzdWJtaXRcIlxyXG4gICAgICAgICAgICAgIHZhcmlhbnQ9XCJjb250YWluZWRcIlxyXG4gICAgICAgICAgICAgIGNvbG9yPVwic3VjY2Vzc1wiXHJcbiAgICAgICAgICAgICAgc3g9e3sgcHg6IDQsIHB5OiAxLjUsIGZvbnRXZWlnaHQ6IDUwMCB9fVxyXG4gICAgICAgICAgICAgIGRpc2FibGVkPXtpc0xvYWRpbmd9XHJcbiAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICB7aXNMb2FkaW5nID8gKFxyXG4gICAgICAgICAgICAgICAgPENpcmN1bGFyUHJvZ3Jlc3Mgc2l6ZT17MjR9IHN4PXt7IGNvbG9yOiBcIiNmZmZcIiB9fSAvPlxyXG4gICAgICAgICAgICAgICkgOiAoXHJcbiAgICAgICAgICAgICAgICBcIkdlbmVyYXRlIFJlY2lwZVwiXHJcbiAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgPC9CdXR0b24+XHJcbiAgICAgICAgICA8L0JveD5cclxuICAgICAgICA8L2Zvcm0+XHJcbiAgICAgIDwvQm94PlxyXG4gICAgPC9Db250YWluZXI+XHJcbiAgKTtcclxufVxyXG5cclxuZXhwb3J0IGRlZmF1bHQgUmVjaXBlR2VuZXJhdGlvbjtcclxuIl0sImZpbGUiOiJDOi9Vc2Vycy9zX21hci9jczMyL1NuYWNrU3RhY2svY2xpZW50L3NyYy9wYWdlcy9SZWNpcGVHZW5lcmF0aW9uLnRzeCJ9