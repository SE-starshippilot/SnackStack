import {
  capitalize
} from "/node_modules/.vite/deps/chunk-TSMFREGN.js?v=4d3a3d4b";

// node_modules/@mui/material/esm/utils/capitalize.js
var capitalize_default = capitalize;

export {
  capitalize_default
};
//# sourceMappingURL=chunk-NTONOVYZ.js.map
