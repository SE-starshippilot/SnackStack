import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/RecipeTableRow/RecipeTableRow.tsx");import { jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/s_mar/cs32/SnackStack/client/src/components/RecipeTableRow/RecipeTableRow.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=4d3a3d4b"; const React = __vite__cjsImport3_react.__esModule ? __vite__cjsImport3_react.default : __vite__cjsImport3_react; const useState = __vite__cjsImport3_react["useState"]; const useCallback = __vite__cjsImport3_react["useCallback"];
import { TableRow, IconButton, Collapse } from "/node_modules/.vite/deps/@mui_material.js?v=4d3a3d4b";
import IcecreamOutlinedIcon from "/node_modules/.vite/deps/@mui_icons-material_IcecreamOutlined.js?v=4d3a3d4b";
import { StyledTableRow, StyledTableCell } from "/src/styles/RecipeTableStyles.tsx";
import { ExpandedRecipeDetails } from "/src/components/RecipeTableRow/ExpandedRecipeDetails.tsx";
import { FavoriteButton } from "/src/components/RecipeTableRow/FavoriteButton.tsx";
const RecipeTableRowComponent = ({
  row,
  onToggleFavorite
}) => {
  _s();
  const [open, setOpen] = useState(false);
  const handleClick = useCallback(() => {
    setOpen((prev) => !prev);
  }, []);
  return /* @__PURE__ */ jsxDEV(React.Fragment, { children: [
    /* @__PURE__ */ jsxDEV(StyledTableRow, { onClick: handleClick, sx: {
      "& > *": {
        borderBottom: "unset"
      }
    }, children: [
      /* @__PURE__ */ jsxDEV(StyledTableCell, { children: /* @__PURE__ */ jsxDEV(IconButton, { "aria-label": "expand row", size: "small", sx: {
        transition: "transform 0.3s",
        transform: open ? "rotate(90deg)" : "rotate(0deg)",
        pointerEvents: "none"
      }, children: /* @__PURE__ */ jsxDEV(IcecreamOutlinedIcon, {}, void 0, false, {
        fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/components/RecipeTableRow/RecipeTableRow.tsx",
        lineNumber: 34,
        columnNumber: 13
      }, this) }, void 0, false, {
        fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/components/RecipeTableRow/RecipeTableRow.tsx",
        lineNumber: 29,
        columnNumber: 11
      }, this) }, void 0, false, {
        fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/components/RecipeTableRow/RecipeTableRow.tsx",
        lineNumber: 28,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(StyledTableCell, { children: row.recipeName }, void 0, false, {
        fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/components/RecipeTableRow/RecipeTableRow.tsx",
        lineNumber: 37,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(StyledTableCell, { children: row.createdAt }, void 0, false, {
        fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/components/RecipeTableRow/RecipeTableRow.tsx",
        lineNumber: 38,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(StyledTableCell, { children: row.recipeDescription }, void 0, false, {
        fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/components/RecipeTableRow/RecipeTableRow.tsx",
        lineNumber: 39,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(StyledTableCell, { children: row.recipeIngredients.map((i) => i.ingredientName).join(", ") }, void 0, false, {
        fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/components/RecipeTableRow/RecipeTableRow.tsx",
        lineNumber: 40,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(StyledTableCell, { children: /* @__PURE__ */ jsxDEV(FavoriteButton, { recipe: row, onToggleFavorite }, void 0, false, {
        fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/components/RecipeTableRow/RecipeTableRow.tsx",
        lineNumber: 44,
        columnNumber: 11
      }, this) }, void 0, false, {
        fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/components/RecipeTableRow/RecipeTableRow.tsx",
        lineNumber: 43,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/components/RecipeTableRow/RecipeTableRow.tsx",
      lineNumber: 23,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(TableRow, { children: /* @__PURE__ */ jsxDEV(StyledTableCell, { style: {
      paddingBottom: 0,
      paddingTop: 0
    }, colSpan: 6, children: /* @__PURE__ */ jsxDEV(Collapse, { in: open, timeout: "auto", unmountOnExit: true, children: /* @__PURE__ */ jsxDEV(ExpandedRecipeDetails, { recipe: row }, void 0, false, {
      fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/components/RecipeTableRow/RecipeTableRow.tsx",
      lineNumber: 53,
      columnNumber: 13
    }, this) }, void 0, false, {
      fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/components/RecipeTableRow/RecipeTableRow.tsx",
      lineNumber: 52,
      columnNumber: 11
    }, this) }, void 0, false, {
      fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/components/RecipeTableRow/RecipeTableRow.tsx",
      lineNumber: 48,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/components/RecipeTableRow/RecipeTableRow.tsx",
      lineNumber: 47,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/components/RecipeTableRow/RecipeTableRow.tsx",
    lineNumber: 22,
    columnNumber: 10
  }, this);
};
_s(RecipeTableRowComponent, "2QDwBKFJMwdJsoCuk+zKAH+Weao=");
_c = RecipeTableRowComponent;
export const RecipeTableRow = React.memo(RecipeTableRowComponent, (prevProps, nextProps) => {
  return prevProps.row.id === nextProps.row.id && prevProps.row.isFavorite === nextProps.row.isFavorite;
});
_c2 = RecipeTableRow;
var _c, _c2;
$RefreshReg$(_c, "RecipeTableRowComponent");
$RefreshReg$(_c2, "RecipeTableRow");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/s_mar/cs32/SnackStack/client/src/components/RecipeTableRow/RecipeTableRow.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBMENZOzs7Ozs7Ozs7Ozs7Ozs7O0FBMUNaLE9BQU9BLFNBQVNDLFVBQVVDLG1CQUFtQjtBQUM3QyxTQUFTQyxVQUFxQkMsWUFBWUMsZ0JBQWdCO0FBQzFELE9BQU9DLDBCQUEwQjtBQUVqQyxTQUNFQyxnQkFDQUMsdUJBQ0s7QUFDUCxTQUFTQyw2QkFBNkI7QUFDdEMsU0FBU0Msc0JBQXNCO0FBTy9CLE1BQU1DLDBCQUF5REEsQ0FBQztBQUFBLEVBQzlEQztBQUFBQSxFQUNBQztBQUNGLE1BQU07QUFBQUMsS0FBQTtBQUNKLFFBQU0sQ0FBQ0MsTUFBTUMsT0FBTyxJQUFJZixTQUFTLEtBQUs7QUFFdEMsUUFBTWdCLGNBQWNmLFlBQVksTUFBTTtBQUNwQ2MsWUFBU0UsVUFBUyxDQUFDQSxJQUFJO0FBQUEsRUFDekIsR0FBRyxFQUFFO0FBRUwsU0FDRSx1QkFBQyxNQUFNLFVBQU4sRUFDQztBQUFBLDJCQUFDLGtCQUNDLFNBQVNELGFBQ1QsSUFBSTtBQUFBLE1BQUUsU0FBUztBQUFBLFFBQUVFLGNBQWM7QUFBQSxNQUFRO0FBQUEsSUFBRSxHQUV6QztBQUFBLDZCQUFDLG1CQUNDLGlDQUFDLGNBQ0MsY0FBVyxjQUNYLE1BQUssU0FDTCxJQUFJO0FBQUEsUUFDRkMsWUFBWTtBQUFBLFFBQ1pDLFdBQVdOLE9BQU8sa0JBQWtCO0FBQUEsUUFDcENPLGVBQWU7QUFBQSxNQUNqQixHQUVBLGlDQUFDLDBCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBcUIsS0FUdkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQVVBLEtBWEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQVlBO0FBQUEsTUFDQSx1QkFBQyxtQkFBaUJWLGNBQUlXLGNBQXRCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBaUM7QUFBQSxNQUNqQyx1QkFBQyxtQkFBaUJYLGNBQUlZLGFBQXRCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBZ0M7QUFBQSxNQUNoQyx1QkFBQyxtQkFBaUJaLGNBQUlhLHFCQUF0QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXdDO0FBQUEsTUFDeEMsdUJBQUMsbUJBQ0ViLGNBQUljLGtCQUFrQkMsSUFBS0MsT0FBTUEsRUFBRUMsY0FBYyxFQUFFQyxLQUFLLElBQUksS0FEL0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBO0FBQUEsTUFDQSx1QkFBQyxtQkFDQyxpQ0FBQyxrQkFBZSxRQUFRbEIsS0FBSyxvQkFBN0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFnRSxLQURsRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRUE7QUFBQSxTQXpCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBMEJBO0FBQUEsSUFDQSx1QkFBQyxZQUNDLGlDQUFDLG1CQUNDLE9BQU87QUFBQSxNQUFFbUIsZUFBZTtBQUFBLE1BQUdDLFlBQVk7QUFBQSxJQUFFLEdBQ3pDLFNBQVMsR0FFVCxpQ0FBQyxZQUFTLElBQUlqQixNQUFNLFNBQVEsUUFBTyxlQUFhLE1BQzlDLGlDQUFDLHlCQUFzQixRQUFRSCxPQUEvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQW1DLEtBRHJDO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FFQSxLQU5GO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FPQSxLQVJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FTQTtBQUFBLE9BckNGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FzQ0E7QUFFSjtBQUVBRSxHQXJETUgseUJBQXNEO0FBQUFzQixLQUF0RHRCO0FBc0RDLGFBQU11QixpQkFBaUJsQyxNQUFNbUMsS0FDbEN4Qix5QkFDQSxDQUFDeUIsV0FBV0MsY0FBYztBQUN4QixTQUNFRCxVQUFVeEIsSUFBSTBCLE9BQU9ELFVBQVV6QixJQUFJMEIsTUFDbkNGLFVBQVV4QixJQUFJMkIsZUFBZUYsVUFBVXpCLElBQUkyQjtBQUUvQyxDQUNGO0FBQUVDLE1BUldOO0FBQWMsSUFBQUQsSUFBQU87QUFBQUMsYUFBQVIsSUFBQTtBQUFBUSxhQUFBRCxLQUFBIiwibmFtZXMiOlsiUmVhY3QiLCJ1c2VTdGF0ZSIsInVzZUNhbGxiYWNrIiwiVGFibGVSb3ciLCJJY29uQnV0dG9uIiwiQ29sbGFwc2UiLCJJY2VjcmVhbU91dGxpbmVkSWNvbiIsIlN0eWxlZFRhYmxlUm93IiwiU3R5bGVkVGFibGVDZWxsIiwiRXhwYW5kZWRSZWNpcGVEZXRhaWxzIiwiRmF2b3JpdGVCdXR0b24iLCJSZWNpcGVUYWJsZVJvd0NvbXBvbmVudCIsInJvdyIsIm9uVG9nZ2xlRmF2b3JpdGUiLCJfcyIsIm9wZW4iLCJzZXRPcGVuIiwiaGFuZGxlQ2xpY2siLCJwcmV2IiwiYm9yZGVyQm90dG9tIiwidHJhbnNpdGlvbiIsInRyYW5zZm9ybSIsInBvaW50ZXJFdmVudHMiLCJyZWNpcGVOYW1lIiwiY3JlYXRlZEF0IiwicmVjaXBlRGVzY3JpcHRpb24iLCJyZWNpcGVJbmdyZWRpZW50cyIsIm1hcCIsImkiLCJpbmdyZWRpZW50TmFtZSIsImpvaW4iLCJwYWRkaW5nQm90dG9tIiwicGFkZGluZ1RvcCIsIl9jIiwiUmVjaXBlVGFibGVSb3ciLCJtZW1vIiwicHJldlByb3BzIiwibmV4dFByb3BzIiwiaWQiLCJpc0Zhdm9yaXRlIiwiX2MyIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiUmVjaXBlVGFibGVSb3cudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBSZWFjdCwgeyB1c2VTdGF0ZSwgdXNlQ2FsbGJhY2sgfSBmcm9tIFwicmVhY3RcIjtcclxuaW1wb3J0IHsgVGFibGVSb3csIFRhYmxlQ2VsbCwgSWNvbkJ1dHRvbiwgQ29sbGFwc2UgfSBmcm9tIFwiQG11aS9tYXRlcmlhbFwiO1xyXG5pbXBvcnQgSWNlY3JlYW1PdXRsaW5lZEljb24gZnJvbSBcIkBtdWkvaWNvbnMtbWF0ZXJpYWwvSWNlY3JlYW1PdXRsaW5lZFwiO1xyXG5pbXBvcnQgeyBSZWNpcGUgfSBmcm9tIFwiLi4vLi4vdHlwZXMvcmVjaXBlXCI7XHJcbmltcG9ydCB7XHJcbiAgU3R5bGVkVGFibGVSb3csXHJcbiAgU3R5bGVkVGFibGVDZWxsLFxyXG59IGZyb20gXCIuLi8uLi9zdHlsZXMvUmVjaXBlVGFibGVTdHlsZXNcIjtcclxuaW1wb3J0IHsgRXhwYW5kZWRSZWNpcGVEZXRhaWxzIH0gZnJvbSBcIi4vRXhwYW5kZWRSZWNpcGVEZXRhaWxzXCI7XHJcbmltcG9ydCB7IEZhdm9yaXRlQnV0dG9uIH0gZnJvbSBcIi4vRmF2b3JpdGVCdXR0b25cIjtcclxuXHJcbmludGVyZmFjZSBSZWNpcGVUYWJsZVJvd1Byb3BzIHtcclxuICByb3c6IFJlY2lwZTtcclxuICBvblRvZ2dsZUZhdm9yaXRlOiAocmVjaXBlOiBSZWNpcGUpID0+IHZvaWQ7XHJcbn1cclxuXHJcbmNvbnN0IFJlY2lwZVRhYmxlUm93Q29tcG9uZW50OiBSZWFjdC5GQzxSZWNpcGVUYWJsZVJvd1Byb3BzPiA9ICh7XHJcbiAgcm93LFxyXG4gIG9uVG9nZ2xlRmF2b3JpdGUsXHJcbn0pID0+IHtcclxuICBjb25zdCBbb3Blbiwgc2V0T3Blbl0gPSB1c2VTdGF0ZShmYWxzZSk7XHJcblxyXG4gIGNvbnN0IGhhbmRsZUNsaWNrID0gdXNlQ2FsbGJhY2soKCkgPT4ge1xyXG4gICAgc2V0T3BlbigocHJldikgPT4gIXByZXYpO1xyXG4gIH0sIFtdKTtcclxuXHJcbiAgcmV0dXJuIChcclxuICAgIDxSZWFjdC5GcmFnbWVudD5cclxuICAgICAgPFN0eWxlZFRhYmxlUm93XHJcbiAgICAgICAgb25DbGljaz17aGFuZGxlQ2xpY2t9XHJcbiAgICAgICAgc3g9e3sgXCImID4gKlwiOiB7IGJvcmRlckJvdHRvbTogXCJ1bnNldFwiIH0gfX1cclxuICAgICAgPlxyXG4gICAgICAgIDxTdHlsZWRUYWJsZUNlbGw+XHJcbiAgICAgICAgICA8SWNvbkJ1dHRvblxyXG4gICAgICAgICAgICBhcmlhLWxhYmVsPVwiZXhwYW5kIHJvd1wiXHJcbiAgICAgICAgICAgIHNpemU9XCJzbWFsbFwiXHJcbiAgICAgICAgICAgIHN4PXt7XHJcbiAgICAgICAgICAgICAgdHJhbnNpdGlvbjogXCJ0cmFuc2Zvcm0gMC4zc1wiLFxyXG4gICAgICAgICAgICAgIHRyYW5zZm9ybTogb3BlbiA/IFwicm90YXRlKDkwZGVnKVwiIDogXCJyb3RhdGUoMGRlZylcIixcclxuICAgICAgICAgICAgICBwb2ludGVyRXZlbnRzOiBcIm5vbmVcIixcclxuICAgICAgICAgICAgfX1cclxuICAgICAgICAgID5cclxuICAgICAgICAgICAgPEljZWNyZWFtT3V0bGluZWRJY29uIC8+XHJcbiAgICAgICAgICA8L0ljb25CdXR0b24+XHJcbiAgICAgICAgPC9TdHlsZWRUYWJsZUNlbGw+XHJcbiAgICAgICAgPFN0eWxlZFRhYmxlQ2VsbD57cm93LnJlY2lwZU5hbWV9PC9TdHlsZWRUYWJsZUNlbGw+XHJcbiAgICAgICAgPFN0eWxlZFRhYmxlQ2VsbD57cm93LmNyZWF0ZWRBdH08L1N0eWxlZFRhYmxlQ2VsbD5cclxuICAgICAgICA8U3R5bGVkVGFibGVDZWxsPntyb3cucmVjaXBlRGVzY3JpcHRpb259PC9TdHlsZWRUYWJsZUNlbGw+XHJcbiAgICAgICAgPFN0eWxlZFRhYmxlQ2VsbD5cclxuICAgICAgICAgIHtyb3cucmVjaXBlSW5ncmVkaWVudHMubWFwKChpKSA9PiBpLmluZ3JlZGllbnROYW1lKS5qb2luKFwiLCBcIil9XHJcbiAgICAgICAgPC9TdHlsZWRUYWJsZUNlbGw+XHJcbiAgICAgICAgPFN0eWxlZFRhYmxlQ2VsbD5cclxuICAgICAgICAgIDxGYXZvcml0ZUJ1dHRvbiByZWNpcGU9e3Jvd30gb25Ub2dnbGVGYXZvcml0ZT17b25Ub2dnbGVGYXZvcml0ZX0gLz5cclxuICAgICAgICA8L1N0eWxlZFRhYmxlQ2VsbD5cclxuICAgICAgPC9TdHlsZWRUYWJsZVJvdz5cclxuICAgICAgPFRhYmxlUm93PlxyXG4gICAgICAgIDxTdHlsZWRUYWJsZUNlbGxcclxuICAgICAgICAgIHN0eWxlPXt7IHBhZGRpbmdCb3R0b206IDAsIHBhZGRpbmdUb3A6IDAgfX1cclxuICAgICAgICAgIGNvbFNwYW49ezZ9XHJcbiAgICAgICAgPlxyXG4gICAgICAgICAgPENvbGxhcHNlIGluPXtvcGVufSB0aW1lb3V0PVwiYXV0b1wiIHVubW91bnRPbkV4aXQ+XHJcbiAgICAgICAgICAgIDxFeHBhbmRlZFJlY2lwZURldGFpbHMgcmVjaXBlPXtyb3d9IC8+XHJcbiAgICAgICAgICA8L0NvbGxhcHNlPlxyXG4gICAgICAgIDwvU3R5bGVkVGFibGVDZWxsPlxyXG4gICAgICA8L1RhYmxlUm93PlxyXG4gICAgPC9SZWFjdC5GcmFnbWVudD5cclxuICApO1xyXG59O1xyXG5cclxuLy8gT25seSByZS1yZW5kZXIgd2hlbiByb3cgZGF0YSBvciBmYXZvcml0ZSBzdGF0dXMgY2hhbmdlc1xyXG5leHBvcnQgY29uc3QgUmVjaXBlVGFibGVSb3cgPSBSZWFjdC5tZW1vKFxyXG4gIFJlY2lwZVRhYmxlUm93Q29tcG9uZW50LFxyXG4gIChwcmV2UHJvcHMsIG5leHRQcm9wcykgPT4ge1xyXG4gICAgcmV0dXJuIChcclxuICAgICAgcHJldlByb3BzLnJvdy5pZCA9PT0gbmV4dFByb3BzLnJvdy5pZCAmJlxyXG4gICAgICBwcmV2UHJvcHMucm93LmlzRmF2b3JpdGUgPT09IG5leHRQcm9wcy5yb3cuaXNGYXZvcml0ZVxyXG4gICAgKTtcclxuICB9XHJcbik7XHJcbiJdLCJmaWxlIjoiQzovVXNlcnMvc19tYXIvY3MzMi9TbmFja1N0YWNrL2NsaWVudC9zcmMvY29tcG9uZW50cy9SZWNpcGVUYWJsZVJvdy9SZWNpcGVUYWJsZVJvdy50c3gifQ==