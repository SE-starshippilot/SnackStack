"use client";
import "/node_modules/.vite/deps/chunk-C6WWHQR7.js?v=4d3a3d4b";
import "/node_modules/.vite/deps/chunk-JQS66VEU.js?v=4d3a3d4b";
import {
  createSvgIcon
} from "/node_modules/.vite/deps/chunk-MLPXR4TV.js?v=4d3a3d4b";
import "/node_modules/.vite/deps/chunk-JFUJMKGI.js?v=4d3a3d4b";
import "/node_modules/.vite/deps/chunk-NTONOVYZ.js?v=4d3a3d4b";
import "/node_modules/.vite/deps/chunk-ZZNIRIXO.js?v=4d3a3d4b";
import "/node_modules/.vite/deps/chunk-TSMFREGN.js?v=4d3a3d4b";
import "/node_modules/.vite/deps/chunk-64FVIM6J.js?v=4d3a3d4b";
import {
  require_jsx_runtime
} from "/node_modules/.vite/deps/chunk-TOXUORXJ.js?v=4d3a3d4b";
import "/node_modules/.vite/deps/chunk-K5YNGTCN.js?v=4d3a3d4b";
import {
  __toESM
} from "/node_modules/.vite/deps/chunk-ZC22LKFR.js?v=4d3a3d4b";

// node_modules/@mui/icons-material/esm/FavoriteBorder.js
var import_jsx_runtime = __toESM(require_jsx_runtime());
var FavoriteBorder_default = createSvgIcon((0, import_jsx_runtime.jsx)("path", {
  d: "M16.5 3c-1.74 0-3.41.81-4.5 2.09C10.91 3.81 9.24 3 7.5 3 4.42 3 2 5.42 2 8.5c0 3.78 3.4 6.86 8.55 11.54L12 21.35l1.45-1.32C18.6 15.36 22 12.28 22 8.5 22 5.42 19.58 3 16.5 3m-4.4 15.55-.1.1-.1-.1C7.14 14.24 4 11.39 4 8.5 4 6.5 5.5 5 7.5 5c1.54 0 3.04.99 3.57 2.36h1.87C13.46 5.99 14.96 5 16.5 5c2 0 3.5 1.5 3.5 3.5 0 2.89-3.14 5.74-7.9 10.05"
}), "FavoriteBorder");
export {
  FavoriteBorder_default as default
};
//# sourceMappingURL=@mui_icons-material_FavoriteBorder.js.map
