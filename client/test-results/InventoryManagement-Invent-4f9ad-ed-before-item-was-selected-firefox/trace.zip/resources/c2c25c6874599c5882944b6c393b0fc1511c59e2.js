import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/LoginPromptModal.tsx");import { jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/s_mar/cs32/SnackStack/client/src/components/LoginPromptModal.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=4d3a3d4b"; const useState = __vite__cjsImport3_react["useState"]; const useEffect = __vite__cjsImport3_react["useEffect"];
import { useNavigate } from "/node_modules/.vite/deps/react-router-dom.js?v=4d3a3d4b";
import { useClerk } from "/node_modules/.vite/deps/@clerk_clerk-react.js?v=4d3a3d4b";
import { Dialog, DialogTitle, DialogContent, DialogActions, Button, Typography, Box } from "/node_modules/.vite/deps/@mui_material.js?v=4d3a3d4b";
export default function LoginPromptModal({
  open,
  onClose,
  message = "You need to be logged in to access this feature.",
  returnTo
}) {
  _s();
  const navigate = useNavigate();
  const {
    openSignIn
  } = useClerk();
  const [isClosing, setIsClosing] = useState(false);
  useEffect(() => {
    if (isClosing) {
      const timer = setTimeout(() => {
        setIsClosing(false);
        onClose();
      }, 300);
      return () => clearTimeout(timer);
    }
  }, [isClosing, onClose]);
  const handleClose = () => {
    setIsClosing(true);
  };
  const handleLogin = () => {
    setIsClosing(true);
    setTimeout(() => {
      openSignIn({
        redirectUrl: returnTo || window.location.pathname
      });
    }, 300);
  };
  const handleCancel = () => {
    setIsClosing(true);
    setTimeout(() => {
      navigate("/");
    }, 300);
  };
  return /* @__PURE__ */ jsxDEV(Dialog, { open: open && !isClosing, onClose: handleClose, maxWidth: "sm", fullWidth: true, children: [
    /* @__PURE__ */ jsxDEV(DialogTitle, { children: "Sign in required" }, void 0, false, {
      fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/components/LoginPromptModal.tsx",
      lineNumber: 59,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(DialogContent, { children: /* @__PURE__ */ jsxDEV(Box, { sx: {
      py: 1
    }, children: /* @__PURE__ */ jsxDEV(Typography, { variant: "body1", children: message }, void 0, false, {
      fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/components/LoginPromptModal.tsx",
      lineNumber: 64,
      columnNumber: 11
    }, this) }, void 0, false, {
      fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/components/LoginPromptModal.tsx",
      lineNumber: 61,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/components/LoginPromptModal.tsx",
      lineNumber: 60,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(DialogActions, { children: [
      /* @__PURE__ */ jsxDEV(Button, { onClick: handleCancel, color: "inherit", children: "Cancel" }, void 0, false, {
        fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/components/LoginPromptModal.tsx",
        lineNumber: 70,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(Button, { onClick: handleLogin, variant: "contained", color: "primary", autoFocus: true, children: "Sign In" }, void 0, false, {
        fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/components/LoginPromptModal.tsx",
        lineNumber: 73,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/components/LoginPromptModal.tsx",
      lineNumber: 69,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/components/LoginPromptModal.tsx",
    lineNumber: 58,
    columnNumber: 10
  }, this);
}
_s(LoginPromptModal, "nDhX9HhX8dlMb4wnfYfqt2QlIYE=", false, function() {
  return [useNavigate, useClerk];
});
_c = LoginPromptModal;
var _c;
$RefreshReg$(_c, "LoginPromptModal");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/s_mar/cs32/SnackStack/client/src/components/LoginPromptModal.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBMEVNOzs7Ozs7Ozs7Ozs7Ozs7O0FBMUVOLFNBQVNBLFVBQVVDLGlCQUFpQjtBQUNwQyxTQUFTQyxtQkFBbUI7QUFDNUIsU0FBU0MsZ0JBQWdCO0FBQ3pCLFNBQ0VDLFFBQ0FDLGFBQ0FDLGVBQ0FDLGVBQ0FDLFFBQ0FDLFlBQ0FDLFdBQ0s7QUFTUCx3QkFBd0JDLGlCQUFpQjtBQUFBLEVBQ3ZDQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQyxVQUFVO0FBQUEsRUFDVkM7QUFDcUIsR0FBRztBQUFBQyxLQUFBO0FBQ3hCLFFBQU1DLFdBQVdmLFlBQVk7QUFDN0IsUUFBTTtBQUFBLElBQUVnQjtBQUFBQSxFQUFXLElBQUlmLFNBQVM7QUFDaEMsUUFBTSxDQUFDZ0IsV0FBV0MsWUFBWSxJQUFJcEIsU0FBUyxLQUFLO0FBR2hEQyxZQUFVLE1BQU07QUFDZCxRQUFJa0IsV0FBVztBQUNiLFlBQU1FLFFBQVFDLFdBQVcsTUFBTTtBQUM3QkYscUJBQWEsS0FBSztBQUNsQlAsZ0JBQVE7QUFBQSxNQUNWLEdBQUcsR0FBRztBQUNOLGFBQU8sTUFBTVUsYUFBYUYsS0FBSztBQUFBLElBQ2pDO0FBQUEsRUFDRixHQUFHLENBQUNGLFdBQVdOLE9BQU8sQ0FBQztBQUV2QixRQUFNVyxjQUFjQSxNQUFNO0FBQ3hCSixpQkFBYSxJQUFJO0FBQUEsRUFDbkI7QUFFQSxRQUFNSyxjQUFjQSxNQUFNO0FBRXhCTCxpQkFBYSxJQUFJO0FBR2pCRSxlQUFXLE1BQU07QUFFZkosaUJBQVc7QUFBQSxRQUNUUSxhQUFhWCxZQUFZWSxPQUFPQyxTQUFTQztBQUFBQSxNQUMzQyxDQUFDO0FBQUEsSUFDSCxHQUFHLEdBQUc7QUFBQSxFQUNSO0FBRUEsUUFBTUMsZUFBZUEsTUFBTTtBQUN6QlYsaUJBQWEsSUFBSTtBQUdqQkUsZUFBVyxNQUFNO0FBQ2ZMLGVBQVMsR0FBRztBQUFBLElBQ2QsR0FBRyxHQUFHO0FBQUEsRUFDUjtBQUVBLFNBQ0UsdUJBQUMsVUFDQyxNQUFNTCxRQUFRLENBQUNPLFdBQ2YsU0FBU0ssYUFDVCxVQUFTLE1BQ1QsV0FBUyxNQUVUO0FBQUEsMkJBQUMsZUFBWSxnQ0FBYjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQTZCO0FBQUEsSUFDN0IsdUJBQUMsaUJBQ0MsaUNBQUMsT0FBSSxJQUFJO0FBQUEsTUFBRU8sSUFBSTtBQUFBLElBQUUsR0FDZixpQ0FBQyxjQUFXLFNBQVEsU0FDakJqQixxQkFESDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBRUEsS0FIRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBSUEsS0FMRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBTUE7QUFBQSxJQUNBLHVCQUFDLGlCQUNDO0FBQUEsNkJBQUMsVUFBTyxTQUFTZ0IsY0FBYyxPQUFNLFdBQVUsc0JBQS9DO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQTtBQUFBLE1BQ0EsdUJBQUMsVUFBTyxTQUFTTCxhQUFhLFNBQVEsYUFBWSxPQUFNLFdBQVUsV0FBUyxNQUFDLHVCQUE1RTtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRUE7QUFBQSxTQU5GO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FPQTtBQUFBLE9BckJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FzQkE7QUFFSjtBQUFDVCxHQXhFdUJMLGtCQUFnQjtBQUFBLFVBTXJCVCxhQUNNQyxRQUFRO0FBQUE7QUFBQTZCLEtBUFRyQjtBQUFnQixJQUFBcUI7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbInVzZVN0YXRlIiwidXNlRWZmZWN0IiwidXNlTmF2aWdhdGUiLCJ1c2VDbGVyayIsIkRpYWxvZyIsIkRpYWxvZ1RpdGxlIiwiRGlhbG9nQ29udGVudCIsIkRpYWxvZ0FjdGlvbnMiLCJCdXR0b24iLCJUeXBvZ3JhcGh5IiwiQm94IiwiTG9naW5Qcm9tcHRNb2RhbCIsIm9wZW4iLCJvbkNsb3NlIiwibWVzc2FnZSIsInJldHVyblRvIiwiX3MiLCJuYXZpZ2F0ZSIsIm9wZW5TaWduSW4iLCJpc0Nsb3NpbmciLCJzZXRJc0Nsb3NpbmciLCJ0aW1lciIsInNldFRpbWVvdXQiLCJjbGVhclRpbWVvdXQiLCJoYW5kbGVDbG9zZSIsImhhbmRsZUxvZ2luIiwicmVkaXJlY3RVcmwiLCJ3aW5kb3ciLCJsb2NhdGlvbiIsInBhdGhuYW1lIiwiaGFuZGxlQ2FuY2VsIiwicHkiLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIkxvZ2luUHJvbXB0TW9kYWwudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZVN0YXRlLCB1c2VFZmZlY3QgfSBmcm9tIFwicmVhY3RcIjtcclxuaW1wb3J0IHsgdXNlTmF2aWdhdGUgfSBmcm9tIFwicmVhY3Qtcm91dGVyLWRvbVwiO1xyXG5pbXBvcnQgeyB1c2VDbGVyayB9IGZyb20gXCJAY2xlcmsvY2xlcmstcmVhY3RcIjtcclxuaW1wb3J0IHtcclxuICBEaWFsb2csXHJcbiAgRGlhbG9nVGl0bGUsXHJcbiAgRGlhbG9nQ29udGVudCxcclxuICBEaWFsb2dBY3Rpb25zLFxyXG4gIEJ1dHRvbixcclxuICBUeXBvZ3JhcGh5LFxyXG4gIEJveCxcclxufSBmcm9tIFwiQG11aS9tYXRlcmlhbFwiO1xyXG5cclxuaW50ZXJmYWNlIExvZ2luUHJvbXB0TW9kYWxQcm9wcyB7XHJcbiAgb3BlbjogYm9vbGVhbjtcclxuICBvbkNsb3NlOiAoKSA9PiB2b2lkO1xyXG4gIG1lc3NhZ2U/OiBzdHJpbmc7XHJcbiAgcmV0dXJuVG8/OiBzdHJpbmc7XHJcbn1cclxuXHJcbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIExvZ2luUHJvbXB0TW9kYWwoe1xyXG4gIG9wZW4sXHJcbiAgb25DbG9zZSxcclxuICBtZXNzYWdlID0gXCJZb3UgbmVlZCB0byBiZSBsb2dnZWQgaW4gdG8gYWNjZXNzIHRoaXMgZmVhdHVyZS5cIixcclxuICByZXR1cm5UbyxcclxufTogTG9naW5Qcm9tcHRNb2RhbFByb3BzKSB7XHJcbiAgY29uc3QgbmF2aWdhdGUgPSB1c2VOYXZpZ2F0ZSgpO1xyXG4gIGNvbnN0IHsgb3BlblNpZ25JbiB9ID0gdXNlQ2xlcmsoKTtcclxuICBjb25zdCBbaXNDbG9zaW5nLCBzZXRJc0Nsb3NpbmddID0gdXNlU3RhdGUoZmFsc2UpO1xyXG5cclxuICAvLyBJZiBkaWFsb2cgaXMgY2xvc2luZywgcmVzZXQgc3RhdGUgYWZ0ZXIgYW5pbWF0aW9uIGNvbXBsZXRlc1xyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBpZiAoaXNDbG9zaW5nKSB7XHJcbiAgICAgIGNvbnN0IHRpbWVyID0gc2V0VGltZW91dCgoKSA9PiB7XHJcbiAgICAgICAgc2V0SXNDbG9zaW5nKGZhbHNlKTtcclxuICAgICAgICBvbkNsb3NlKCk7XHJcbiAgICAgIH0sIDMwMCk7IC8vIE1hdGNoIHlvdXIgZGlhbG9nIGNsb3NlIGFuaW1hdGlvbiBkdXJhdGlvblxyXG4gICAgICByZXR1cm4gKCkgPT4gY2xlYXJUaW1lb3V0KHRpbWVyKTtcclxuICAgIH1cclxuICB9LCBbaXNDbG9zaW5nLCBvbkNsb3NlXSk7XHJcblxyXG4gIGNvbnN0IGhhbmRsZUNsb3NlID0gKCkgPT4ge1xyXG4gICAgc2V0SXNDbG9zaW5nKHRydWUpO1xyXG4gIH07XHJcblxyXG4gIGNvbnN0IGhhbmRsZUxvZ2luID0gKCkgPT4ge1xyXG4gICAgLy8gQ2xvc2UgbW9kYWwgZmlyc3RcclxuICAgIHNldElzQ2xvc2luZyh0cnVlKTtcclxuICAgIFxyXG4gICAgLy8gVXNlIHNldFRpbWVvdXQgdG8gZW5zdXJlIG1vZGFsIGNsb3NlcyBiZWZvcmUgcmVkaXJlY3RcclxuICAgIHNldFRpbWVvdXQoKCkgPT4ge1xyXG4gICAgICAvLyBPcGVuIENsZXJrJ3Mgc2lnbi1pbiBkaWFsb2cgd2l0aCBhIHJldHVyblVybCBpZiBwcm92aWRlZFxyXG4gICAgICBvcGVuU2lnbkluKHtcclxuICAgICAgICByZWRpcmVjdFVybDogcmV0dXJuVG8gfHwgd2luZG93LmxvY2F0aW9uLnBhdGhuYW1lLFxyXG4gICAgICB9KTtcclxuICAgIH0sIDMwMCk7XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgaGFuZGxlQ2FuY2VsID0gKCkgPT4ge1xyXG4gICAgc2V0SXNDbG9zaW5nKHRydWUpO1xyXG4gICAgXHJcbiAgICAvLyBSZWRpcmVjdCB0byBob21lIGFmdGVyIGRpYWxvZyBjbG9zZXNcclxuICAgIHNldFRpbWVvdXQoKCkgPT4ge1xyXG4gICAgICBuYXZpZ2F0ZShcIi9cIik7XHJcbiAgICB9LCAzMDApO1xyXG4gIH07XHJcblxyXG4gIHJldHVybiAoXHJcbiAgICA8RGlhbG9nIFxyXG4gICAgICBvcGVuPXtvcGVuICYmICFpc0Nsb3Npbmd9IFxyXG4gICAgICBvbkNsb3NlPXtoYW5kbGVDbG9zZX1cclxuICAgICAgbWF4V2lkdGg9XCJzbVwiXHJcbiAgICAgIGZ1bGxXaWR0aFxyXG4gICAgPlxyXG4gICAgICA8RGlhbG9nVGl0bGU+U2lnbiBpbiByZXF1aXJlZDwvRGlhbG9nVGl0bGU+XHJcbiAgICAgIDxEaWFsb2dDb250ZW50PlxyXG4gICAgICAgIDxCb3ggc3g9e3sgcHk6IDEgfX0+XHJcbiAgICAgICAgICA8VHlwb2dyYXBoeSB2YXJpYW50PVwiYm9keTFcIj5cclxuICAgICAgICAgICAge21lc3NhZ2V9XHJcbiAgICAgICAgICA8L1R5cG9ncmFwaHk+XHJcbiAgICAgICAgPC9Cb3g+XHJcbiAgICAgIDwvRGlhbG9nQ29udGVudD5cclxuICAgICAgPERpYWxvZ0FjdGlvbnM+XHJcbiAgICAgICAgPEJ1dHRvbiBvbkNsaWNrPXtoYW5kbGVDYW5jZWx9IGNvbG9yPVwiaW5oZXJpdFwiPlxyXG4gICAgICAgICAgQ2FuY2VsXHJcbiAgICAgICAgPC9CdXR0b24+XHJcbiAgICAgICAgPEJ1dHRvbiBvbkNsaWNrPXtoYW5kbGVMb2dpbn0gdmFyaWFudD1cImNvbnRhaW5lZFwiIGNvbG9yPVwicHJpbWFyeVwiIGF1dG9Gb2N1cz5cclxuICAgICAgICAgIFNpZ24gSW5cclxuICAgICAgICA8L0J1dHRvbj5cclxuICAgICAgPC9EaWFsb2dBY3Rpb25zPlxyXG4gICAgPC9EaWFsb2c+XHJcbiAgKTtcclxufSJdLCJmaWxlIjoiQzovVXNlcnMvc19tYXIvY3MzMi9TbmFja1N0YWNrL2NsaWVudC9zcmMvY29tcG9uZW50cy9Mb2dpblByb21wdE1vZGFsLnRzeCJ9