import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/styles/HistoryRecipes.css");import { updateStyle as __vite__updateStyle, removeStyle as __vite__removeStyle } from "/@vite/client"
const __vite__id = "C:/Users/s_mar/cs32/SnackStack/client/src/styles/HistoryRecipes.css"
const __vite__css = ".history-container {\r\n  flex: 1;\r\n  display: flex;\r\n  flex-direction: column;\r\n}\r\n\r\n.history-container.has-content {\r\n  justify-content: flex-start;\r\n  align-items: stretch;\r\n}\r\n\r\n.history-container.empty {\r\n  display: flex;\r\n  align-items: center;\r\n  justify-content: center;\r\n  text-align: center;\r\n}\r\n\r\n.history-header {\r\n  margin-bottom: 2rem;\r\n  text-align: center;\r\n}\r\n\r\n.history-table-container {\r\n  flex-grow: 1;\r\n  margin-bottom: 2rem;\r\n  overflow-y: auto;\r\n}\r\n"
__vite__updateStyle(__vite__id, __vite__css)
import.meta.hot.accept()
export default __vite__css
import.meta.hot.prune(() => __vite__removeStyle(__vite__id))