import {
  Pagination_default,
  getPaginationUtilityClass,
  paginationClasses_default
} from "/node_modules/.vite/deps/chunk-GD6VD4PB.js?v=4d3a3d4b";
import "/node_modules/.vite/deps/chunk-LTC32GJK.js?v=4d3a3d4b";
import "/node_modules/.vite/deps/chunk-5OZJXOSV.js?v=4d3a3d4b";
import "/node_modules/.vite/deps/chunk-MLPXR4TV.js?v=4d3a3d4b";
import "/node_modules/.vite/deps/chunk-JFUJMKGI.js?v=4d3a3d4b";
import "/node_modules/.vite/deps/chunk-NTONOVYZ.js?v=4d3a3d4b";
import "/node_modules/.vite/deps/chunk-ZZNIRIXO.js?v=4d3a3d4b";
import "/node_modules/.vite/deps/chunk-TSMFREGN.js?v=4d3a3d4b";
import "/node_modules/.vite/deps/chunk-64FVIM6J.js?v=4d3a3d4b";
import "/node_modules/.vite/deps/chunk-TOXUORXJ.js?v=4d3a3d4b";
import "/node_modules/.vite/deps/chunk-K5YNGTCN.js?v=4d3a3d4b";
import "/node_modules/.vite/deps/chunk-ZC22LKFR.js?v=4d3a3d4b";
export {
  Pagination_default as default,
  getPaginationUtilityClass,
  paginationClasses_default as paginationClasses
};
//# sourceMappingURL=@mui_material_Pagination.js.map
