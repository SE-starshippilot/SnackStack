import {
  require_react
} from "/node_modules/.vite/deps/chunk-K5YNGTCN.js?v=4d3a3d4b";
import {
  __toESM
} from "/node_modules/.vite/deps/chunk-ZC22LKFR.js?v=4d3a3d4b";

// node_modules/@mui/material/esm/Table/Tablelvl2Context.js
var React = __toESM(require_react(), 1);
var Tablelvl2Context = React.createContext();
if (true) {
  Tablelvl2Context.displayName = "Tablelvl2Context";
}
var Tablelvl2Context_default = Tablelvl2Context;

export {
  Tablelvl2Context_default
};
//# sourceMappingURL=chunk-7ZELHDS7.js.map
