import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/Profile.tsx");import { jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/s_mar/cs32/SnackStack/client/src/components/Profile.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import { useUser, RedirectToSignIn } from "/node_modules/.vite/deps/@clerk_clerk-react.js?v=4d3a3d4b";
import __vite__cjsImport4_react from "/node_modules/.vite/deps/react.js?v=4d3a3d4b"; const useState = __vite__cjsImport4_react["useState"]; const useEffect = __vite__cjsImport4_react["useEffect"];
import { useNavigate } from "/node_modules/.vite/deps/react-router-dom.js?v=4d3a3d4b";
import { TextField, Button, Snackbar, Alert, Container, Typography, Box, CircularProgress } from "/node_modules/.vite/deps/@mui_material.js?v=4d3a3d4b";
import axios from "/node_modules/.vite/deps/axios.js?v=4d3a3d4b";
import { useUserContext } from "/src/contexts/UserContext.tsx";
const API_URL = "http://localhost:8080/api/users";
export default function Profile() {
  _s();
  const {
    user,
    isLoaded
  } = useUser();
  const {
    isProfileComplete,
    dbUserId,
    setUserData
  } = useUserContext();
  const [username, setUsername] = useState("");
  const [email, setEmail] = useState("");
  const [emailError, setEmailError] = useState("");
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isCheckingProfile, setIsCheckingProfile] = useState(true);
  const [notification, setNotification] = useState({
    open: false,
    message: "",
    severity: "success"
  });
  const navigate = useNavigate();
  useEffect(() => {
    const checkExistingProfile = async () => {
      if (isLoaded && user) {
        const userEmail = user.primaryEmailAddress?.emailAddress;
        if (userEmail) {
          try {
            setIsCheckingProfile(true);
            const response = await axios.get(`${API_URL}/email/${userEmail}`);
            if (response.data && response.data.userId) {
              console.log("Found existing user profile:", response.data);
              setUserData({
                id: response.data.userId,
                username: response.data.userName,
                email: response.data.email
              });
              setTimeout(() => {
                navigate("/", {
                  replace: true
                });
              }, 100);
            } else {
              setUsername(user.username || "");
              setEmail(userEmail);
            }
          } catch (error) {
            console.log("No existing profile found, showing profile form");
            setUsername(user.username || "");
            setEmail(userEmail || "");
          } finally {
            setIsCheckingProfile(false);
          }
        } else {
          setIsCheckingProfile(false);
        }
      }
    };
    if (isProfileComplete && dbUserId) {
      console.log("Profile already complete, redirecting to home");
      navigate("/", {
        replace: true
      });
    } else if (isLoaded && user) {
      checkExistingProfile();
    } else if (isLoaded) {
      setIsCheckingProfile(false);
    }
  }, [isLoaded, user, isProfileComplete, dbUserId, navigate, setUserData]);
  if (!isLoaded || isCheckingProfile) {
    return /* @__PURE__ */ jsxDEV(Container, { maxWidth: "sm", children: /* @__PURE__ */ jsxDEV(Box, { sx: {
      my: 4,
      display: "flex",
      flexDirection: "column",
      alignItems: "center",
      justifyContent: "center",
      minHeight: "50vh"
    }, children: [
      /* @__PURE__ */ jsxDEV(CircularProgress, {}, void 0, false, {
        fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/components/Profile.tsx",
        lineNumber: 100,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV(Typography, { sx: {
        mt: 2
      }, children: !isLoaded ? "Loading user information..." : "Checking profile status..." }, void 0, false, {
        fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/components/Profile.tsx",
        lineNumber: 101,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/components/Profile.tsx",
      lineNumber: 92,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/components/Profile.tsx",
      lineNumber: 91,
      columnNumber: 12
    }, this);
  }
  if (!user)
    return /* @__PURE__ */ jsxDEV(RedirectToSignIn, {}, void 0, false, {
      fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/components/Profile.tsx",
      lineNumber: 111,
      columnNumber: 21
    }, this);
  const validateEmail = (email2) => {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email2);
  };
  const handleEmailChange = (e) => {
    const newEmail = e.target.value;
    setEmail(newEmail);
    if (newEmail && !validateEmail(newEmail)) {
      setEmailError("Please enter a valid email address");
    } else {
      setEmailError("");
    }
  };
  const onSave = async (e) => {
    e.preventDefault();
    if (!validateEmail(email)) {
      setEmailError("Please enter a valid email address");
      return;
    }
    if (!username.trim()) {
      return;
    }
    try {
      setIsSubmitting(true);
      console.log("Creating user profile with:", {
        userName: username,
        email
      });
      const response = await axios.post(API_URL, {
        userName: username,
        email
      });
      console.log("Backend response:", response.data);
      setUserData({
        id: response.data.id,
        username,
        email
      });
      console.log("Profile completed successfully");
      setNotification({
        open: true,
        message: "Profile updated successfully!",
        severity: "success"
      });
      setTimeout(() => {
        navigate("/", {
          replace: true
        });
      }, 1500);
    } catch (error) {
      console.error("Error saving profile:", error);
      setNotification({
        open: true,
        message: "Error updating profile. Please try again.",
        severity: "error"
      });
    } finally {
      setIsSubmitting(false);
    }
  };
  const handleCloseNotification = () => {
    setNotification({
      ...notification,
      open: false
    });
  };
  return /* @__PURE__ */ jsxDEV(Container, { maxWidth: "sm", children: [
    /* @__PURE__ */ jsxDEV(Box, { sx: {
      my: 4,
      display: "flex",
      flexDirection: "column",
      alignItems: "center"
    }, children: [
      /* @__PURE__ */ jsxDEV(Typography, { component: "h1", variant: "h4", gutterBottom: true, children: "Complete Your Profile" }, void 0, false, {
        fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/components/Profile.tsx",
        lineNumber: 191,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(Box, { component: "form", onSubmit: onSave, sx: {
        mt: 1,
        width: "100%"
      }, children: [
        /* @__PURE__ */ jsxDEV(TextField, { margin: "normal", required: true, fullWidth: true, id: "username", label: "Username", name: "username", autoComplete: "username", value: username, onChange: (e) => setUsername(e.target.value), autoFocus: true }, void 0, false, {
          fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/components/Profile.tsx",
          lineNumber: 199,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV(TextField, { margin: "normal", required: true, fullWidth: true, id: "email", label: "Email Address", name: "email", autoComplete: "email", value: email, onChange: handleEmailChange, error: !!emailError, helperText: emailError }, void 0, false, {
          fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/components/Profile.tsx",
          lineNumber: 201,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV(Button, { type: "submit", fullWidth: true, variant: "contained", sx: {
          mt: 3,
          mb: 2
        }, disabled: isSubmitting, children: isSubmitting ? "Saving..." : "Save & Continue" }, void 0, false, {
          fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/components/Profile.tsx",
          lineNumber: 203,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/components/Profile.tsx",
        lineNumber: 195,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/components/Profile.tsx",
      lineNumber: 185,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(Snackbar, { open: notification.open, autoHideDuration: 6e3, onClose: handleCloseNotification, anchorOrigin: {
      vertical: "bottom",
      horizontal: "center"
    }, children: /* @__PURE__ */ jsxDEV(Alert, { onClose: handleCloseNotification, severity: notification.severity, sx: {
      width: "100%"
    }, children: notification.message }, void 0, false, {
      fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/components/Profile.tsx",
      lineNumber: 216,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/components/Profile.tsx",
      lineNumber: 212,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/components/Profile.tsx",
    lineNumber: 184,
    columnNumber: 10
  }, this);
}
_s(Profile, "oeOT6TN1x6f2sVgs/2zeSjockak=", false, function() {
  return [useUser, useUserContext, useNavigate];
});
_c = Profile;
var _c;
$RefreshReg$(_c, "Profile");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/s_mar/cs32/SnackStack/client/src/components/Profile.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBc0dVOzs7Ozs7Ozs7Ozs7Ozs7O0FBdEdWLFNBQVNBLFNBQVNDLHdCQUFpQztBQUNuRCxTQUFTQyxVQUFVQyxpQkFBaUI7QUFDcEMsU0FBU0MsbUJBQW1CO0FBQzVCLFNBQ0VDLFdBQ0FDLFFBQ0FDLFVBQ0FDLE9BQ0FDLFdBQ0FDLFlBQ0FDLEtBQ0FDLHdCQUNLO0FBQ1AsT0FBT0MsV0FBVztBQUNsQixTQUFTQyxzQkFBc0I7QUFHL0IsTUFBTUMsVUFBVTtBQUVoQix3QkFBd0JDLFVBQVU7QUFBQUMsS0FBQTtBQUNoQyxRQUFNO0FBQUEsSUFBRUM7QUFBQUEsSUFBTUM7QUFBQUEsRUFBUyxJQUFJbkIsUUFBUTtBQUNuQyxRQUFNO0FBQUEsSUFBRW9CO0FBQUFBLElBQW1CQztBQUFBQSxJQUFVQztBQUFBQSxFQUFZLElBQUlSLGVBQWU7QUFDcEUsUUFBTSxDQUFDUyxVQUFVQyxXQUFXLElBQUl0QixTQUFTLEVBQUU7QUFDM0MsUUFBTSxDQUFDdUIsT0FBT0MsUUFBUSxJQUFJeEIsU0FBUyxFQUFFO0FBQ3JDLFFBQU0sQ0FBQ3lCLFlBQVlDLGFBQWEsSUFBSTFCLFNBQVMsRUFBRTtBQUMvQyxRQUFNLENBQUMyQixjQUFjQyxlQUFlLElBQUk1QixTQUFTLEtBQUs7QUFDdEQsUUFBTSxDQUFDNkIsbUJBQW1CQyxvQkFBb0IsSUFBSTlCLFNBQVMsSUFBSTtBQUMvRCxRQUFNLENBQUMrQixjQUFjQyxlQUFlLElBQUloQyxTQUFTO0FBQUEsSUFDL0NpQyxNQUFNO0FBQUEsSUFDTkMsU0FBUztBQUFBLElBQ1RDLFVBQVU7QUFBQSxFQUNaLENBQUM7QUFDRCxRQUFNQyxXQUFXbEMsWUFBWTtBQUc3QkQsWUFBVSxNQUFNO0FBQ2QsVUFBTW9DLHVCQUF1QixZQUFZO0FBQ3ZDLFVBQUlwQixZQUFZRCxNQUFNO0FBQ3BCLGNBQU1zQixZQUFZdEIsS0FBS3VCLHFCQUFxQkM7QUFFNUMsWUFBSUYsV0FBVztBQUNiLGNBQUk7QUFDRlIsaUNBQXFCLElBQUk7QUFFekIsa0JBQU1XLFdBQVcsTUFBTTlCLE1BQU0rQixJQUFJLEdBQUc3QixPQUFPLFVBQVV5QixTQUFTLEVBQUU7QUFFaEUsZ0JBQUlHLFNBQVNFLFFBQVFGLFNBQVNFLEtBQUtDLFFBQVE7QUFDekNDLHNCQUFRQyxJQUFJLGdDQUFnQ0wsU0FBU0UsSUFBSTtBQUV6RHZCLDBCQUFZO0FBQUEsZ0JBQ1YyQixJQUFJTixTQUFTRSxLQUFLQztBQUFBQSxnQkFDbEJ2QixVQUFVb0IsU0FBU0UsS0FBS0s7QUFBQUEsZ0JBQ3hCekIsT0FBT2tCLFNBQVNFLEtBQUtwQjtBQUFBQSxjQUN2QixDQUFDO0FBR0QwQix5QkFBVyxNQUFNO0FBQ2ZiLHlCQUFTLEtBQUs7QUFBQSxrQkFBRWMsU0FBUztBQUFBLGdCQUFLLENBQUM7QUFBQSxjQUNqQyxHQUFHLEdBQUc7QUFBQSxZQUNSLE9BQU87QUFFTDVCLDBCQUFZTixLQUFLSyxZQUFZLEVBQUU7QUFDL0JHLHVCQUFTYyxTQUFTO0FBQUEsWUFDcEI7QUFBQSxVQUNGLFNBQVNhLE9BQU87QUFDZE4sb0JBQVFDLElBQUksaURBQWlEO0FBRTdEeEIsd0JBQVlOLEtBQUtLLFlBQVksRUFBRTtBQUMvQkcscUJBQVNjLGFBQWEsRUFBRTtBQUFBLFVBQzFCLFVBQUM7QUFDQ1IsaUNBQXFCLEtBQUs7QUFBQSxVQUM1QjtBQUFBLFFBQ0YsT0FBTztBQUNMQSwrQkFBcUIsS0FBSztBQUFBLFFBQzVCO0FBQUEsTUFDRjtBQUFBLElBQ0Y7QUFFQSxRQUFJWixxQkFBcUJDLFVBQVU7QUFDakMwQixjQUFRQyxJQUFJLCtDQUErQztBQUMzRFYsZUFBUyxLQUFLO0FBQUEsUUFBRWMsU0FBUztBQUFBLE1BQUssQ0FBQztBQUFBLElBQ2pDLFdBQVdqQyxZQUFZRCxNQUFNO0FBQzNCcUIsMkJBQXFCO0FBQUEsSUFDdkIsV0FBV3BCLFVBQVU7QUFDbkJhLDJCQUFxQixLQUFLO0FBQUEsSUFDNUI7QUFBQSxFQUNGLEdBQUcsQ0FBQ2IsVUFBVUQsTUFBTUUsbUJBQW1CQyxVQUFVaUIsVUFBVWhCLFdBQVcsQ0FBQztBQUd2RSxNQUFJLENBQUNILFlBQVlZLG1CQUFtQjtBQUNsQyxXQUNFLHVCQUFDLGFBQVUsVUFBUyxNQUNsQixpQ0FBQyxPQUNDLElBQUk7QUFBQSxNQUNGdUIsSUFBSTtBQUFBLE1BQ0pDLFNBQVM7QUFBQSxNQUNUQyxlQUFlO0FBQUEsTUFDZkMsWUFBWTtBQUFBLE1BQ1pDLGdCQUFnQjtBQUFBLE1BQ2hCQyxXQUFXO0FBQUEsSUFDYixHQUVBO0FBQUEsNkJBQUMsc0JBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFpQjtBQUFBLE1BQ2pCLHVCQUFDLGNBQVcsSUFBSTtBQUFBLFFBQUVDLElBQUk7QUFBQSxNQUFFLEdBQ3JCLFdBQUN6QyxXQUFXLGdDQUFnQyxnQ0FEL0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBO0FBQUEsU0FiRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBY0EsS0FmRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBZ0JBO0FBQUEsRUFFSjtBQUdBLE1BQUksQ0FBQ0Q7QUFBTSxXQUFPLHVCQUFDLHNCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBaUI7QUFFbkMsUUFBTTJDLGdCQUFnQkEsQ0FBQ3BDLFdBQWtCO0FBQ3ZDLFVBQU1xQyxhQUFhO0FBQ25CLFdBQU9BLFdBQVdDLEtBQUt0QyxNQUFLO0FBQUEsRUFDOUI7QUFFQSxRQUFNdUMsb0JBQW9CQSxDQUFDQyxNQUEyQztBQUNwRSxVQUFNQyxXQUFXRCxFQUFFRSxPQUFPQztBQUMxQjFDLGFBQVN3QyxRQUFRO0FBRWpCLFFBQUlBLFlBQVksQ0FBQ0wsY0FBY0ssUUFBUSxHQUFHO0FBQ3hDdEMsb0JBQWMsb0NBQW9DO0FBQUEsSUFDcEQsT0FBTztBQUNMQSxvQkFBYyxFQUFFO0FBQUEsSUFDbEI7QUFBQSxFQUNGO0FBRUEsUUFBTXlDLFNBQVMsT0FBT0osTUFBdUI7QUFDM0NBLE1BQUVLLGVBQWU7QUFFakIsUUFBSSxDQUFDVCxjQUFjcEMsS0FBSyxHQUFHO0FBQ3pCRyxvQkFBYyxvQ0FBb0M7QUFDbEQ7QUFBQSxJQUNGO0FBRUEsUUFBSSxDQUFDTCxTQUFTZ0QsS0FBSyxHQUFHO0FBQ3BCO0FBQUEsSUFDRjtBQUVBLFFBQUk7QUFDRnpDLHNCQUFnQixJQUFJO0FBRXBCaUIsY0FBUUMsSUFBSSwrQkFBK0I7QUFBQSxRQUFFRSxVQUFVM0I7QUFBQUEsUUFBVUU7QUFBQUEsTUFBTSxDQUFDO0FBR3hFLFlBQU1rQixXQUFXLE1BQU05QixNQUFNMkQsS0FBS3pELFNBQVM7QUFBQSxRQUN6Q21DLFVBQVUzQjtBQUFBQSxRQUNWRTtBQUFBQSxNQUNGLENBQUM7QUFFRHNCLGNBQVFDLElBQUkscUJBQXFCTCxTQUFTRSxJQUFJO0FBRzlDdkIsa0JBQVk7QUFBQSxRQUNWMkIsSUFBSU4sU0FBU0UsS0FBS0k7QUFBQUEsUUFDbEIxQjtBQUFBQSxRQUNBRTtBQUFBQSxNQUNGLENBQUM7QUFFRHNCLGNBQVFDLElBQUksZ0NBQWdDO0FBRTVDZCxzQkFBZ0I7QUFBQSxRQUNkQyxNQUFNO0FBQUEsUUFDTkMsU0FBUztBQUFBLFFBQ1RDLFVBQVU7QUFBQSxNQUNaLENBQUM7QUFHRGMsaUJBQVcsTUFBTTtBQUNmYixpQkFBUyxLQUFLO0FBQUEsVUFBRWMsU0FBUztBQUFBLFFBQUssQ0FBQztBQUFBLE1BQ2pDLEdBQUcsSUFBSTtBQUFBLElBQ1QsU0FBU0MsT0FBTztBQUNkTixjQUFRTSxNQUFNLHlCQUF5QkEsS0FBSztBQUM1Q25CLHNCQUFnQjtBQUFBLFFBQ2RDLE1BQU07QUFBQSxRQUNOQyxTQUFTO0FBQUEsUUFDVEMsVUFBVTtBQUFBLE1BQ1osQ0FBQztBQUFBLElBQ0gsVUFBQztBQUNDUCxzQkFBZ0IsS0FBSztBQUFBLElBQ3ZCO0FBQUEsRUFDRjtBQUVBLFFBQU0yQywwQkFBMEJBLE1BQU07QUFDcEN2QyxvQkFBZ0I7QUFBQSxNQUFFLEdBQUdEO0FBQUFBLE1BQWNFLE1BQU07QUFBQSxJQUFNLENBQUM7QUFBQSxFQUNsRDtBQUVBLFNBQ0UsdUJBQUMsYUFBVSxVQUFTLE1BQ2xCO0FBQUEsMkJBQUMsT0FDQyxJQUFJO0FBQUEsTUFDRm1CLElBQUk7QUFBQSxNQUNKQyxTQUFTO0FBQUEsTUFDVEMsZUFBZTtBQUFBLE1BQ2ZDLFlBQVk7QUFBQSxJQUNkLEdBRUE7QUFBQSw2QkFBQyxjQUFXLFdBQVUsTUFBSyxTQUFRLE1BQUssY0FBWSxNQUFDLHFDQUFyRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRUE7QUFBQSxNQUVBLHVCQUFDLE9BQUksV0FBVSxRQUFPLFVBQVVZLFFBQVEsSUFBSTtBQUFBLFFBQUVULElBQUk7QUFBQSxRQUFHYyxPQUFPO0FBQUEsTUFBTyxHQUNqRTtBQUFBLCtCQUFDLGFBQ0MsUUFBTyxVQUNQLFVBQVEsTUFDUixXQUFTLE1BQ1QsSUFBRyxZQUNILE9BQU0sWUFDTixNQUFLLFlBQ0wsY0FBYSxZQUNiLE9BQU9uRCxVQUNQLFVBQVcwQyxPQUFNekMsWUFBWXlDLEVBQUVFLE9BQU9DLEtBQUssR0FDM0MsV0FBUyxRQVZYO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFVVztBQUFBLFFBR1gsdUJBQUMsYUFDQyxRQUFPLFVBQ1AsVUFBUSxNQUNSLFdBQVMsTUFDVCxJQUFHLFNBQ0gsT0FBTSxpQkFDTixNQUFLLFNBQ0wsY0FBYSxTQUNiLE9BQU8zQyxPQUNQLFVBQVV1QyxtQkFDVixPQUFPLENBQUMsQ0FBQ3JDLFlBQ1QsWUFBWUEsY0FYZDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBV3lCO0FBQUEsUUFHekIsdUJBQUMsVUFDQyxNQUFLLFVBQ0wsV0FBUyxNQUNULFNBQVEsYUFDUixJQUFJO0FBQUEsVUFBRWlDLElBQUk7QUFBQSxVQUFHZSxJQUFJO0FBQUEsUUFBRSxHQUNuQixVQUFVOUMsY0FFVEEseUJBQWUsY0FBYyxxQkFQaEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVFBO0FBQUEsV0FwQ0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQXFDQTtBQUFBLFNBakRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FrREE7QUFBQSxJQUVBLHVCQUFDLFlBQ0MsTUFBTUksYUFBYUUsTUFDbkIsa0JBQWtCLEtBQ2xCLFNBQVNzQyx5QkFDVCxjQUFjO0FBQUEsTUFBRUcsVUFBVTtBQUFBLE1BQVVDLFlBQVk7QUFBQSxJQUFTLEdBRXpELGlDQUFDLFNBQ0MsU0FBU0oseUJBQ1QsVUFBVXhDLGFBQWFJLFVBQ3ZCLElBQUk7QUFBQSxNQUFFcUMsT0FBTztBQUFBLElBQU8sR0FFbkJ6Qyx1QkFBYUcsV0FMaEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQU1BLEtBWkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQWFBO0FBQUEsT0FsRUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQW1FQTtBQUVKO0FBQUNuQixHQWpQdUJELFNBQU87QUFBQSxVQUNGaEIsU0FDMEJjLGdCQVdwQ1YsV0FBVztBQUFBO0FBQUEwRSxLQWJOOUQ7QUFBTyxJQUFBOEQ7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbInVzZVVzZXIiLCJSZWRpcmVjdFRvU2lnbkluIiwidXNlU3RhdGUiLCJ1c2VFZmZlY3QiLCJ1c2VOYXZpZ2F0ZSIsIlRleHRGaWVsZCIsIkJ1dHRvbiIsIlNuYWNrYmFyIiwiQWxlcnQiLCJDb250YWluZXIiLCJUeXBvZ3JhcGh5IiwiQm94IiwiQ2lyY3VsYXJQcm9ncmVzcyIsImF4aW9zIiwidXNlVXNlckNvbnRleHQiLCJBUElfVVJMIiwiUHJvZmlsZSIsIl9zIiwidXNlciIsImlzTG9hZGVkIiwiaXNQcm9maWxlQ29tcGxldGUiLCJkYlVzZXJJZCIsInNldFVzZXJEYXRhIiwidXNlcm5hbWUiLCJzZXRVc2VybmFtZSIsImVtYWlsIiwic2V0RW1haWwiLCJlbWFpbEVycm9yIiwic2V0RW1haWxFcnJvciIsImlzU3VibWl0dGluZyIsInNldElzU3VibWl0dGluZyIsImlzQ2hlY2tpbmdQcm9maWxlIiwic2V0SXNDaGVja2luZ1Byb2ZpbGUiLCJub3RpZmljYXRpb24iLCJzZXROb3RpZmljYXRpb24iLCJvcGVuIiwibWVzc2FnZSIsInNldmVyaXR5IiwibmF2aWdhdGUiLCJjaGVja0V4aXN0aW5nUHJvZmlsZSIsInVzZXJFbWFpbCIsInByaW1hcnlFbWFpbEFkZHJlc3MiLCJlbWFpbEFkZHJlc3MiLCJyZXNwb25zZSIsImdldCIsImRhdGEiLCJ1c2VySWQiLCJjb25zb2xlIiwibG9nIiwiaWQiLCJ1c2VyTmFtZSIsInNldFRpbWVvdXQiLCJyZXBsYWNlIiwiZXJyb3IiLCJteSIsImRpc3BsYXkiLCJmbGV4RGlyZWN0aW9uIiwiYWxpZ25JdGVtcyIsImp1c3RpZnlDb250ZW50IiwibWluSGVpZ2h0IiwibXQiLCJ2YWxpZGF0ZUVtYWlsIiwiZW1haWxSZWdleCIsInRlc3QiLCJoYW5kbGVFbWFpbENoYW5nZSIsImUiLCJuZXdFbWFpbCIsInRhcmdldCIsInZhbHVlIiwib25TYXZlIiwicHJldmVudERlZmF1bHQiLCJ0cmltIiwicG9zdCIsImhhbmRsZUNsb3NlTm90aWZpY2F0aW9uIiwid2lkdGgiLCJtYiIsInZlcnRpY2FsIiwiaG9yaXpvbnRhbCIsIl9jIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiUHJvZmlsZS50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlVXNlciwgUmVkaXJlY3RUb1NpZ25JbiwgdXNlQXV0aCB9IGZyb20gXCJAY2xlcmsvY2xlcmstcmVhY3RcIjtcclxuaW1wb3J0IHsgdXNlU3RhdGUsIHVzZUVmZmVjdCB9IGZyb20gXCJyZWFjdFwiO1xyXG5pbXBvcnQgeyB1c2VOYXZpZ2F0ZSB9IGZyb20gXCJyZWFjdC1yb3V0ZXItZG9tXCI7XHJcbmltcG9ydCB7XHJcbiAgVGV4dEZpZWxkLFxyXG4gIEJ1dHRvbixcclxuICBTbmFja2JhcixcclxuICBBbGVydCxcclxuICBDb250YWluZXIsXHJcbiAgVHlwb2dyYXBoeSxcclxuICBCb3gsXHJcbiAgQ2lyY3VsYXJQcm9ncmVzc1xyXG59IGZyb20gXCJAbXVpL21hdGVyaWFsXCI7XHJcbmltcG9ydCBheGlvcyBmcm9tIFwiYXhpb3NcIjtcclxuaW1wb3J0IHsgdXNlVXNlckNvbnRleHQgfSBmcm9tIFwiLi4vY29udGV4dHMvVXNlckNvbnRleHRcIjtcclxuXHJcbi8vIERlZmluZSB0aGUgQVBJIGJhc2UgVVJMIC0gYWRqdXN0IHRvIG1hdGNoIHlvdXIgYmFja2VuZFxyXG5jb25zdCBBUElfVVJMID0gXCJodHRwOi8vbG9jYWxob3N0OjgwODAvYXBpL3VzZXJzXCI7XHJcblxyXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBQcm9maWxlKCkge1xyXG4gIGNvbnN0IHsgdXNlciwgaXNMb2FkZWQgfSA9IHVzZVVzZXIoKTtcclxuICBjb25zdCB7IGlzUHJvZmlsZUNvbXBsZXRlLCBkYlVzZXJJZCwgc2V0VXNlckRhdGEgfSA9IHVzZVVzZXJDb250ZXh0KCk7XHJcbiAgY29uc3QgW3VzZXJuYW1lLCBzZXRVc2VybmFtZV0gPSB1c2VTdGF0ZShcIlwiKTtcclxuICBjb25zdCBbZW1haWwsIHNldEVtYWlsXSA9IHVzZVN0YXRlKFwiXCIpO1xyXG4gIGNvbnN0IFtlbWFpbEVycm9yLCBzZXRFbWFpbEVycm9yXSA9IHVzZVN0YXRlKFwiXCIpO1xyXG4gIGNvbnN0IFtpc1N1Ym1pdHRpbmcsIHNldElzU3VibWl0dGluZ10gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgY29uc3QgW2lzQ2hlY2tpbmdQcm9maWxlLCBzZXRJc0NoZWNraW5nUHJvZmlsZV0gPSB1c2VTdGF0ZSh0cnVlKTtcclxuICBjb25zdCBbbm90aWZpY2F0aW9uLCBzZXROb3RpZmljYXRpb25dID0gdXNlU3RhdGUoe1xyXG4gICAgb3BlbjogZmFsc2UsXHJcbiAgICBtZXNzYWdlOiBcIlwiLFxyXG4gICAgc2V2ZXJpdHk6IFwic3VjY2Vzc1wiLFxyXG4gIH0pO1xyXG4gIGNvbnN0IG5hdmlnYXRlID0gdXNlTmF2aWdhdGUoKTtcclxuXHJcbiAgLy8gRmlyc3QgY2hlY2sgaWYgdGhlIHVzZXIgYWxyZWFkeSBleGlzdHMgaW4gdGhlIGJhY2tlbmRcclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgY29uc3QgY2hlY2tFeGlzdGluZ1Byb2ZpbGUgPSBhc3luYyAoKSA9PiB7XHJcbiAgICAgIGlmIChpc0xvYWRlZCAmJiB1c2VyKSB7XHJcbiAgICAgICAgY29uc3QgdXNlckVtYWlsID0gdXNlci5wcmltYXJ5RW1haWxBZGRyZXNzPy5lbWFpbEFkZHJlc3M7XHJcbiAgICAgICAgXHJcbiAgICAgICAgaWYgKHVzZXJFbWFpbCkge1xyXG4gICAgICAgICAgdHJ5IHtcclxuICAgICAgICAgICAgc2V0SXNDaGVja2luZ1Byb2ZpbGUodHJ1ZSk7XHJcbiAgICAgICAgICAgIC8vIENoZWNrIGlmIHVzZXIgZXhpc3RzIGluIGJhY2tlbmQgYnkgZW1haWxcclxuICAgICAgICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBheGlvcy5nZXQoYCR7QVBJX1VSTH0vZW1haWwvJHt1c2VyRW1haWx9YCk7XHJcbiAgICAgICAgICAgIFxyXG4gICAgICAgICAgICBpZiAocmVzcG9uc2UuZGF0YSAmJiByZXNwb25zZS5kYXRhLnVzZXJJZCkge1xyXG4gICAgICAgICAgICAgIGNvbnNvbGUubG9nKFwiRm91bmQgZXhpc3RpbmcgdXNlciBwcm9maWxlOlwiLCByZXNwb25zZS5kYXRhKTtcclxuICAgICAgICAgICAgICAvLyBVc2VyIGV4aXN0cywgc3RvcmUgdGhlaXIgZGV0YWlsc1xyXG4gICAgICAgICAgICAgIHNldFVzZXJEYXRhKHtcclxuICAgICAgICAgICAgICAgIGlkOiByZXNwb25zZS5kYXRhLnVzZXJJZCxcclxuICAgICAgICAgICAgICAgIHVzZXJuYW1lOiByZXNwb25zZS5kYXRhLnVzZXJOYW1lLFxyXG4gICAgICAgICAgICAgICAgZW1haWw6IHJlc3BvbnNlLmRhdGEuZW1haWxcclxuICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgICBcclxuICAgICAgICAgICAgICAvLyBOYXZpZ2F0ZSB0byBob21lIHBhZ2UgYWZ0ZXIgc2hvcnQgZGVsYXkgdG8gYWxsb3cgY29udGV4dCB0byB1cGRhdGVcclxuICAgICAgICAgICAgICBzZXRUaW1lb3V0KCgpID0+IHtcclxuICAgICAgICAgICAgICAgIG5hdmlnYXRlKFwiL1wiLCB7IHJlcGxhY2U6IHRydWUgfSk7XHJcbiAgICAgICAgICAgICAgfSwgMTAwKTtcclxuICAgICAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgICAvLyBJbml0aWFsaXplIGZvcm0gd2l0aCB1c2VyIGRhdGEgZnJvbSBDbGVya1xyXG4gICAgICAgICAgICAgIHNldFVzZXJuYW1lKHVzZXIudXNlcm5hbWUgfHwgXCJcIik7XHJcbiAgICAgICAgICAgICAgc2V0RW1haWwodXNlckVtYWlsKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgICAgICAgY29uc29sZS5sb2coXCJObyBleGlzdGluZyBwcm9maWxlIGZvdW5kLCBzaG93aW5nIHByb2ZpbGUgZm9ybVwiKTtcclxuICAgICAgICAgICAgLy8gSW5pdGlhbGl6ZSBmb3JtIHdpdGggdXNlciBkYXRhIGZyb20gQ2xlcmtcclxuICAgICAgICAgICAgc2V0VXNlcm5hbWUodXNlci51c2VybmFtZSB8fCBcIlwiKTtcclxuICAgICAgICAgICAgc2V0RW1haWwodXNlckVtYWlsIHx8IFwiXCIpO1xyXG4gICAgICAgICAgfSBmaW5hbGx5IHtcclxuICAgICAgICAgICAgc2V0SXNDaGVja2luZ1Byb2ZpbGUoZmFsc2UpO1xyXG4gICAgICAgICAgfVxyXG4gICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICBzZXRJc0NoZWNraW5nUHJvZmlsZShmYWxzZSk7XHJcbiAgICAgICAgfVxyXG4gICAgICB9XHJcbiAgICB9O1xyXG5cclxuICAgIGlmIChpc1Byb2ZpbGVDb21wbGV0ZSAmJiBkYlVzZXJJZCkge1xyXG4gICAgICBjb25zb2xlLmxvZyhcIlByb2ZpbGUgYWxyZWFkeSBjb21wbGV0ZSwgcmVkaXJlY3RpbmcgdG8gaG9tZVwiKTtcclxuICAgICAgbmF2aWdhdGUoXCIvXCIsIHsgcmVwbGFjZTogdHJ1ZSB9KTtcclxuICAgIH0gZWxzZSBpZiAoaXNMb2FkZWQgJiYgdXNlcikge1xyXG4gICAgICBjaGVja0V4aXN0aW5nUHJvZmlsZSgpO1xyXG4gICAgfSBlbHNlIGlmIChpc0xvYWRlZCkge1xyXG4gICAgICBzZXRJc0NoZWNraW5nUHJvZmlsZShmYWxzZSk7XHJcbiAgICB9XHJcbiAgfSwgW2lzTG9hZGVkLCB1c2VyLCBpc1Byb2ZpbGVDb21wbGV0ZSwgZGJVc2VySWQsIG5hdmlnYXRlLCBzZXRVc2VyRGF0YV0pO1xyXG5cclxuICAvLyBTaG93IGxvYWRpbmcgc3RhdGVcclxuICBpZiAoIWlzTG9hZGVkIHx8IGlzQ2hlY2tpbmdQcm9maWxlKSB7XHJcbiAgICByZXR1cm4gKFxyXG4gICAgICA8Q29udGFpbmVyIG1heFdpZHRoPVwic21cIj5cclxuICAgICAgICA8Qm94XHJcbiAgICAgICAgICBzeD17e1xyXG4gICAgICAgICAgICBteTogNCxcclxuICAgICAgICAgICAgZGlzcGxheTogXCJmbGV4XCIsXHJcbiAgICAgICAgICAgIGZsZXhEaXJlY3Rpb246IFwiY29sdW1uXCIsXHJcbiAgICAgICAgICAgIGFsaWduSXRlbXM6IFwiY2VudGVyXCIsXHJcbiAgICAgICAgICAgIGp1c3RpZnlDb250ZW50OiBcImNlbnRlclwiLFxyXG4gICAgICAgICAgICBtaW5IZWlnaHQ6IFwiNTB2aFwiXHJcbiAgICAgICAgICB9fVxyXG4gICAgICAgID5cclxuICAgICAgICAgIDxDaXJjdWxhclByb2dyZXNzIC8+XHJcbiAgICAgICAgICA8VHlwb2dyYXBoeSBzeD17eyBtdDogMiB9fT5cclxuICAgICAgICAgICAgeyFpc0xvYWRlZCA/IFwiTG9hZGluZyB1c2VyIGluZm9ybWF0aW9uLi4uXCIgOiBcIkNoZWNraW5nIHByb2ZpbGUgc3RhdHVzLi4uXCJ9XHJcbiAgICAgICAgICA8L1R5cG9ncmFwaHk+XHJcbiAgICAgICAgPC9Cb3g+XHJcbiAgICAgIDwvQ29udGFpbmVyPlxyXG4gICAgKTtcclxuICB9XHJcblxyXG4gIC8vIFJlZGlyZWN0IGlmIG5vIHVzZXJcclxuICBpZiAoIXVzZXIpIHJldHVybiA8UmVkaXJlY3RUb1NpZ25JbiAvPjtcclxuXHJcbiAgY29uc3QgdmFsaWRhdGVFbWFpbCA9IChlbWFpbDogc3RyaW5nKSA9PiB7XHJcbiAgICBjb25zdCBlbWFpbFJlZ2V4ID0gL15bXlxcc0BdK0BbXlxcc0BdK1xcLlteXFxzQF0rJC87XHJcbiAgICByZXR1cm4gZW1haWxSZWdleC50ZXN0KGVtYWlsKTtcclxuICB9O1xyXG5cclxuICBjb25zdCBoYW5kbGVFbWFpbENoYW5nZSA9IChlOiBSZWFjdC5DaGFuZ2VFdmVudDxIVE1MSW5wdXRFbGVtZW50PikgPT4ge1xyXG4gICAgY29uc3QgbmV3RW1haWwgPSBlLnRhcmdldC52YWx1ZTtcclxuICAgIHNldEVtYWlsKG5ld0VtYWlsKTtcclxuXHJcbiAgICBpZiAobmV3RW1haWwgJiYgIXZhbGlkYXRlRW1haWwobmV3RW1haWwpKSB7XHJcbiAgICAgIHNldEVtYWlsRXJyb3IoXCJQbGVhc2UgZW50ZXIgYSB2YWxpZCBlbWFpbCBhZGRyZXNzXCIpO1xyXG4gICAgfSBlbHNlIHtcclxuICAgICAgc2V0RW1haWxFcnJvcihcIlwiKTtcclxuICAgIH1cclxuICB9O1xyXG5cclxuICBjb25zdCBvblNhdmUgPSBhc3luYyAoZTogUmVhY3QuRm9ybUV2ZW50KSA9PiB7XHJcbiAgICBlLnByZXZlbnREZWZhdWx0KCk7XHJcblxyXG4gICAgaWYgKCF2YWxpZGF0ZUVtYWlsKGVtYWlsKSkge1xyXG4gICAgICBzZXRFbWFpbEVycm9yKFwiUGxlYXNlIGVudGVyIGEgdmFsaWQgZW1haWwgYWRkcmVzc1wiKTtcclxuICAgICAgcmV0dXJuO1xyXG4gICAgfVxyXG5cclxuICAgIGlmICghdXNlcm5hbWUudHJpbSgpKSB7XHJcbiAgICAgIHJldHVybjsgLy8gRG9uJ3Qgc3VibWl0IGlmIHVzZXJuYW1lIGlzIGVtcHR5XHJcbiAgICB9XHJcblxyXG4gICAgdHJ5IHtcclxuICAgICAgc2V0SXNTdWJtaXR0aW5nKHRydWUpO1xyXG5cclxuICAgICAgY29uc29sZS5sb2coXCJDcmVhdGluZyB1c2VyIHByb2ZpbGUgd2l0aDpcIiwgeyB1c2VyTmFtZTogdXNlcm5hbWUsIGVtYWlsIH0pO1xyXG4gICAgICBcclxuICAgICAgLy8gQ3JlYXRlIHVzZXIgaW4geW91ciBiYWNrZW5kIHVzaW5nIGF4aW9zXHJcbiAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgYXhpb3MucG9zdChBUElfVVJMLCB7XHJcbiAgICAgICAgdXNlck5hbWU6IHVzZXJuYW1lLFxyXG4gICAgICAgIGVtYWlsOiBlbWFpbCxcclxuICAgICAgfSk7XHJcblxyXG4gICAgICBjb25zb2xlLmxvZyhcIkJhY2tlbmQgcmVzcG9uc2U6XCIsIHJlc3BvbnNlLmRhdGEpO1xyXG5cclxuICAgICAgLy8gVXBkYXRlIHRoZSBnbG9iYWwgY29udGV4dCB3aXRoIHVzZXIgZGF0YVxyXG4gICAgICBzZXRVc2VyRGF0YSh7XHJcbiAgICAgICAgaWQ6IHJlc3BvbnNlLmRhdGEuaWQsXHJcbiAgICAgICAgdXNlcm5hbWU6IHVzZXJuYW1lLFxyXG4gICAgICAgIGVtYWlsOiBlbWFpbCxcclxuICAgICAgfSk7XHJcblxyXG4gICAgICBjb25zb2xlLmxvZyhcIlByb2ZpbGUgY29tcGxldGVkIHN1Y2Nlc3NmdWxseVwiKTtcclxuICAgICAgXHJcbiAgICAgIHNldE5vdGlmaWNhdGlvbih7XHJcbiAgICAgICAgb3BlbjogdHJ1ZSxcclxuICAgICAgICBtZXNzYWdlOiBcIlByb2ZpbGUgdXBkYXRlZCBzdWNjZXNzZnVsbHkhXCIsXHJcbiAgICAgICAgc2V2ZXJpdHk6IFwic3VjY2Vzc1wiLFxyXG4gICAgICB9KTtcclxuXHJcbiAgICAgIC8vIE5hdmlnYXRlIGFmdGVyIHNob3J0IGRlbGF5IHRvIHNob3cgc3VjY2VzcyBub3RpZmljYXRpb25cclxuICAgICAgc2V0VGltZW91dCgoKSA9PiB7XHJcbiAgICAgICAgbmF2aWdhdGUoXCIvXCIsIHsgcmVwbGFjZTogdHJ1ZSB9KTtcclxuICAgICAgfSwgMTUwMCk7XHJcbiAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICBjb25zb2xlLmVycm9yKFwiRXJyb3Igc2F2aW5nIHByb2ZpbGU6XCIsIGVycm9yKTtcclxuICAgICAgc2V0Tm90aWZpY2F0aW9uKHtcclxuICAgICAgICBvcGVuOiB0cnVlLFxyXG4gICAgICAgIG1lc3NhZ2U6IFwiRXJyb3IgdXBkYXRpbmcgcHJvZmlsZS4gUGxlYXNlIHRyeSBhZ2Fpbi5cIixcclxuICAgICAgICBzZXZlcml0eTogXCJlcnJvclwiLFxyXG4gICAgICB9KTtcclxuICAgIH0gZmluYWxseSB7XHJcbiAgICAgIHNldElzU3VibWl0dGluZyhmYWxzZSk7XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgaGFuZGxlQ2xvc2VOb3RpZmljYXRpb24gPSAoKSA9PiB7XHJcbiAgICBzZXROb3RpZmljYXRpb24oeyAuLi5ub3RpZmljYXRpb24sIG9wZW46IGZhbHNlIH0pO1xyXG4gIH07XHJcblxyXG4gIHJldHVybiAoXHJcbiAgICA8Q29udGFpbmVyIG1heFdpZHRoPVwic21cIj5cclxuICAgICAgPEJveFxyXG4gICAgICAgIHN4PXt7XHJcbiAgICAgICAgICBteTogNCxcclxuICAgICAgICAgIGRpc3BsYXk6IFwiZmxleFwiLFxyXG4gICAgICAgICAgZmxleERpcmVjdGlvbjogXCJjb2x1bW5cIixcclxuICAgICAgICAgIGFsaWduSXRlbXM6IFwiY2VudGVyXCIsXHJcbiAgICAgICAgfX1cclxuICAgICAgPlxyXG4gICAgICAgIDxUeXBvZ3JhcGh5IGNvbXBvbmVudD1cImgxXCIgdmFyaWFudD1cImg0XCIgZ3V0dGVyQm90dG9tPlxyXG4gICAgICAgICAgQ29tcGxldGUgWW91ciBQcm9maWxlXHJcbiAgICAgICAgPC9UeXBvZ3JhcGh5PlxyXG5cclxuICAgICAgICA8Qm94IGNvbXBvbmVudD1cImZvcm1cIiBvblN1Ym1pdD17b25TYXZlfSBzeD17eyBtdDogMSwgd2lkdGg6IFwiMTAwJVwiIH19PlxyXG4gICAgICAgICAgPFRleHRGaWVsZFxyXG4gICAgICAgICAgICBtYXJnaW49XCJub3JtYWxcIlxyXG4gICAgICAgICAgICByZXF1aXJlZFxyXG4gICAgICAgICAgICBmdWxsV2lkdGhcclxuICAgICAgICAgICAgaWQ9XCJ1c2VybmFtZVwiXHJcbiAgICAgICAgICAgIGxhYmVsPVwiVXNlcm5hbWVcIlxyXG4gICAgICAgICAgICBuYW1lPVwidXNlcm5hbWVcIlxyXG4gICAgICAgICAgICBhdXRvQ29tcGxldGU9XCJ1c2VybmFtZVwiXHJcbiAgICAgICAgICAgIHZhbHVlPXt1c2VybmFtZX1cclxuICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRVc2VybmFtZShlLnRhcmdldC52YWx1ZSl9XHJcbiAgICAgICAgICAgIGF1dG9Gb2N1c1xyXG4gICAgICAgICAgLz5cclxuXHJcbiAgICAgICAgICA8VGV4dEZpZWxkXHJcbiAgICAgICAgICAgIG1hcmdpbj1cIm5vcm1hbFwiXHJcbiAgICAgICAgICAgIHJlcXVpcmVkXHJcbiAgICAgICAgICAgIGZ1bGxXaWR0aFxyXG4gICAgICAgICAgICBpZD1cImVtYWlsXCJcclxuICAgICAgICAgICAgbGFiZWw9XCJFbWFpbCBBZGRyZXNzXCJcclxuICAgICAgICAgICAgbmFtZT1cImVtYWlsXCJcclxuICAgICAgICAgICAgYXV0b0NvbXBsZXRlPVwiZW1haWxcIlxyXG4gICAgICAgICAgICB2YWx1ZT17ZW1haWx9XHJcbiAgICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVFbWFpbENoYW5nZX1cclxuICAgICAgICAgICAgZXJyb3I9eyEhZW1haWxFcnJvcn1cclxuICAgICAgICAgICAgaGVscGVyVGV4dD17ZW1haWxFcnJvcn1cclxuICAgICAgICAgIC8+XHJcblxyXG4gICAgICAgICAgPEJ1dHRvblxyXG4gICAgICAgICAgICB0eXBlPVwic3VibWl0XCJcclxuICAgICAgICAgICAgZnVsbFdpZHRoXHJcbiAgICAgICAgICAgIHZhcmlhbnQ9XCJjb250YWluZWRcIlxyXG4gICAgICAgICAgICBzeD17eyBtdDogMywgbWI6IDIgfX1cclxuICAgICAgICAgICAgZGlzYWJsZWQ9e2lzU3VibWl0dGluZ31cclxuICAgICAgICAgID5cclxuICAgICAgICAgICAge2lzU3VibWl0dGluZyA/IFwiU2F2aW5nLi4uXCIgOiBcIlNhdmUgJiBDb250aW51ZVwifVxyXG4gICAgICAgICAgPC9CdXR0b24+XHJcbiAgICAgICAgPC9Cb3g+XHJcbiAgICAgIDwvQm94PlxyXG5cclxuICAgICAgPFNuYWNrYmFyXHJcbiAgICAgICAgb3Blbj17bm90aWZpY2F0aW9uLm9wZW59XHJcbiAgICAgICAgYXV0b0hpZGVEdXJhdGlvbj17NjAwMH1cclxuICAgICAgICBvbkNsb3NlPXtoYW5kbGVDbG9zZU5vdGlmaWNhdGlvbn1cclxuICAgICAgICBhbmNob3JPcmlnaW49e3sgdmVydGljYWw6IFwiYm90dG9tXCIsIGhvcml6b250YWw6IFwiY2VudGVyXCIgfX1cclxuICAgICAgPlxyXG4gICAgICAgIDxBbGVydFxyXG4gICAgICAgICAgb25DbG9zZT17aGFuZGxlQ2xvc2VOb3RpZmljYXRpb259XHJcbiAgICAgICAgICBzZXZlcml0eT17bm90aWZpY2F0aW9uLnNldmVyaXR5IGFzIFwic3VjY2Vzc1wiIHwgXCJlcnJvclwifVxyXG4gICAgICAgICAgc3g9e3sgd2lkdGg6IFwiMTAwJVwiIH19XHJcbiAgICAgICAgPlxyXG4gICAgICAgICAge25vdGlmaWNhdGlvbi5tZXNzYWdlfVxyXG4gICAgICAgIDwvQWxlcnQ+XHJcbiAgICAgIDwvU25hY2tiYXI+XHJcbiAgICA8L0NvbnRhaW5lcj5cclxuICApO1xyXG59Il0sImZpbGUiOiJDOi9Vc2Vycy9zX21hci9jczMyL1NuYWNrU3RhY2svY2xpZW50L3NyYy9jb21wb25lbnRzL1Byb2ZpbGUudHN4In0=