import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/RecipesPage.tsx");import { jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/s_mar/cs32/SnackStack/client/src/pages/RecipesPage.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import { Accordion, AccordionDetails, AccordionSummary, Box, Button, Card, CardContent, Container, Typography, List, ListItem, ListItemText, Divider, Snackbar, Alert } from "/node_modules/.vite/deps/@mui_material.js?v=4d3a3d4b";
import ExpandMoreIcon from "/node_modules/.vite/deps/@mui_icons-material_ExpandMore.js?v=4d3a3d4b";
import __vite__cjsImport5_react from "/node_modules/.vite/deps/react.js?v=4d3a3d4b"; const useEffect = __vite__cjsImport5_react["useEffect"]; const useState = __vite__cjsImport5_react["useState"];
import { useLocation, useNavigate } from "/node_modules/.vite/deps/react-router-dom.js?v=4d3a3d4b";
import axios from "/node_modules/.vite/deps/axios.js?v=4d3a3d4b";
import { useUserContext } from "/src/contexts/UserContext.tsx";
const API_URL = "http://localhost:8080/api/history";
function RecipesPage() {
  _s();
  const {
    state
  } = useLocation();
  const navigate = useNavigate();
  const {
    dbUserId
  } = useUserContext();
  const [recipes, setRecipes] = useState(state?.recipes ?? []);
  const [selectedRecipeId, setSelectedRecipeId] = useState(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState(null);
  const [showSuccess, setShowSuccess] = useState(false);
  useEffect(() => {
    if (state?.recipes?.length) {
      setRecipes(state.recipes);
    } else {
      navigate("/cook", {
        replace: true
      });
    }
  }, [state, navigate]);
  const backToCookPage = () => {
    navigate("/cook");
  };
  const handleSelectRecipe = (uuid) => {
    setSelectedRecipeId(uuid);
  };
  const handleConfirmSelection = async () => {
    if (!selectedRecipeId)
      return;
    if (!dbUserId) {
      setError("Please log in to save recipes to your history");
      return;
    }
    try {
      setIsSubmitting(true);
      setError(null);
      await axios.post(API_URL, {
        userId: dbUserId,
        recipeUuid: selectedRecipeId
      });
      const selectedRecipe = recipes.find((r) => r.uuid === selectedRecipeId);
      if (selectedRecipe) {
        setRecipes([selectedRecipe]);
        setShowSuccess(true);
        setTimeout(() => {
          navigate("/recipe-details", {
            state: {
              recipe: selectedRecipe
            }
          });
        }, 1500);
      }
    } catch (err) {
      console.error("Error confirming recipe:", err);
      setError("Failed to save recipe to history. Please try again.");
    } finally {
      setIsSubmitting(false);
    }
  };
  return /* @__PURE__ */ jsxDEV(Container, { maxWidth: "md", sx: {
    py: 4
  }, children: [
    /* @__PURE__ */ jsxDEV(Typography, { variant: "h4", gutterBottom: true, fontWeight: 600, textAlign: "center", children: "Your Generated Recipes" }, void 0, false, {
      fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/pages/RecipesPage.tsx",
      lineNumber: 84,
      columnNumber: 7
    }, this),
    recipes.map((recipe) => /* @__PURE__ */ jsxDEV(Card, { sx: {
      mb: 4,
      boxShadow: 3
    }, children: [
      /* @__PURE__ */ jsxDEV(CardContent, { children: [
        /* @__PURE__ */ jsxDEV(Typography, { variant: "h5", fontWeight: 600, children: recipe.recipeName }, void 0, false, {
          fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/pages/RecipesPage.tsx",
          lineNumber: 93,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV(Typography, { color: "text.secondary", gutterBottom: true, children: [
          recipe.originName || "Unknown origin",
          " · ",
          recipe.servings,
          " ",
          "servings"
        ] }, void 0, true, {
          fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/pages/RecipesPage.tsx",
          lineNumber: 96,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV(Typography, { variant: "body1", sx: {
          mt: 1,
          mb: 2
        }, children: recipe.description }, void 0, false, {
          fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/pages/RecipesPage.tsx",
          lineNumber: 100,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV(Accordion, { children: [
          /* @__PURE__ */ jsxDEV(AccordionSummary, { expandIcon: /* @__PURE__ */ jsxDEV(ExpandMoreIcon, {}, void 0, false, {
            fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/pages/RecipesPage.tsx",
            lineNumber: 108,
            columnNumber: 45
          }, this), children: /* @__PURE__ */ jsxDEV(Typography, { fontWeight: 500, children: "View Details" }, void 0, false, {
            fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/pages/RecipesPage.tsx",
            lineNumber: 109,
            columnNumber: 17
          }, this) }, void 0, false, {
            fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/pages/RecipesPage.tsx",
            lineNumber: 108,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV(AccordionDetails, { children: [
            /* @__PURE__ */ jsxDEV(Box, { mb: 2, children: [
              /* @__PURE__ */ jsxDEV(Typography, { variant: "subtitle1", fontWeight: 600, children: "Ingredients" }, void 0, false, {
                fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/pages/RecipesPage.tsx",
                lineNumber: 114,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV(List, { dense: true, children: recipe.recipeIngredients.map((ing, i) => /* @__PURE__ */ jsxDEV(ListItem, { children: /* @__PURE__ */ jsxDEV(ListItemText, { primary: `${ing.ingredientName} — ${ing.quantity} ${ing.unit ?? ""}`, secondary: ing.note }, void 0, false, {
                fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/pages/RecipesPage.tsx",
                lineNumber: 119,
                columnNumber: 27
              }, this) }, i, false, {
                fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/pages/RecipesPage.tsx",
                lineNumber: 118,
                columnNumber: 83
              }, this)) }, void 0, false, {
                fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/pages/RecipesPage.tsx",
                lineNumber: 117,
                columnNumber: 19
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/pages/RecipesPage.tsx",
              lineNumber: 113,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV(Divider, { sx: {
              my: 2
            } }, void 0, false, {
              fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/pages/RecipesPage.tsx",
              lineNumber: 124,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV(Box, { children: [
              /* @__PURE__ */ jsxDEV(Typography, { variant: "subtitle1", fontWeight: 600, children: "Steps" }, void 0, false, {
                fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/pages/RecipesPage.tsx",
                lineNumber: 130,
                columnNumber: 19
              }, this),
              /* @__PURE__ */ jsxDEV(List, { dense: true, children: recipe.recipeSteps.map((step, j) => /* @__PURE__ */ jsxDEV(ListItem, { children: /* @__PURE__ */ jsxDEV(ListItemText, { primaryTypographyProps: {
                style: {
                  whiteSpace: "pre-line"
                }
              }, primary: `${j + 1}. ${step}` }, void 0, false, {
                fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/pages/RecipesPage.tsx",
                lineNumber: 135,
                columnNumber: 25
              }, this) }, j, false, {
                fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/pages/RecipesPage.tsx",
                lineNumber: 134,
                columnNumber: 74
              }, this)) }, void 0, false, {
                fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/pages/RecipesPage.tsx",
                lineNumber: 133,
                columnNumber: 19
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/pages/RecipesPage.tsx",
              lineNumber: 129,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/pages/RecipesPage.tsx",
            lineNumber: 111,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/pages/RecipesPage.tsx",
          lineNumber: 107,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/pages/RecipesPage.tsx",
        lineNumber: 92,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV(Box, { sx: {
        display: "flex",
        justifyContent: "center",
        mb: 2
      }, children: /* @__PURE__ */ jsxDEV(Button, { variant: selectedRecipeId === recipe.uuid ? "contained" : "outlined", color: "primary", onClick: () => handleSelectRecipe(recipe.uuid), sx: {
        mt: 2
      }, children: selectedRecipeId === recipe.uuid ? "Selected" : "Select this recipe" }, void 0, false, {
        fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/pages/RecipesPage.tsx",
        lineNumber: 151,
        columnNumber: 13
      }, this) }, void 0, false, {
        fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/pages/RecipesPage.tsx",
        lineNumber: 146,
        columnNumber: 11
      }, this)
    ] }, recipe.uuid, true, {
      fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/pages/RecipesPage.tsx",
      lineNumber: 88,
      columnNumber: 30
    }, this)),
    /* @__PURE__ */ jsxDEV(Box, { sx: {
      display: "flex",
      justifyContent: "space-between"
    }, children: [
      /* @__PURE__ */ jsxDEV(Button, { "aria-label": "recipes-page-back-btn", variant: "contained", color: "success", sx: {
        px: 4,
        py: 1.5,
        fontWeight: 500
      }, onClick: backToCookPage, children: "Back" }, void 0, false, {
        fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/pages/RecipesPage.tsx",
        lineNumber: 163,
        columnNumber: 9
      }, this),
      selectedRecipeId && /* @__PURE__ */ jsxDEV(Button, { "aria-label": "confirm-selection-btn", variant: "contained", color: "secondary", sx: {
        px: 4,
        py: 1.5,
        fontWeight: 500
      }, onClick: handleConfirmSelection, disabled: isSubmitting, children: isSubmitting ? "Saving..." : "Confirm" }, void 0, false, {
        fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/pages/RecipesPage.tsx",
        lineNumber: 171,
        columnNumber: 30
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/pages/RecipesPage.tsx",
      lineNumber: 159,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(Snackbar, { open: !!error, autoHideDuration: 6e3, onClose: () => setError(null), children: /* @__PURE__ */ jsxDEV(Alert, { severity: "error", onClose: () => setError(null), children: error }, void 0, false, {
      fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/pages/RecipesPage.tsx",
      lineNumber: 182,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/pages/RecipesPage.tsx",
      lineNumber: 181,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(Snackbar, { open: showSuccess, autoHideDuration: 3e3, onClose: () => setShowSuccess(false), children: /* @__PURE__ */ jsxDEV(Alert, { severity: "success", onClose: () => setShowSuccess(false), children: "Recipe saved to your history!" }, void 0, false, {
      fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/pages/RecipesPage.tsx",
      lineNumber: 188,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/pages/RecipesPage.tsx",
      lineNumber: 187,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/pages/RecipesPage.tsx",
    lineNumber: 81,
    columnNumber: 10
  }, this);
}
_s(RecipesPage, "0keq4po11jW2LsPICySINRdVLfQ=", false, function() {
  return [useLocation, useNavigate, useUserContext];
});
_c = RecipesPage;
export default RecipesPage;
var _c;
$RefreshReg$(_c, "RecipesPage");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/s_mar/cs32/SnackStack/client/src/pages/RecipesPage.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBOEZNOzs7Ozs7Ozs7Ozs7Ozs7O0FBOUZOLFNBQ0VBLFdBQ0FDLGtCQUNBQyxrQkFDQUMsS0FDQUMsUUFDQUMsTUFDQUMsYUFDQUMsV0FDQUMsWUFDQUMsTUFDQUMsVUFDQUMsY0FDQUMsU0FDQUMsVUFDQUMsYUFDSztBQUNQLE9BQU9DLG9CQUFvQjtBQUMzQixTQUFTQyxXQUFXQyxnQkFBZ0I7QUFDcEMsU0FBU0MsYUFBYUMsbUJBQW1CO0FBQ3pDLE9BQU9DLFdBQVc7QUFDbEIsU0FBU0Msc0JBQXNCO0FBRy9CLE1BQU1DLFVBQVU7QUFFaEIsU0FBU0MsY0FBYztBQUFBQyxLQUFBO0FBQ3JCLFFBQU07QUFBQSxJQUFFQztBQUFBQSxFQUFNLElBQUlQLFlBQVk7QUFDOUIsUUFBTVEsV0FBV1AsWUFBWTtBQUM3QixRQUFNO0FBQUEsSUFBRVE7QUFBQUEsRUFBUyxJQUFJTixlQUFlO0FBQ3BDLFFBQU0sQ0FBQ08sU0FBU0MsVUFBVSxJQUFJWixTQUFtQlEsT0FBT0csV0FBVyxFQUFFO0FBQ3JFLFFBQU0sQ0FBQ0Usa0JBQWtCQyxtQkFBbUIsSUFBSWQsU0FBd0IsSUFBSTtBQUM1RSxRQUFNLENBQUNlLGNBQWNDLGVBQWUsSUFBSWhCLFNBQVMsS0FBSztBQUN0RCxRQUFNLENBQUNpQixPQUFPQyxRQUFRLElBQUlsQixTQUF3QixJQUFJO0FBQ3RELFFBQU0sQ0FBQ21CLGFBQWFDLGNBQWMsSUFBSXBCLFNBQVMsS0FBSztBQUVwREQsWUFBVSxNQUFNO0FBQ2QsUUFBSVMsT0FBT0csU0FBU1UsUUFBUTtBQUMxQlQsaUJBQVdKLE1BQU1HLE9BQU87QUFBQSxJQUMxQixPQUFPO0FBQ0xGLGVBQVMsU0FBUztBQUFBLFFBQUVhLFNBQVM7QUFBQSxNQUFLLENBQUM7QUFBQSxJQUNyQztBQUFBLEVBQ0YsR0FBRyxDQUFDZCxPQUFPQyxRQUFRLENBQUM7QUFFcEIsUUFBTWMsaUJBQWlCQSxNQUFNO0FBQzNCZCxhQUFTLE9BQU87QUFBQSxFQUNsQjtBQUVBLFFBQU1lLHFCQUFxQkEsQ0FBQ0MsU0FBaUI7QUFDM0NYLHdCQUFvQlcsSUFBSTtBQUFBLEVBQzFCO0FBRUEsUUFBTUMseUJBQXlCLFlBQVk7QUFDekMsUUFBSSxDQUFDYjtBQUFrQjtBQUd2QixRQUFJLENBQUNILFVBQVU7QUFDYlEsZUFBUywrQ0FBK0M7QUFDeEQ7QUFBQSxJQUNGO0FBRUEsUUFBSTtBQUNGRixzQkFBZ0IsSUFBSTtBQUNwQkUsZUFBUyxJQUFJO0FBR2IsWUFBTWYsTUFBTXdCLEtBQUt0QixTQUFTO0FBQUEsUUFDeEJ1QixRQUFRbEI7QUFBQUEsUUFDUm1CLFlBQVloQjtBQUFBQSxNQUNkLENBQUM7QUFHRCxZQUFNaUIsaUJBQWlCbkIsUUFBUW9CLEtBQU1DLE9BQU1BLEVBQUVQLFNBQVNaLGdCQUFnQjtBQUN0RSxVQUFJaUIsZ0JBQWdCO0FBQ2xCbEIsbUJBQVcsQ0FBQ2tCLGNBQWMsQ0FBQztBQUMzQlYsdUJBQWUsSUFBSTtBQUduQmEsbUJBQVcsTUFBTTtBQUNmeEIsbUJBQVMsbUJBQW1CO0FBQUEsWUFDMUJELE9BQU87QUFBQSxjQUFFMEIsUUFBUUo7QUFBQUEsWUFBZTtBQUFBLFVBQ2xDLENBQUM7QUFBQSxRQUNILEdBQUcsSUFBSTtBQUFBLE1BQ1Q7QUFBQSxJQUNGLFNBQVNLLEtBQUs7QUFDWkMsY0FBUW5CLE1BQU0sNEJBQTRCa0IsR0FBRztBQUM3Q2pCLGVBQVMscURBQXFEO0FBQUEsSUFDaEUsVUFBQztBQUNDRixzQkFBZ0IsS0FBSztBQUFBLElBQ3ZCO0FBQUEsRUFDRjtBQUVBLFNBQ0UsdUJBQUMsYUFBVSxVQUFTLE1BQUssSUFBSTtBQUFBLElBQUVxQixJQUFJO0FBQUEsRUFBRSxHQUNuQztBQUFBLDJCQUFDLGNBQVcsU0FBUSxNQUFLLGNBQVksTUFBQyxZQUFZLEtBQUssV0FBVSxVQUFTLHNDQUExRTtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBRUE7QUFBQSxJQUVDMUIsUUFBUTJCLElBQUtKLFlBQ1osdUJBQUMsUUFBdUIsSUFBSTtBQUFBLE1BQUVLLElBQUk7QUFBQSxNQUFHQyxXQUFXO0FBQUEsSUFBRSxHQUNoRDtBQUFBLDZCQUFDLGVBQ0M7QUFBQSwrQkFBQyxjQUFXLFNBQVEsTUFBSyxZQUFZLEtBQ2xDTixpQkFBT08sY0FEVjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQSxRQUNBLHVCQUFDLGNBQVcsT0FBTSxrQkFBaUIsY0FBWSxNQUM1Q1A7QUFBQUEsaUJBQU9RLGNBQWM7QUFBQSxVQUFpQjtBQUFBLFVBQUlSLE9BQU9TO0FBQUFBLFVBQVU7QUFBQSxVQUFJO0FBQUEsYUFEbEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUdBO0FBQUEsUUFDQSx1QkFBQyxjQUFXLFNBQVEsU0FBUSxJQUFJO0FBQUEsVUFBRUMsSUFBSTtBQUFBLFVBQUdMLElBQUk7QUFBQSxRQUFFLEdBQzVDTCxpQkFBT1csZUFEVjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQSxRQUVBLHVCQUFDLGFBQ0M7QUFBQSxpQ0FBQyxvQkFBaUIsWUFBWSx1QkFBQyxvQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFlLEdBQzNDLGlDQUFDLGNBQVcsWUFBWSxLQUFLLDRCQUE3QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUF5QyxLQUQzQztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsVUFDQSx1QkFBQyxvQkFFQztBQUFBLG1DQUFDLE9BQUksSUFBSSxHQUNQO0FBQUEscUNBQUMsY0FBVyxTQUFRLGFBQVksWUFBWSxLQUFLLDJCQUFqRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsY0FDQSx1QkFBQyxRQUFLLE9BQUssTUFDUlgsaUJBQU9ZLGtCQUFrQlIsSUFDeEIsQ0FBQ1MsS0FBaUJDLE1BQ2hCLHVCQUFDLFlBQ0MsaUNBQUMsZ0JBQ0MsU0FBUyxHQUFHRCxJQUFJRSxjQUFjLE1BQU1GLElBQUlHLFFBQVEsSUFDOUNILElBQUlJLFFBQVEsRUFBRSxJQUVoQixXQUFXSixJQUFJSyxRQUpqQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUlzQixLQUxUSixHQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBT0EsQ0FFSixLQVpGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBYUE7QUFBQSxpQkFqQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFrQkE7QUFBQSxZQUVBLHVCQUFDLFdBQVEsSUFBSTtBQUFBLGNBQUVLLElBQUk7QUFBQSxZQUFFLEtBQXJCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXVCO0FBQUEsWUFHdkIsdUJBQUMsT0FDQztBQUFBLHFDQUFDLGNBQVcsU0FBUSxhQUFZLFlBQVksS0FBSyxxQkFBakQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBLGNBQ0EsdUJBQUMsUUFBSyxPQUFLLE1BQ1JuQixpQkFBT29CLFlBQVloQixJQUFJLENBQUNpQixNQUFjQyxNQUNyQyx1QkFBQyxZQUNDLGlDQUFDLGdCQUNDLHdCQUF3QjtBQUFBLGdCQUN0QkMsT0FBTztBQUFBLGtCQUFFQyxZQUFZO0FBQUEsZ0JBQVc7QUFBQSxjQUNsQyxHQUNBLFNBQVMsR0FBR0YsSUFBSSxDQUFDLEtBQUtELElBQUksTUFKNUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFJK0IsS0FMbEJDLEdBQWY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFPQSxDQUNELEtBVkg7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFXQTtBQUFBLGlCQWZGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBZ0JBO0FBQUEsZUF6Q0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkEwQ0E7QUFBQSxhQTlDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBK0NBO0FBQUEsV0EzREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQTREQTtBQUFBLE1BQ0EsdUJBQUMsT0FBSSxJQUFJO0FBQUEsUUFBRUcsU0FBUztBQUFBLFFBQVFDLGdCQUFnQjtBQUFBLFFBQVVyQixJQUFJO0FBQUEsTUFBRSxHQUMxRCxpQ0FBQyxVQUNDLFNBQ0UxQixxQkFBcUJxQixPQUFPVCxPQUFPLGNBQWMsWUFFbkQsT0FBTSxXQUNOLFNBQVMsTUFBTUQsbUJBQW1CVSxPQUFPVCxJQUFJLEdBQzdDLElBQUk7QUFBQSxRQUFFbUIsSUFBSTtBQUFBLE1BQUUsR0FFWC9CLCtCQUFxQnFCLE9BQU9ULE9BQ3pCLGFBQ0Esd0JBVk47QUFBQTtBQUFBO0FBQUE7QUFBQSxhQVdBLEtBWkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQWFBO0FBQUEsU0EzRVNTLE9BQU9ULE1BQWxCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0E0RUEsQ0FDRDtBQUFBLElBRUQsdUJBQUMsT0FBSSxJQUFJO0FBQUEsTUFBRWtDLFNBQVM7QUFBQSxNQUFRQyxnQkFBZ0I7QUFBQSxJQUFnQixHQUMxRDtBQUFBLDZCQUFDLFVBQ0MsY0FBVyx5QkFDWCxTQUFRLGFBQ1IsT0FBTSxXQUNOLElBQUk7QUFBQSxRQUFFQyxJQUFJO0FBQUEsUUFBR3hCLElBQUk7QUFBQSxRQUFLeUIsWUFBWTtBQUFBLE1BQUksR0FDdEMsU0FBU3ZDLGdCQUNWLG9CQU5EO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFRQTtBQUFBLE1BRUNWLG9CQUNDLHVCQUFDLFVBQ0MsY0FBVyx5QkFDWCxTQUFRLGFBQ1IsT0FBTSxhQUNOLElBQUk7QUFBQSxRQUFFZ0QsSUFBSTtBQUFBLFFBQUd4QixJQUFJO0FBQUEsUUFBS3lCLFlBQVk7QUFBQSxNQUFJLEdBQ3RDLFNBQVNwQyx3QkFDVCxVQUFVWCxjQUVUQSx5QkFBZSxjQUFjLGFBUmhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFTQTtBQUFBLFNBckJKO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0F1QkE7QUFBQSxJQUdBLHVCQUFDLFlBQ0MsTUFBTSxDQUFDLENBQUNFLE9BQ1Isa0JBQWtCLEtBQ2xCLFNBQVMsTUFBTUMsU0FBUyxJQUFJLEdBRTVCLGlDQUFDLFNBQU0sVUFBUyxTQUFRLFNBQVMsTUFBTUEsU0FBUyxJQUFJLEdBQ2pERCxtQkFESDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBRUEsS0FQRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBUUE7QUFBQSxJQUVBLHVCQUFDLFlBQ0MsTUFBTUUsYUFDTixrQkFBa0IsS0FDbEIsU0FBUyxNQUFNQyxlQUFlLEtBQUssR0FFbkMsaUNBQUMsU0FBTSxVQUFTLFdBQVUsU0FBUyxNQUFNQSxlQUFlLEtBQUssR0FBRyw2Q0FBaEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUVBLEtBUEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQVFBO0FBQUEsT0FqSUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQWtJQTtBQUVKO0FBQUNiLEdBdk1RRCxhQUFXO0FBQUEsVUFDQUwsYUFDREMsYUFDSUUsY0FBYztBQUFBO0FBQUEyRCxLQUg1QnpEO0FBeU1ULGVBQWVBO0FBQVksSUFBQXlEO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJBY2NvcmRpb24iLCJBY2NvcmRpb25EZXRhaWxzIiwiQWNjb3JkaW9uU3VtbWFyeSIsIkJveCIsIkJ1dHRvbiIsIkNhcmQiLCJDYXJkQ29udGVudCIsIkNvbnRhaW5lciIsIlR5cG9ncmFwaHkiLCJMaXN0IiwiTGlzdEl0ZW0iLCJMaXN0SXRlbVRleHQiLCJEaXZpZGVyIiwiU25hY2tiYXIiLCJBbGVydCIsIkV4cGFuZE1vcmVJY29uIiwidXNlRWZmZWN0IiwidXNlU3RhdGUiLCJ1c2VMb2NhdGlvbiIsInVzZU5hdmlnYXRlIiwiYXhpb3MiLCJ1c2VVc2VyQ29udGV4dCIsIkFQSV9VUkwiLCJSZWNpcGVzUGFnZSIsIl9zIiwic3RhdGUiLCJuYXZpZ2F0ZSIsImRiVXNlcklkIiwicmVjaXBlcyIsInNldFJlY2lwZXMiLCJzZWxlY3RlZFJlY2lwZUlkIiwic2V0U2VsZWN0ZWRSZWNpcGVJZCIsImlzU3VibWl0dGluZyIsInNldElzU3VibWl0dGluZyIsImVycm9yIiwic2V0RXJyb3IiLCJzaG93U3VjY2VzcyIsInNldFNob3dTdWNjZXNzIiwibGVuZ3RoIiwicmVwbGFjZSIsImJhY2tUb0Nvb2tQYWdlIiwiaGFuZGxlU2VsZWN0UmVjaXBlIiwidXVpZCIsImhhbmRsZUNvbmZpcm1TZWxlY3Rpb24iLCJwb3N0IiwidXNlcklkIiwicmVjaXBlVXVpZCIsInNlbGVjdGVkUmVjaXBlIiwiZmluZCIsInIiLCJzZXRUaW1lb3V0IiwicmVjaXBlIiwiZXJyIiwiY29uc29sZSIsInB5IiwibWFwIiwibWIiLCJib3hTaGFkb3ciLCJyZWNpcGVOYW1lIiwib3JpZ2luTmFtZSIsInNlcnZpbmdzIiwibXQiLCJkZXNjcmlwdGlvbiIsInJlY2lwZUluZ3JlZGllbnRzIiwiaW5nIiwiaSIsImluZ3JlZGllbnROYW1lIiwicXVhbnRpdHkiLCJ1bml0Iiwibm90ZSIsIm15IiwicmVjaXBlU3RlcHMiLCJzdGVwIiwiaiIsInN0eWxlIiwid2hpdGVTcGFjZSIsImRpc3BsYXkiLCJqdXN0aWZ5Q29udGVudCIsInB4IiwiZm9udFdlaWdodCIsIl9jIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiUmVjaXBlc1BhZ2UudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7XHJcbiAgQWNjb3JkaW9uLFxyXG4gIEFjY29yZGlvbkRldGFpbHMsXHJcbiAgQWNjb3JkaW9uU3VtbWFyeSxcclxuICBCb3gsXHJcbiAgQnV0dG9uLFxyXG4gIENhcmQsXHJcbiAgQ2FyZENvbnRlbnQsXHJcbiAgQ29udGFpbmVyLFxyXG4gIFR5cG9ncmFwaHksXHJcbiAgTGlzdCxcclxuICBMaXN0SXRlbSxcclxuICBMaXN0SXRlbVRleHQsXHJcbiAgRGl2aWRlcixcclxuICBTbmFja2JhcixcclxuICBBbGVydCxcclxufSBmcm9tIFwiQG11aS9tYXRlcmlhbFwiO1xyXG5pbXBvcnQgRXhwYW5kTW9yZUljb24gZnJvbSBcIkBtdWkvaWNvbnMtbWF0ZXJpYWwvRXhwYW5kTW9yZVwiO1xyXG5pbXBvcnQgeyB1c2VFZmZlY3QsIHVzZVN0YXRlIH0gZnJvbSBcInJlYWN0XCI7XHJcbmltcG9ydCB7IHVzZUxvY2F0aW9uLCB1c2VOYXZpZ2F0ZSB9IGZyb20gXCJyZWFjdC1yb3V0ZXItZG9tXCI7XHJcbmltcG9ydCBheGlvcyBmcm9tIFwiYXhpb3NcIjtcclxuaW1wb3J0IHsgdXNlVXNlckNvbnRleHQgfSBmcm9tIFwiLi4vY29udGV4dHMvVXNlckNvbnRleHRcIjsgLy8gSW1wb3J0IHRoZSBVc2VyQ29udGV4dCBob29rXHJcbmltcG9ydCB0eXBlIHsgSW5ncmVkaWVudCwgUmVjaXBlLCBMb2NhdGlvblN0YXRlIH0gZnJvbSBcIi4uL3R5cGVzL3JlY2lwZVwiO1xyXG5cclxuY29uc3QgQVBJX1VSTCA9IFwiaHR0cDovL2xvY2FsaG9zdDo4MDgwL2FwaS9oaXN0b3J5XCI7XHJcblxyXG5mdW5jdGlvbiBSZWNpcGVzUGFnZSgpIHtcclxuICBjb25zdCB7IHN0YXRlIH0gPSB1c2VMb2NhdGlvbigpIGFzIHsgc3RhdGU/OiBMb2NhdGlvblN0YXRlIH07XHJcbiAgY29uc3QgbmF2aWdhdGUgPSB1c2VOYXZpZ2F0ZSgpO1xyXG4gIGNvbnN0IHsgZGJVc2VySWQgfSA9IHVzZVVzZXJDb250ZXh0KCk7IC8vIEdldCB1c2VyIElEIGZyb20gY29udGV4dFxyXG4gIGNvbnN0IFtyZWNpcGVzLCBzZXRSZWNpcGVzXSA9IHVzZVN0YXRlPFJlY2lwZVtdPihzdGF0ZT8ucmVjaXBlcyA/PyBbXSk7XHJcbiAgY29uc3QgW3NlbGVjdGVkUmVjaXBlSWQsIHNldFNlbGVjdGVkUmVjaXBlSWRdID0gdXNlU3RhdGU8c3RyaW5nIHwgbnVsbD4obnVsbCk7XHJcbiAgY29uc3QgW2lzU3VibWl0dGluZywgc2V0SXNTdWJtaXR0aW5nXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICBjb25zdCBbZXJyb3IsIHNldEVycm9yXSA9IHVzZVN0YXRlPHN0cmluZyB8IG51bGw+KG51bGwpO1xyXG4gIGNvbnN0IFtzaG93U3VjY2Vzcywgc2V0U2hvd1N1Y2Nlc3NdID0gdXNlU3RhdGUoZmFsc2UpO1xyXG5cclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgaWYgKHN0YXRlPy5yZWNpcGVzPy5sZW5ndGgpIHtcclxuICAgICAgc2V0UmVjaXBlcyhzdGF0ZS5yZWNpcGVzKTtcclxuICAgIH0gZWxzZSB7XHJcbiAgICAgIG5hdmlnYXRlKFwiL2Nvb2tcIiwgeyByZXBsYWNlOiB0cnVlIH0pO1xyXG4gICAgfVxyXG4gIH0sIFtzdGF0ZSwgbmF2aWdhdGVdKTtcclxuXHJcbiAgY29uc3QgYmFja1RvQ29va1BhZ2UgPSAoKSA9PiB7XHJcbiAgICBuYXZpZ2F0ZShcIi9jb29rXCIpO1xyXG4gIH07XHJcblxyXG4gIGNvbnN0IGhhbmRsZVNlbGVjdFJlY2lwZSA9ICh1dWlkOiBzdHJpbmcpID0+IHtcclxuICAgIHNldFNlbGVjdGVkUmVjaXBlSWQodXVpZCk7XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgaGFuZGxlQ29uZmlybVNlbGVjdGlvbiA9IGFzeW5jICgpID0+IHtcclxuICAgIGlmICghc2VsZWN0ZWRSZWNpcGVJZCkgcmV0dXJuO1xyXG5cclxuICAgIC8vIENoZWNrIGlmIHVzZXIgaXMgbG9nZ2VkIGluXHJcbiAgICBpZiAoIWRiVXNlcklkKSB7XHJcbiAgICAgIHNldEVycm9yKFwiUGxlYXNlIGxvZyBpbiB0byBzYXZlIHJlY2lwZXMgdG8geW91ciBoaXN0b3J5XCIpO1xyXG4gICAgICByZXR1cm47XHJcbiAgICB9XHJcblxyXG4gICAgdHJ5IHtcclxuICAgICAgc2V0SXNTdWJtaXR0aW5nKHRydWUpO1xyXG4gICAgICBzZXRFcnJvcihudWxsKTtcclxuXHJcbiAgICAgIC8vIFNlbmQgcmVxdWVzdCB0byBhZGQgcmVjaXBlIHRvIGhpc3RvcnkgdXNpbmcgdGhlIHVzZXIgSUQgZnJvbSBjb250ZXh0XHJcbiAgICAgIGF3YWl0IGF4aW9zLnBvc3QoQVBJX1VSTCwge1xyXG4gICAgICAgIHVzZXJJZDogZGJVc2VySWQsXHJcbiAgICAgICAgcmVjaXBlVXVpZDogc2VsZWN0ZWRSZWNpcGVJZCxcclxuICAgICAgfSk7XHJcblxyXG4gICAgICAvLyBGaWx0ZXIgdG8ga2VlcCBvbmx5IHRoZSBzZWxlY3RlZCByZWNpcGVcclxuICAgICAgY29uc3Qgc2VsZWN0ZWRSZWNpcGUgPSByZWNpcGVzLmZpbmQoKHIpID0+IHIudXVpZCA9PT0gc2VsZWN0ZWRSZWNpcGVJZCk7XHJcbiAgICAgIGlmIChzZWxlY3RlZFJlY2lwZSkge1xyXG4gICAgICAgIHNldFJlY2lwZXMoW3NlbGVjdGVkUmVjaXBlXSk7XHJcbiAgICAgICAgc2V0U2hvd1N1Y2Nlc3ModHJ1ZSk7XHJcblxyXG4gICAgICAgIC8vIE5hdmlnYXRlIHRvIGRldGFpbHMgcGFnZSBhZnRlciBhIHNob3J0IGRlbGF5XHJcbiAgICAgICAgc2V0VGltZW91dCgoKSA9PiB7XHJcbiAgICAgICAgICBuYXZpZ2F0ZShcIi9yZWNpcGUtZGV0YWlsc1wiLCB7XHJcbiAgICAgICAgICAgIHN0YXRlOiB7IHJlY2lwZTogc2VsZWN0ZWRSZWNpcGUgfSxcclxuICAgICAgICAgIH0pO1xyXG4gICAgICAgIH0sIDE1MDApO1xyXG4gICAgICB9XHJcbiAgICB9IGNhdGNoIChlcnIpIHtcclxuICAgICAgY29uc29sZS5lcnJvcihcIkVycm9yIGNvbmZpcm1pbmcgcmVjaXBlOlwiLCBlcnIpO1xyXG4gICAgICBzZXRFcnJvcihcIkZhaWxlZCB0byBzYXZlIHJlY2lwZSB0byBoaXN0b3J5LiBQbGVhc2UgdHJ5IGFnYWluLlwiKTtcclxuICAgIH0gZmluYWxseSB7XHJcbiAgICAgIHNldElzU3VibWl0dGluZyhmYWxzZSk7XHJcbiAgICB9XHJcbiAgfTtcclxuXHJcbiAgcmV0dXJuIChcclxuICAgIDxDb250YWluZXIgbWF4V2lkdGg9XCJtZFwiIHN4PXt7IHB5OiA0IH19PlxyXG4gICAgICA8VHlwb2dyYXBoeSB2YXJpYW50PVwiaDRcIiBndXR0ZXJCb3R0b20gZm9udFdlaWdodD17NjAwfSB0ZXh0QWxpZ249XCJjZW50ZXJcIj5cclxuICAgICAgICBZb3VyIEdlbmVyYXRlZCBSZWNpcGVzXHJcbiAgICAgIDwvVHlwb2dyYXBoeT5cclxuXHJcbiAgICAgIHtyZWNpcGVzLm1hcCgocmVjaXBlKSA9PiAoXHJcbiAgICAgICAgPENhcmQga2V5PXtyZWNpcGUudXVpZH0gc3g9e3sgbWI6IDQsIGJveFNoYWRvdzogMyB9fT5cclxuICAgICAgICAgIDxDYXJkQ29udGVudD5cclxuICAgICAgICAgICAgPFR5cG9ncmFwaHkgdmFyaWFudD1cImg1XCIgZm9udFdlaWdodD17NjAwfT5cclxuICAgICAgICAgICAgICB7cmVjaXBlLnJlY2lwZU5hbWV9XHJcbiAgICAgICAgICAgIDwvVHlwb2dyYXBoeT5cclxuICAgICAgICAgICAgPFR5cG9ncmFwaHkgY29sb3I9XCJ0ZXh0LnNlY29uZGFyeVwiIGd1dHRlckJvdHRvbT5cclxuICAgICAgICAgICAgICB7cmVjaXBlLm9yaWdpbk5hbWUgfHwgXCJVbmtub3duIG9yaWdpblwifSDCtyB7cmVjaXBlLnNlcnZpbmdzfXtcIiBcIn1cclxuICAgICAgICAgICAgICBzZXJ2aW5nc1xyXG4gICAgICAgICAgICA8L1R5cG9ncmFwaHk+XHJcbiAgICAgICAgICAgIDxUeXBvZ3JhcGh5IHZhcmlhbnQ9XCJib2R5MVwiIHN4PXt7IG10OiAxLCBtYjogMiB9fT5cclxuICAgICAgICAgICAgICB7cmVjaXBlLmRlc2NyaXB0aW9ufVxyXG4gICAgICAgICAgICA8L1R5cG9ncmFwaHk+XHJcblxyXG4gICAgICAgICAgICA8QWNjb3JkaW9uPlxyXG4gICAgICAgICAgICAgIDxBY2NvcmRpb25TdW1tYXJ5IGV4cGFuZEljb249ezxFeHBhbmRNb3JlSWNvbiAvPn0+XHJcbiAgICAgICAgICAgICAgICA8VHlwb2dyYXBoeSBmb250V2VpZ2h0PXs1MDB9PlZpZXcgRGV0YWlsczwvVHlwb2dyYXBoeT5cclxuICAgICAgICAgICAgICA8L0FjY29yZGlvblN1bW1hcnk+XHJcbiAgICAgICAgICAgICAgPEFjY29yZGlvbkRldGFpbHM+XHJcbiAgICAgICAgICAgICAgICB7LyogSW5ncmVkaWVudHMgKi99XHJcbiAgICAgICAgICAgICAgICA8Qm94IG1iPXsyfT5cclxuICAgICAgICAgICAgICAgICAgPFR5cG9ncmFwaHkgdmFyaWFudD1cInN1YnRpdGxlMVwiIGZvbnRXZWlnaHQ9ezYwMH0+XHJcbiAgICAgICAgICAgICAgICAgICAgSW5ncmVkaWVudHNcclxuICAgICAgICAgICAgICAgICAgPC9UeXBvZ3JhcGh5PlxyXG4gICAgICAgICAgICAgICAgICA8TGlzdCBkZW5zZT5cclxuICAgICAgICAgICAgICAgICAgICB7cmVjaXBlLnJlY2lwZUluZ3JlZGllbnRzLm1hcChcclxuICAgICAgICAgICAgICAgICAgICAgIChpbmc6IEluZ3JlZGllbnQsIGk6IG51bWJlcikgPT4gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8TGlzdEl0ZW0ga2V5PXtpfT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICA8TGlzdEl0ZW1UZXh0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBwcmltYXJ5PXtgJHtpbmcuaW5ncmVkaWVudE5hbWV9IOKAlCAke2luZy5xdWFudGl0eX0gJHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaW5nLnVuaXQgPz8gXCJcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfWB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBzZWNvbmRhcnk9e2luZy5ub3RlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvTGlzdEl0ZW0+XHJcbiAgICAgICAgICAgICAgICAgICAgICApXHJcbiAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgPC9MaXN0PlxyXG4gICAgICAgICAgICAgICAgPC9Cb3g+XHJcblxyXG4gICAgICAgICAgICAgICAgPERpdmlkZXIgc3g9e3sgbXk6IDIgfX0gLz5cclxuXHJcbiAgICAgICAgICAgICAgICB7LyogU3RlcHMgKi99XHJcbiAgICAgICAgICAgICAgICA8Qm94PlxyXG4gICAgICAgICAgICAgICAgICA8VHlwb2dyYXBoeSB2YXJpYW50PVwic3VidGl0bGUxXCIgZm9udFdlaWdodD17NjAwfT5cclxuICAgICAgICAgICAgICAgICAgICBTdGVwc1xyXG4gICAgICAgICAgICAgICAgICA8L1R5cG9ncmFwaHk+XHJcbiAgICAgICAgICAgICAgICAgIDxMaXN0IGRlbnNlPlxyXG4gICAgICAgICAgICAgICAgICAgIHtyZWNpcGUucmVjaXBlU3RlcHMubWFwKChzdGVwOiBzdHJpbmcsIGo6IG51bWJlcikgPT4gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgPExpc3RJdGVtIGtleT17an0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxMaXN0SXRlbVRleHRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBwcmltYXJ5VHlwb2dyYXBoeVByb3BzPXt7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBzdHlsZTogeyB3aGl0ZVNwYWNlOiBcInByZS1saW5lXCIgfSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHByaW1hcnk9e2Ake2ogKyAxfS4gJHtzdGVwfWB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICA8L0xpc3RJdGVtPlxyXG4gICAgICAgICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICAgICAgICA8L0xpc3Q+XHJcbiAgICAgICAgICAgICAgICA8L0JveD5cclxuICAgICAgICAgICAgICA8L0FjY29yZGlvbkRldGFpbHM+XHJcbiAgICAgICAgICAgIDwvQWNjb3JkaW9uPlxyXG4gICAgICAgICAgPC9DYXJkQ29udGVudD5cclxuICAgICAgICAgIDxCb3ggc3g9e3sgZGlzcGxheTogXCJmbGV4XCIsIGp1c3RpZnlDb250ZW50OiBcImNlbnRlclwiLCBtYjogMiB9fT5cclxuICAgICAgICAgICAgPEJ1dHRvblxyXG4gICAgICAgICAgICAgIHZhcmlhbnQ9e1xyXG4gICAgICAgICAgICAgICAgc2VsZWN0ZWRSZWNpcGVJZCA9PT0gcmVjaXBlLnV1aWQgPyBcImNvbnRhaW5lZFwiIDogXCJvdXRsaW5lZFwiXHJcbiAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgIGNvbG9yPVwicHJpbWFyeVwiXHJcbiAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gaGFuZGxlU2VsZWN0UmVjaXBlKHJlY2lwZS51dWlkKX1cclxuICAgICAgICAgICAgICBzeD17eyBtdDogMiB9fVxyXG4gICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAge3NlbGVjdGVkUmVjaXBlSWQgPT09IHJlY2lwZS51dWlkXHJcbiAgICAgICAgICAgICAgICA/IFwiU2VsZWN0ZWRcIlxyXG4gICAgICAgICAgICAgICAgOiBcIlNlbGVjdCB0aGlzIHJlY2lwZVwifVxyXG4gICAgICAgICAgICA8L0J1dHRvbj5cclxuICAgICAgICAgIDwvQm94PlxyXG4gICAgICAgIDwvQ2FyZD5cclxuICAgICAgKSl9XHJcblxyXG4gICAgICA8Qm94IHN4PXt7IGRpc3BsYXk6IFwiZmxleFwiLCBqdXN0aWZ5Q29udGVudDogXCJzcGFjZS1iZXR3ZWVuXCIgfX0+XHJcbiAgICAgICAgPEJ1dHRvblxyXG4gICAgICAgICAgYXJpYS1sYWJlbD1cInJlY2lwZXMtcGFnZS1iYWNrLWJ0blwiXHJcbiAgICAgICAgICB2YXJpYW50PVwiY29udGFpbmVkXCJcclxuICAgICAgICAgIGNvbG9yPVwic3VjY2Vzc1wiXHJcbiAgICAgICAgICBzeD17eyBweDogNCwgcHk6IDEuNSwgZm9udFdlaWdodDogNTAwIH19XHJcbiAgICAgICAgICBvbkNsaWNrPXtiYWNrVG9Db29rUGFnZX1cclxuICAgICAgICA+XHJcbiAgICAgICAgICBCYWNrXHJcbiAgICAgICAgPC9CdXR0b24+XHJcblxyXG4gICAgICAgIHtzZWxlY3RlZFJlY2lwZUlkICYmIChcclxuICAgICAgICAgIDxCdXR0b25cclxuICAgICAgICAgICAgYXJpYS1sYWJlbD1cImNvbmZpcm0tc2VsZWN0aW9uLWJ0blwiXHJcbiAgICAgICAgICAgIHZhcmlhbnQ9XCJjb250YWluZWRcIlxyXG4gICAgICAgICAgICBjb2xvcj1cInNlY29uZGFyeVwiXHJcbiAgICAgICAgICAgIHN4PXt7IHB4OiA0LCBweTogMS41LCBmb250V2VpZ2h0OiA1MDAgfX1cclxuICAgICAgICAgICAgb25DbGljaz17aGFuZGxlQ29uZmlybVNlbGVjdGlvbn1cclxuICAgICAgICAgICAgZGlzYWJsZWQ9e2lzU3VibWl0dGluZ31cclxuICAgICAgICAgID5cclxuICAgICAgICAgICAge2lzU3VibWl0dGluZyA/IFwiU2F2aW5nLi4uXCIgOiBcIkNvbmZpcm1cIn1cclxuICAgICAgICAgIDwvQnV0dG9uPlxyXG4gICAgICAgICl9XHJcbiAgICAgIDwvQm94PlxyXG5cclxuICAgICAgey8qIEVycm9yIGFuZCBzdWNjZXNzIG5vdGlmaWNhdGlvbnMgKi99XHJcbiAgICAgIDxTbmFja2JhclxyXG4gICAgICAgIG9wZW49eyEhZXJyb3J9XHJcbiAgICAgICAgYXV0b0hpZGVEdXJhdGlvbj17NjAwMH1cclxuICAgICAgICBvbkNsb3NlPXsoKSA9PiBzZXRFcnJvcihudWxsKX1cclxuICAgICAgPlxyXG4gICAgICAgIDxBbGVydCBzZXZlcml0eT1cImVycm9yXCIgb25DbG9zZT17KCkgPT4gc2V0RXJyb3IobnVsbCl9PlxyXG4gICAgICAgICAge2Vycm9yfVxyXG4gICAgICAgIDwvQWxlcnQ+XHJcbiAgICAgIDwvU25hY2tiYXI+XHJcblxyXG4gICAgICA8U25hY2tiYXJcclxuICAgICAgICBvcGVuPXtzaG93U3VjY2Vzc31cclxuICAgICAgICBhdXRvSGlkZUR1cmF0aW9uPXszMDAwfVxyXG4gICAgICAgIG9uQ2xvc2U9eygpID0+IHNldFNob3dTdWNjZXNzKGZhbHNlKX1cclxuICAgICAgPlxyXG4gICAgICAgIDxBbGVydCBzZXZlcml0eT1cInN1Y2Nlc3NcIiBvbkNsb3NlPXsoKSA9PiBzZXRTaG93U3VjY2VzcyhmYWxzZSl9PlxyXG4gICAgICAgICAgUmVjaXBlIHNhdmVkIHRvIHlvdXIgaGlzdG9yeSFcclxuICAgICAgICA8L0FsZXJ0PlxyXG4gICAgICA8L1NuYWNrYmFyPlxyXG4gICAgPC9Db250YWluZXI+XHJcbiAgKTtcclxufVxyXG5cclxuZXhwb3J0IGRlZmF1bHQgUmVjaXBlc1BhZ2U7XHJcbiJdLCJmaWxlIjoiQzovVXNlcnMvc19tYXIvY3MzMi9TbmFja1N0YWNrL2NsaWVudC9zcmMvcGFnZXMvUmVjaXBlc1BhZ2UudHN4In0=