import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/RecipeHistory.tsx");import { jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/s_mar/cs32/SnackStack/client/src/pages/RecipeHistory.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import FavoriteIcon from "/node_modules/.vite/deps/@mui_icons-material_Favorite.js?v=4d3a3d4b";
import MenuBookIcon from "/node_modules/.vite/deps/@mui_icons-material_MenuBook.js?v=4d3a3d4b";
import SearchIcon from "/node_modules/.vite/deps/@mui_icons-material_Search.js?v=4d3a3d4b";
import { Box, Button, CircularProgress, InputAdornment, TextField, Typography } from "/node_modules/.vite/deps/@mui_material.js?v=4d3a3d4b";
import ToggleButton from "/node_modules/.vite/deps/@mui_material_ToggleButton.js?v=4d3a3d4b";
import ToggleButtonGroup from "/node_modules/.vite/deps/@mui_material_ToggleButtonGroup.js?v=4d3a3d4b";
import __vite__cjsImport9_react from "/node_modules/.vite/deps/react.js?v=4d3a3d4b"; const useEffect = __vite__cjsImport9_react["useEffect"]; const useState = __vite__cjsImport9_react["useState"];
import { useNavigate } from "/node_modules/.vite/deps/react-router-dom.js?v=4d3a3d4b";
import { RecipeTable } from "/src/components/RecipeTable.tsx";
import "/src/styles/HistoryRecipes.css";
import { useUserContext } from "/src/contexts/UserContext.tsx";
import axios from "/node_modules/.vite/deps/axios.js?v=4d3a3d4b";
const API_BASE_URL = "http://localhost:8080/api";
const buildQueryString = (params) => Object.entries(params).filter(([, v]) => v !== void 0 && v !== null).map(([k, v]) => `${encodeURIComponent(k)}=${encodeURIComponent(String(v))}`).join("&");
const HistoryRecipes = () => {
  _s();
  const navigate = useNavigate();
  const {
    dbUserId
  } = useUserContext();
  const rowsPerPage = 10;
  const [recipes, setRecipes] = useState([]);
  const [page, setPage] = useState(1);
  const [searchTerm, setSearchTerm] = useState("");
  const [showFavoritesOnly, setShowFavoritesOnly] = useState(false);
  const [sortOrder, setSortOrder] = useState("newest");
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState(null);
  const fetchHistory = async () => {
    if (!dbUserId)
      return;
    setIsLoading(true);
    setError(null);
    try {
      const qs = buildQueryString({
        offset: (page - 1) * rowsPerPage,
        limit: rowsPerPage,
        sortAsc: sortOrder === "oldest",
        favoriteOnly: showFavoritesOnly,
        keyword: searchTerm
      });
      const {
        data
      } = await axios.get(`${API_BASE_URL}/history/${dbUserId}?${qs}`);
      const mapped = data.map((d) => ({
        id: d.id,
        uuid: String(d.recipeId),
        recipeName: d.recipeName,
        servings: 0,
        // backend doesn’t send this yet
        recipeDescription: d.recipeDescription ?? "",
        originName: "",
        recipeIngredients: d.recipeIngredients ?? [],
        recipeSteps: d.recipeStep ?? [],
        historyId: d.id,
        createdAt: d.createdAt,
        isFavorite: d.isFavorite
      }));
      setRecipes(mapped);
    } catch (err) {
      console.error(err);
      setError(err?.response?.data?.message ?? "Could not fetch recipe history. Please try again.");
    } finally {
      setIsLoading(false);
    }
  };
  useEffect(() => {
    fetchHistory();
  }, [page, searchTerm, showFavoritesOnly, sortOrder, dbUserId]);
  const handleToggleFavorite = async (row) => {
  };
  const handleKeyPress = (e) => e.key === "Enter" && setPage(1) && fetchHistory();
  if (!dbUserId)
    return /* @__PURE__ */ jsxDEV(Box, { className: "history-container", display: "flex", justifyContent: "center", mt: 8, children: /* @__PURE__ */ jsxDEV(Typography, { children: "Please sign in to view your cooking history." }, void 0, false, {
      fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/pages/RecipeHistory.tsx",
      lineNumber: 121,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/pages/RecipeHistory.tsx",
      lineNumber: 120,
      columnNumber: 25
    }, this);
  if (isLoading)
    return /* @__PURE__ */ jsxDEV(Box, { className: "history-container", display: "flex", justifyContent: "center", mt: 8, children: /* @__PURE__ */ jsxDEV(CircularProgress, { color: "success" }, void 0, false, {
      fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/pages/RecipeHistory.tsx",
      lineNumber: 124,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/pages/RecipeHistory.tsx",
      lineNumber: 123,
      columnNumber: 25
    }, this);
  if (error)
    return /* @__PURE__ */ jsxDEV(Box, { className: "history-container", display: "flex", flexDirection: "column", alignItems: "center", mt: 8, children: [
      /* @__PURE__ */ jsxDEV(Typography, { color: "error", gutterBottom: true, children: error }, void 0, false, {
        fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/pages/RecipeHistory.tsx",
        lineNumber: 127,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(Button, { variant: "outlined", color: "success", onClick: fetchHistory, children: "Retry" }, void 0, false, {
        fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/pages/RecipeHistory.tsx",
        lineNumber: 130,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/pages/RecipeHistory.tsx",
      lineNumber: 126,
      columnNumber: 21
    }, this);
  if (recipes.length === 0)
    return /* @__PURE__ */ jsxDEV(Box, { className: "history-container empty", children: /* @__PURE__ */ jsxDEV(Box, { display: "flex", flexDirection: "column", alignItems: "center", gap: 2, children: [
      /* @__PURE__ */ jsxDEV(Typography, { variant: "h3", fontWeight: "bold", children: [
        /* @__PURE__ */ jsxDEV(MenuBookIcon, { sx: {
          fontSize: 45,
          mr: 1
        } }, void 0, false, {
          fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/pages/RecipeHistory.tsx",
          lineNumber: 137,
          columnNumber: 13
        }, this),
        "Cooking History"
      ] }, void 0, true, {
        fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/pages/RecipeHistory.tsx",
        lineNumber: 136,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV(Typography, { variant: "subtitle1", color: "text.secondary", children: "Your cooking journey starts here!" }, void 0, false, {
        fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/pages/RecipeHistory.tsx",
        lineNumber: 143,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV(Button, { variant: "contained", color: "success", onClick: () => navigate("/cook"), children: "Generate Your First Recipe" }, void 0, false, {
        fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/pages/RecipeHistory.tsx",
        lineNumber: 146,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/pages/RecipeHistory.tsx",
      lineNumber: 135,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/pages/RecipeHistory.tsx",
      lineNumber: 134,
      columnNumber: 36
    }, this);
  return /* @__PURE__ */ jsxDEV(Box, { className: "history-container has-content", children: [
    /* @__PURE__ */ jsxDEV("div", { className: "history-header", children: [
      /* @__PURE__ */ jsxDEV(Typography, { variant: "h3", fontWeight: "bold", gutterBottom: true, children: [
        /* @__PURE__ */ jsxDEV(MenuBookIcon, { sx: {
          fontSize: 45,
          mr: 1
        } }, void 0, false, {
          fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/pages/RecipeHistory.tsx",
          lineNumber: 157,
          columnNumber: 11
        }, this),
        "Cooking History"
      ] }, void 0, true, {
        fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/pages/RecipeHistory.tsx",
        lineNumber: 156,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(Typography, { variant: "subtitle1", color: "text.secondary", gutterBottom: true, children: "View your past recipes and track what you've cooked!" }, void 0, false, {
        fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/pages/RecipeHistory.tsx",
        lineNumber: 163,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/pages/RecipeHistory.tsx",
      lineNumber: 155,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(Box, { sx: {
      mb: 3,
      display: "flex",
      gap: 2,
      alignItems: "center"
    }, children: [
      /* @__PURE__ */ jsxDEV(TextField, { placeholder: "Search recipes...", size: "small", color: "success", value: searchTerm, onChange: (e) => setSearchTerm(e.target.value), onKeyDown: handleKeyPress, InputProps: {
        endAdornment: /* @__PURE__ */ jsxDEV(InputAdornment, { position: "end", children: /* @__PURE__ */ jsxDEV(SearchIcon, { sx: {
          color: "action.active"
        } }, void 0, false, {
          fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/pages/RecipeHistory.tsx",
          lineNumber: 177,
          columnNumber: 17
        }, this) }, void 0, false, {
          fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/pages/RecipeHistory.tsx",
          lineNumber: 176,
          columnNumber: 23
        }, this),
        style: {
          height: 36
        }
      }, sx: {
        flexGrow: 1
      } }, void 0, false, {
        fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/pages/RecipeHistory.tsx",
        lineNumber: 175,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(Button, { variant: showFavoritesOnly ? "contained" : "outlined", color: "success", startIcon: /* @__PURE__ */ jsxDEV(FavoriteIcon, {}, void 0, false, {
        fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/pages/RecipeHistory.tsx",
        lineNumber: 188,
        columnNumber: 99
      }, this), onClick: () => {
        setShowFavoritesOnly((prev) => !prev);
        setPage(1);
      }, sx: {
        height: 36,
        textTransform: "none",
        px: 2
      }, children: "Favorites" }, void 0, false, {
        fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/pages/RecipeHistory.tsx",
        lineNumber: 188,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(ToggleButtonGroup, { color: "success", value: sortOrder, exclusive: true, onChange: (_, val) => val && setSortOrder(val), "aria-label": "recipe sort order", sx: {
        height: 36,
        "& .MuiToggleButton-root": {
          textTransform: "none",
          px: 2,
          "&.Mui-selected": {
            color: "white",
            backgroundColor: "success.main",
            "&:hover": {
              backgroundColor: "success.dark"
            }
          }
        }
      }, children: [
        /* @__PURE__ */ jsxDEV(ToggleButton, { value: "newest", children: "Newest" }, void 0, false, {
          fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/pages/RecipeHistory.tsx",
          lineNumber: 213,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV(ToggleButton, { value: "oldest", children: "Oldest" }, void 0, false, {
          fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/pages/RecipeHistory.tsx",
          lineNumber: 214,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/pages/RecipeHistory.tsx",
        lineNumber: 199,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/pages/RecipeHistory.tsx",
      lineNumber: 169,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(RecipeTable, { recipes, page, rowsPerPage, onPageChange: (_, value) => setPage(value), onToggleFavorite: handleToggleFavorite }, void 0, false, {
      fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/pages/RecipeHistory.tsx",
      lineNumber: 219,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/pages/RecipeHistory.tsx",
    lineNumber: 154,
    columnNumber: 10
  }, this);
};
_s(HistoryRecipes, "YKgDfoDv4gMR07SDvE+dEzeiLJo=", false, function() {
  return [useNavigate, useUserContext];
});
_c = HistoryRecipes;
export default HistoryRecipes;
var _c;
$RefreshReg$(_c, "HistoryRecipes");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/s_mar/cs32/SnackStack/client/src/pages/RecipeHistory.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBdUpROzs7Ozs7Ozs7Ozs7Ozs7O0FBdkpSLE9BQU9BLGtCQUFrQjtBQUN6QixPQUFPQyxrQkFBa0I7QUFDekIsT0FBT0MsZ0JBQWdCO0FBQ3ZCLFNBQ0VDLEtBQ0FDLFFBQ0FDLGtCQUNBQyxnQkFDQUMsV0FDQUMsa0JBQ0s7QUFDUCxPQUFPQyxrQkFBa0I7QUFDekIsT0FBT0MsdUJBQXVCO0FBQzlCLFNBQWdCQyxXQUFXQyxnQkFBZ0I7QUFDM0MsU0FBU0MsbUJBQW1CO0FBQzVCLFNBQVNDLG1CQUFtQjtBQUM1QixPQUFPO0FBRVAsU0FBU0Msc0JBQXNCO0FBRS9CLE9BQU9DLFdBQVc7QUFFbEIsTUFBTUMsZUFBZTtBQUVyQixNQUFNQyxtQkFBbUJBLENBQUNDLFdBQ3hCQyxPQUFPQyxRQUFRRixNQUFNLEVBQ2xCRyxPQUNDLENBQUMsR0FBR0MsQ0FBQyxNQUNIQSxNQUFNQyxVQUNORCxNQUFNLElBQ1YsRUFDQ0UsSUFDQyxDQUFDLENBQUNDLEdBQUdILENBQUMsTUFBTSxHQUFHSSxtQkFBbUJELENBQUMsQ0FBQyxJQUFJQyxtQkFBbUJDLE9BQU9MLENBQUMsQ0FBQyxDQUFDLEVBQ3ZFLEVBQ0NNLEtBQUssR0FBRztBQUViLE1BQU1DLGlCQUEyQkEsTUFBTTtBQUFBQyxLQUFBO0FBQ3JDLFFBQU1DLFdBQVduQixZQUFZO0FBQzdCLFFBQU07QUFBQSxJQUFFb0I7QUFBQUEsRUFBUyxJQUFJbEIsZUFBZTtBQUNwQyxRQUFNbUIsY0FBYztBQUdwQixRQUFNLENBQUNDLFNBQVNDLFVBQVUsSUFBSXhCLFNBQW1CLEVBQUU7QUFDbkQsUUFBTSxDQUFDeUIsTUFBTUMsT0FBTyxJQUFJMUIsU0FBUyxDQUFDO0FBQ2xDLFFBQU0sQ0FBQzJCLFlBQVlDLGFBQWEsSUFBSTVCLFNBQVMsRUFBRTtBQUMvQyxRQUFNLENBQUM2QixtQkFBbUJDLG9CQUFvQixJQUFJOUIsU0FBUyxLQUFLO0FBQ2hFLFFBQU0sQ0FBQytCLFdBQVdDLFlBQVksSUFBSWhDLFNBQThCLFFBQVE7QUFHeEUsUUFBTSxDQUFDaUMsV0FBV0MsWUFBWSxJQUFJbEMsU0FBUyxLQUFLO0FBQ2hELFFBQU0sQ0FBQ21DLE9BQU9DLFFBQVEsSUFBSXBDLFNBQXdCLElBQUk7QUFNdEQsUUFBTXFDLGVBQWUsWUFBWTtBQUMvQixRQUFJLENBQUNoQjtBQUFVO0FBQ2ZhLGlCQUFhLElBQUk7QUFDakJFLGFBQVMsSUFBSTtBQUViLFFBQUk7QUFDRixZQUFNRSxLQUFLaEMsaUJBQWlCO0FBQUEsUUFDMUJpQyxTQUFTZCxPQUFPLEtBQUtIO0FBQUFBLFFBQ3JCa0IsT0FBT2xCO0FBQUFBLFFBQ1BtQixTQUFTVixjQUFjO0FBQUEsUUFDdkJXLGNBQWNiO0FBQUFBLFFBQ2RjLFNBQVNoQjtBQUFBQSxNQUNYLENBQUM7QUFFRCxZQUFNO0FBQUEsUUFBRWlCO0FBQUFBLE1BQUssSUFBSSxNQUFNeEMsTUFBTXlDLElBWTNCLEdBQUd4QyxZQUFZLFlBQVlnQixRQUFRLElBQUlpQixFQUFFLEVBQUU7QUFFN0MsWUFBTVEsU0FBbUJGLEtBQUsvQixJQUFLa0MsUUFBTztBQUFBLFFBQ3hDQyxJQUFJRCxFQUFFQztBQUFBQSxRQUNOQyxNQUFNakMsT0FBTytCLEVBQUVHLFFBQVE7QUFBQSxRQUN2QkMsWUFBWUosRUFBRUk7QUFBQUEsUUFDZEMsVUFBVTtBQUFBO0FBQUEsUUFDVkMsbUJBQW1CTixFQUFFTSxxQkFBcUI7QUFBQSxRQUMxQ0MsWUFBWTtBQUFBLFFBQ1pDLG1CQUFtQlIsRUFBRVEscUJBQXFCO0FBQUEsUUFDMUNDLGFBQWFULEVBQUVVLGNBQWM7QUFBQSxRQUM3QkMsV0FBV1gsRUFBRUM7QUFBQUEsUUFDYlcsV0FBV1osRUFBRVk7QUFBQUEsUUFDYkMsWUFBWWIsRUFBRWE7QUFBQUEsTUFDaEIsRUFBRTtBQUVGcEMsaUJBQVdzQixNQUFNO0FBQUEsSUFDbkIsU0FBU2UsS0FBVTtBQUNqQkMsY0FBUTNCLE1BQU0wQixHQUFHO0FBQ2pCekIsZUFDRXlCLEtBQUtFLFVBQVVuQixNQUFNb0IsV0FDbkIsbURBQ0o7QUFBQSxJQUNGLFVBQUM7QUFDQzlCLG1CQUFhLEtBQUs7QUFBQSxJQUNwQjtBQUFBLEVBQ0Y7QUFHQW5DLFlBQVUsTUFBTTtBQUNkc0MsaUJBQWE7QUFBQSxFQUVmLEdBQUcsQ0FBQ1osTUFBTUUsWUFBWUUsbUJBQW1CRSxXQUFXVixRQUFRLENBQUM7QUFHN0QsUUFBTTRDLHVCQUF1QixPQUFPQyxRQUFnQjtBQUFBLEVBQUM7QUFzQnJELFFBQU1DLGlCQUFpQkEsQ0FBQ0MsTUFDdEJBLEVBQUVDLFFBQVEsV0FBVzNDLFFBQVEsQ0FBQyxLQUFLVyxhQUFhO0FBR2xELE1BQUksQ0FBQ2hCO0FBQ0gsV0FDRSx1QkFBQyxPQUNDLFdBQVUscUJBQ1YsU0FBUSxRQUNSLGdCQUFlLFVBQ2YsSUFBSSxHQUVKLGlDQUFDLGNBQVcsNERBQVo7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUF3RCxLQU4xRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBT0E7QUFHSixNQUFJWTtBQUNGLFdBQ0UsdUJBQUMsT0FDQyxXQUFVLHFCQUNWLFNBQVEsUUFDUixnQkFBZSxVQUNmLElBQUksR0FFSixpQ0FBQyxvQkFBaUIsT0FBTSxhQUF4QjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQWlDLEtBTm5DO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FPQTtBQUdKLE1BQUlFO0FBQ0YsV0FDRSx1QkFBQyxPQUNDLFdBQVUscUJBQ1YsU0FBUSxRQUNSLGVBQWMsVUFDZCxZQUFXLFVBQ1gsSUFBSSxHQUVKO0FBQUEsNkJBQUMsY0FBVyxPQUFNLFNBQVEsY0FBWSxNQUNuQ0EsbUJBREg7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBO0FBQUEsTUFDQSx1QkFBQyxVQUFPLFNBQVEsWUFBVyxPQUFNLFdBQVUsU0FBU0UsY0FBYyxxQkFBbEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBO0FBQUEsU0FaRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBYUE7QUFHSixNQUFJZCxRQUFRK0MsV0FBVztBQUNyQixXQUNFLHVCQUFDLE9BQUksV0FBVSwyQkFDYixpQ0FBQyxPQUFJLFNBQVEsUUFBTyxlQUFjLFVBQVMsWUFBVyxVQUFTLEtBQUssR0FDbEU7QUFBQSw2QkFBQyxjQUFXLFNBQVEsTUFBSyxZQUFXLFFBQ2xDO0FBQUEsK0JBQUMsZ0JBQWEsSUFBSTtBQUFBLFVBQUVDLFVBQVU7QUFBQSxVQUFJQyxJQUFJO0FBQUEsUUFBRSxLQUF4QztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTBDO0FBQUEsUUFBRztBQUFBLFdBRC9DO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFHQTtBQUFBLE1BQ0EsdUJBQUMsY0FBVyxTQUFRLGFBQVksT0FBTSxrQkFBaUIsaURBQXZEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQTtBQUFBLE1BQ0EsdUJBQUMsVUFDQyxTQUFRLGFBQ1IsT0FBTSxXQUNOLFNBQVMsTUFBTXBELFNBQVMsT0FBTyxHQUNoQywwQ0FKRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBTUE7QUFBQSxTQWRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FlQSxLQWhCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBaUJBO0FBS0osU0FDRSx1QkFBQyxPQUFJLFdBQVUsaUNBQ2I7QUFBQSwyQkFBQyxTQUFJLFdBQVUsa0JBQ2I7QUFBQSw2QkFBQyxjQUFXLFNBQVEsTUFBSyxZQUFXLFFBQU8sY0FBWSxNQUNyRDtBQUFBLCtCQUFDLGdCQUFhLElBQUk7QUFBQSxVQUFFbUQsVUFBVTtBQUFBLFVBQUlDLElBQUk7QUFBQSxRQUFFLEtBQXhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBMEM7QUFBQSxRQUFHO0FBQUEsV0FEL0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUdBO0FBQUEsTUFDQSx1QkFBQyxjQUFXLFNBQVEsYUFBWSxPQUFNLGtCQUFpQixjQUFZLE1BQUMsb0VBQXBFO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQTtBQUFBLFNBUEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQVFBO0FBQUEsSUFHQSx1QkFBQyxPQUFJLElBQUk7QUFBQSxNQUFFQyxJQUFJO0FBQUEsTUFBR0MsU0FBUztBQUFBLE1BQVFDLEtBQUs7QUFBQSxNQUFHQyxZQUFZO0FBQUEsSUFBUyxHQUM5RDtBQUFBLDZCQUFDLGFBQ0MsYUFBWSxxQkFDWixNQUFLLFNBQ0wsT0FBTSxXQUNOLE9BQU9qRCxZQUNQLFVBQVd5QyxPQUFNeEMsY0FBY3dDLEVBQUVTLE9BQU9DLEtBQUssR0FDN0MsV0FBV1gsZ0JBQ1gsWUFBWTtBQUFBLFFBQ1ZZLGNBQ0UsdUJBQUMsa0JBQWUsVUFBUyxPQUN2QixpQ0FBQyxjQUFXLElBQUk7QUFBQSxVQUFFQyxPQUFPO0FBQUEsUUFBZ0IsS0FBekM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUEyQyxLQUQ3QztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQSxRQUVGQyxPQUFPO0FBQUEsVUFBRUMsUUFBUTtBQUFBLFFBQUc7QUFBQSxNQUN0QixHQUNBLElBQUk7QUFBQSxRQUFFQyxVQUFVO0FBQUEsTUFBRSxLQWZwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBZXNCO0FBQUEsTUFHdEIsdUJBQUMsVUFDQyxTQUFTdEQsb0JBQW9CLGNBQWMsWUFDM0MsT0FBTSxXQUNOLFdBQVcsdUJBQUMsa0JBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFhLEdBQ3hCLFNBQVMsTUFBTTtBQUNiQyw2QkFBc0JzRCxVQUFTLENBQUNBLElBQUk7QUFDcEMxRCxnQkFBUSxDQUFDO0FBQUEsTUFDWCxHQUNBLElBQUk7QUFBQSxRQUFFd0QsUUFBUTtBQUFBLFFBQUlHLGVBQWU7QUFBQSxRQUFRQyxJQUFJO0FBQUEsTUFBRSxHQUNoRCx5QkFURDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBV0E7QUFBQSxNQUVBLHVCQUFDLHFCQUNDLE9BQU0sV0FDTixPQUFPdkQsV0FDUCxXQUFTLE1BQ1QsVUFBVSxDQUFDd0QsR0FBR0MsUUFBUUEsT0FBT3hELGFBQWF3RCxHQUFHLEdBQzdDLGNBQVcscUJBQ1gsSUFBSTtBQUFBLFFBQ0ZOLFFBQVE7QUFBQSxRQUNSLDJCQUEyQjtBQUFBLFVBQ3pCRyxlQUFlO0FBQUEsVUFDZkMsSUFBSTtBQUFBLFVBQ0osa0JBQWtCO0FBQUEsWUFDaEJOLE9BQU87QUFBQSxZQUNQUyxpQkFBaUI7QUFBQSxZQUNqQixXQUFXO0FBQUEsY0FBRUEsaUJBQWlCO0FBQUEsWUFBZTtBQUFBLFVBQy9DO0FBQUEsUUFDRjtBQUFBLE1BQ0YsR0FFQTtBQUFBLCtCQUFDLGdCQUFhLE9BQU0sVUFBUyxzQkFBN0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFtQztBQUFBLFFBQ25DLHVCQUFDLGdCQUFhLE9BQU0sVUFBUyxzQkFBN0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFtQztBQUFBLFdBcEJyQztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBcUJBO0FBQUEsU0FyREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQXNEQTtBQUFBLElBR0EsdUJBQUMsZUFDQyxTQUNBLE1BQ0EsYUFDQSxjQUFjLENBQUNGLEdBQUdULFVBQVVwRCxRQUFRb0QsS0FBSyxHQUN6QyxrQkFBa0JiLHdCQUxwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBS3lDO0FBQUEsT0ExRTNDO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0E0RUE7QUFFSjtBQUFFOUMsR0E1UElELGdCQUF3QjtBQUFBLFVBQ1hqQixhQUNJRSxjQUFjO0FBQUE7QUFBQXVGLEtBRi9CeEU7QUE4UE4sZUFBZUE7QUFBZSxJQUFBd0U7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbIkZhdm9yaXRlSWNvbiIsIk1lbnVCb29rSWNvbiIsIlNlYXJjaEljb24iLCJCb3giLCJCdXR0b24iLCJDaXJjdWxhclByb2dyZXNzIiwiSW5wdXRBZG9ybm1lbnQiLCJUZXh0RmllbGQiLCJUeXBvZ3JhcGh5IiwiVG9nZ2xlQnV0dG9uIiwiVG9nZ2xlQnV0dG9uR3JvdXAiLCJ1c2VFZmZlY3QiLCJ1c2VTdGF0ZSIsInVzZU5hdmlnYXRlIiwiUmVjaXBlVGFibGUiLCJ1c2VVc2VyQ29udGV4dCIsImF4aW9zIiwiQVBJX0JBU0VfVVJMIiwiYnVpbGRRdWVyeVN0cmluZyIsInBhcmFtcyIsIk9iamVjdCIsImVudHJpZXMiLCJmaWx0ZXIiLCJ2IiwidW5kZWZpbmVkIiwibWFwIiwiayIsImVuY29kZVVSSUNvbXBvbmVudCIsIlN0cmluZyIsImpvaW4iLCJIaXN0b3J5UmVjaXBlcyIsIl9zIiwibmF2aWdhdGUiLCJkYlVzZXJJZCIsInJvd3NQZXJQYWdlIiwicmVjaXBlcyIsInNldFJlY2lwZXMiLCJwYWdlIiwic2V0UGFnZSIsInNlYXJjaFRlcm0iLCJzZXRTZWFyY2hUZXJtIiwic2hvd0Zhdm9yaXRlc09ubHkiLCJzZXRTaG93RmF2b3JpdGVzT25seSIsInNvcnRPcmRlciIsInNldFNvcnRPcmRlciIsImlzTG9hZGluZyIsInNldElzTG9hZGluZyIsImVycm9yIiwic2V0RXJyb3IiLCJmZXRjaEhpc3RvcnkiLCJxcyIsIm9mZnNldCIsImxpbWl0Iiwic29ydEFzYyIsImZhdm9yaXRlT25seSIsImtleXdvcmQiLCJkYXRhIiwiZ2V0IiwibWFwcGVkIiwiZCIsImlkIiwidXVpZCIsInJlY2lwZUlkIiwicmVjaXBlTmFtZSIsInNlcnZpbmdzIiwicmVjaXBlRGVzY3JpcHRpb24iLCJvcmlnaW5OYW1lIiwicmVjaXBlSW5ncmVkaWVudHMiLCJyZWNpcGVTdGVwcyIsInJlY2lwZVN0ZXAiLCJoaXN0b3J5SWQiLCJjcmVhdGVkQXQiLCJpc0Zhdm9yaXRlIiwiZXJyIiwiY29uc29sZSIsInJlc3BvbnNlIiwibWVzc2FnZSIsImhhbmRsZVRvZ2dsZUZhdm9yaXRlIiwicm93IiwiaGFuZGxlS2V5UHJlc3MiLCJlIiwia2V5IiwibGVuZ3RoIiwiZm9udFNpemUiLCJtciIsIm1iIiwiZGlzcGxheSIsImdhcCIsImFsaWduSXRlbXMiLCJ0YXJnZXQiLCJ2YWx1ZSIsImVuZEFkb3JubWVudCIsImNvbG9yIiwic3R5bGUiLCJoZWlnaHQiLCJmbGV4R3JvdyIsInByZXYiLCJ0ZXh0VHJhbnNmb3JtIiwicHgiLCJfIiwidmFsIiwiYmFja2dyb3VuZENvbG9yIiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJSZWNpcGVIaXN0b3J5LnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgRmF2b3JpdGVJY29uIGZyb20gXCJAbXVpL2ljb25zLW1hdGVyaWFsL0Zhdm9yaXRlXCI7XHJcbmltcG9ydCBNZW51Qm9va0ljb24gZnJvbSBcIkBtdWkvaWNvbnMtbWF0ZXJpYWwvTWVudUJvb2tcIjtcclxuaW1wb3J0IFNlYXJjaEljb24gZnJvbSBcIkBtdWkvaWNvbnMtbWF0ZXJpYWwvU2VhcmNoXCI7XHJcbmltcG9ydCB7XHJcbiAgQm94LFxyXG4gIEJ1dHRvbixcclxuICBDaXJjdWxhclByb2dyZXNzLFxyXG4gIElucHV0QWRvcm5tZW50LFxyXG4gIFRleHRGaWVsZCxcclxuICBUeXBvZ3JhcGh5LFxyXG59IGZyb20gXCJAbXVpL21hdGVyaWFsXCI7XHJcbmltcG9ydCBUb2dnbGVCdXR0b24gZnJvbSBcIkBtdWkvbWF0ZXJpYWwvVG9nZ2xlQnV0dG9uXCI7XHJcbmltcG9ydCBUb2dnbGVCdXR0b25Hcm91cCBmcm9tIFwiQG11aS9tYXRlcmlhbC9Ub2dnbGVCdXR0b25Hcm91cFwiO1xyXG5pbXBvcnQgUmVhY3QsIHsgdXNlRWZmZWN0LCB1c2VTdGF0ZSB9IGZyb20gXCJyZWFjdFwiO1xyXG5pbXBvcnQgeyB1c2VOYXZpZ2F0ZSB9IGZyb20gXCJyZWFjdC1yb3V0ZXItZG9tXCI7XHJcbmltcG9ydCB7IFJlY2lwZVRhYmxlIH0gZnJvbSBcIi4uL2NvbXBvbmVudHMvUmVjaXBlVGFibGVcIjtcclxuaW1wb3J0IFwiLi4vc3R5bGVzL0hpc3RvcnlSZWNpcGVzLmNzc1wiO1xyXG5pbXBvcnQgeyBJbmdyZWRpZW50LCBSZWNpcGUgfSBmcm9tIFwiLi4vdHlwZXMvcmVjaXBlXCI7XHJcbmltcG9ydCB7IHVzZVVzZXJDb250ZXh0IH0gZnJvbSBcIi4uL2NvbnRleHRzL1VzZXJDb250ZXh0XCI7XHJcblxyXG5pbXBvcnQgYXhpb3MgZnJvbSBcImF4aW9zXCI7XHJcblxyXG5jb25zdCBBUElfQkFTRV9VUkwgPSBcImh0dHA6Ly9sb2NhbGhvc3Q6ODA4MC9hcGlcIjtcclxuXHJcbmNvbnN0IGJ1aWxkUXVlcnlTdHJpbmcgPSAocGFyYW1zOiBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPikgPT5cclxuICBPYmplY3QuZW50cmllcyhwYXJhbXMpXHJcbiAgICAuZmlsdGVyKFxyXG4gICAgICAoWywgdl0pID0+XHJcbiAgICAgICAgdiAhPT0gdW5kZWZpbmVkICYmXHJcbiAgICAgICAgdiAhPT0gbnVsbFxyXG4gICAgKVxyXG4gICAgLm1hcChcclxuICAgICAgKFtrLCB2XSkgPT4gYCR7ZW5jb2RlVVJJQ29tcG9uZW50KGspfT0ke2VuY29kZVVSSUNvbXBvbmVudChTdHJpbmcodikpfWBcclxuICAgIClcclxuICAgIC5qb2luKFwiJlwiKTtcclxuXHJcbmNvbnN0IEhpc3RvcnlSZWNpcGVzOiBSZWFjdC5GQyA9ICgpID0+IHtcclxuICBjb25zdCBuYXZpZ2F0ZSA9IHVzZU5hdmlnYXRlKCk7XHJcbiAgY29uc3QgeyBkYlVzZXJJZCB9ID0gdXNlVXNlckNvbnRleHQoKTtcclxuICBjb25zdCByb3dzUGVyUGFnZSA9IDEwO1xyXG5cclxuICAvKiBVSSBzdGF0ZSAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tICovXHJcbiAgY29uc3QgW3JlY2lwZXMsIHNldFJlY2lwZXNdID0gdXNlU3RhdGU8UmVjaXBlW10+KFtdKTtcclxuICBjb25zdCBbcGFnZSwgc2V0UGFnZV0gPSB1c2VTdGF0ZSgxKTtcclxuICBjb25zdCBbc2VhcmNoVGVybSwgc2V0U2VhcmNoVGVybV0gPSB1c2VTdGF0ZShcIlwiKTtcclxuICBjb25zdCBbc2hvd0Zhdm9yaXRlc09ubHksIHNldFNob3dGYXZvcml0ZXNPbmx5XSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICBjb25zdCBbc29ydE9yZGVyLCBzZXRTb3J0T3JkZXJdID0gdXNlU3RhdGU8XCJuZXdlc3RcIiB8IFwib2xkZXN0XCI+KFwibmV3ZXN0XCIpO1xyXG5cclxuICAvKiByZXF1ZXN0IHN0YXRlIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tICovXHJcbiAgY29uc3QgW2lzTG9hZGluZywgc2V0SXNMb2FkaW5nXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICBjb25zdCBbZXJyb3IsIHNldEVycm9yXSA9IHVzZVN0YXRlPHN0cmluZyB8IG51bGw+KG51bGwpO1xyXG5cclxuICAvKiAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXHJcbiAgICogRmV0Y2ggaGVscGVyXHJcbiAgICogLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLSAqL1xyXG5cclxuICBjb25zdCBmZXRjaEhpc3RvcnkgPSBhc3luYyAoKSA9PiB7XHJcbiAgICBpZiAoIWRiVXNlcklkKSByZXR1cm47IC8vIG5vIERCIHVzZXIgeWV0XHJcbiAgICBzZXRJc0xvYWRpbmcodHJ1ZSk7XHJcbiAgICBzZXRFcnJvcihudWxsKTtcclxuXHJcbiAgICB0cnkge1xyXG4gICAgICBjb25zdCBxcyA9IGJ1aWxkUXVlcnlTdHJpbmcoe1xyXG4gICAgICAgIG9mZnNldDogKHBhZ2UgLSAxKSAqIHJvd3NQZXJQYWdlLFxyXG4gICAgICAgIGxpbWl0OiByb3dzUGVyUGFnZSxcclxuICAgICAgICBzb3J0QXNjOiBzb3J0T3JkZXIgPT09IFwib2xkZXN0XCIsXHJcbiAgICAgICAgZmF2b3JpdGVPbmx5OiBzaG93RmF2b3JpdGVzT25seSxcclxuICAgICAgICBrZXl3b3JkOiBzZWFyY2hUZXJtLFxyXG4gICAgICB9KTtcclxuXHJcbiAgICAgIGNvbnN0IHsgZGF0YSB9ID0gYXdhaXQgYXhpb3MuZ2V0PFxyXG4gICAgICAgIHtcclxuICAgICAgICAgIGlkOiBudW1iZXI7XHJcbiAgICAgICAgICB1c2VySWQ6IG51bWJlcjtcclxuICAgICAgICAgIHJlY2lwZUlkOiBudW1iZXI7XHJcbiAgICAgICAgICByZWNpcGVOYW1lOiBzdHJpbmc7XHJcbiAgICAgICAgICByZWNpcGVEZXNjcmlwdGlvbjogc3RyaW5nO1xyXG4gICAgICAgICAgY3JlYXRlZEF0OiBzdHJpbmc7XHJcbiAgICAgICAgICBpc0Zhdm9yaXRlOiBib29sZWFuO1xyXG4gICAgICAgICAgcmVjaXBlU3RlcDogc3RyaW5nW10gfCBudWxsO1xyXG4gICAgICAgICAgcmVjaXBlSW5ncmVkaWVudHM6IEluZ3JlZGllbnRbXSB8IG51bGw7XHJcbiAgICAgICAgfVtdXHJcbiAgICAgID4oYCR7QVBJX0JBU0VfVVJMfS9oaXN0b3J5LyR7ZGJVc2VySWR9PyR7cXN9YCk7XHJcblxyXG4gICAgICBjb25zdCBtYXBwZWQ6IFJlY2lwZVtdID0gZGF0YS5tYXAoKGQpID0+ICh7XHJcbiAgICAgICAgaWQ6IGQuaWQsXHJcbiAgICAgICAgdXVpZDogU3RyaW5nKGQucmVjaXBlSWQpLFxyXG4gICAgICAgIHJlY2lwZU5hbWU6IGQucmVjaXBlTmFtZSxcclxuICAgICAgICBzZXJ2aW5nczogMCwgLy8gYmFja2VuZCBkb2VzbuKAmXQgc2VuZCB0aGlzIHlldFxyXG4gICAgICAgIHJlY2lwZURlc2NyaXB0aW9uOiBkLnJlY2lwZURlc2NyaXB0aW9uID8/IFwiXCIsXHJcbiAgICAgICAgb3JpZ2luTmFtZTogXCJcIixcclxuICAgICAgICByZWNpcGVJbmdyZWRpZW50czogZC5yZWNpcGVJbmdyZWRpZW50cyA/PyBbXSxcclxuICAgICAgICByZWNpcGVTdGVwczogZC5yZWNpcGVTdGVwID8/IFtdLFxyXG4gICAgICAgIGhpc3RvcnlJZDogZC5pZCxcclxuICAgICAgICBjcmVhdGVkQXQ6IGQuY3JlYXRlZEF0LFxyXG4gICAgICAgIGlzRmF2b3JpdGU6IGQuaXNGYXZvcml0ZSxcclxuICAgICAgfSkpO1xyXG5cclxuICAgICAgc2V0UmVjaXBlcyhtYXBwZWQpO1xyXG4gICAgfSBjYXRjaCAoZXJyOiBhbnkpIHtcclxuICAgICAgY29uc29sZS5lcnJvcihlcnIpO1xyXG4gICAgICBzZXRFcnJvcihcclxuICAgICAgICBlcnI/LnJlc3BvbnNlPy5kYXRhPy5tZXNzYWdlID8/XHJcbiAgICAgICAgICBcIkNvdWxkIG5vdCBmZXRjaCByZWNpcGUgaGlzdG9yeS4gUGxlYXNlIHRyeSBhZ2Fpbi5cIlxyXG4gICAgICApO1xyXG4gICAgfSBmaW5hbGx5IHtcclxuICAgICAgc2V0SXNMb2FkaW5nKGZhbHNlKTtcclxuICAgIH1cclxuICB9O1xyXG5cclxuICAvKiBmZXRjaCBvbiBtb3VudCAvIGZpbHRlciBjaGFuZ2VzIC8gdXNlciBjaGFuZ2UgLS0tLS0tLS0tLS0tLS0tLS0tICovXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGZldGNoSGlzdG9yeSgpO1xyXG4gICAgLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIHJlYWN0LWhvb2tzL2V4aGF1c3RpdmUtZGVwc1xyXG4gIH0sIFtwYWdlLCBzZWFyY2hUZXJtLCBzaG93RmF2b3JpdGVzT25seSwgc29ydE9yZGVyLCBkYlVzZXJJZF0pO1xyXG5cclxuICAvKiBvcHRpbWlzdGljIGZhdm91cml0ZSB0b2dnbGUgLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tICovXHJcbiAgY29uc3QgaGFuZGxlVG9nZ2xlRmF2b3JpdGUgPSBhc3luYyAocm93OiBSZWNpcGUpID0+IHt9O1xyXG4gIC8vIGNvbnN0IGhhbmRsZVRvZ2dsZUZhdm9yaXRlID0gYXN5bmMgKHJvdykgPT4ge1xyXG4gIC8vICAgc2V0UmVjaXBlcygocHJldikgPT5cclxuICAvLyAgICAgcHJldi5tYXAoKHIpID0+XHJcbiAgLy8gICAgICAgci5pZCA9PT0gcm93Lmhpc3RvcnlJZCA/IHsgLi4uciwgaXNGYXZvcml0ZTogIXIuaXNGYXZvcml0ZSB9IDogclxyXG4gIC8vICAgICApXHJcbiAgLy8gICApO1xyXG5cclxuICAvLyAgIHRyeSB7XHJcbiAgLy8gICAgIGF3YWl0IGF4aW9zLnBhdGNoKGAvYXBpL2hpc3RvcnkvJHtyb3cuaGlzdG9yeUlkfS9mYXZvcml0ZWApO1xyXG4gIC8vICAgfSBjYXRjaCB7XHJcbiAgLy8gICAgIC8qIHJvbGwgYmFjayBvbiBmYWlsdXJlICovXHJcbiAgLy8gICAgIHNldFJlY2lwZXMoKHByZXYpID0+XHJcbiAgLy8gICAgICAgcHJldi5tYXAoKHIpID0+XHJcbiAgLy8gICAgICAgICByLmlkID09PSByb3cuaGlzdG9yeUlkXHJcbiAgLy8gICAgICAgICAgID8geyAuLi5yLCBpc0Zhdm9yaXRlOiAhci5pc0Zhdm9yaXRlIH1cclxuICAvLyAgICAgICAgICAgOiByXHJcbiAgLy8gICAgICAgKVxyXG4gIC8vICAgICApO1xyXG4gIC8vICAgfVxyXG4gIC8vIH07XHJcblxyXG4gIGNvbnN0IGhhbmRsZUtleVByZXNzID0gKGU6IFJlYWN0LktleWJvYXJkRXZlbnQpID0+XHJcbiAgICBlLmtleSA9PT0gXCJFbnRlclwiICYmIHNldFBhZ2UoMSkgJiYgZmV0Y2hIaXN0b3J5KCk7XHJcblxyXG4gIC8qIGxvYWRpbmcgLyBlcnJvciAvIGVtcHR5IHN0YXRlcyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0gKi9cclxuICBpZiAoIWRiVXNlcklkKVxyXG4gICAgcmV0dXJuIChcclxuICAgICAgPEJveFxyXG4gICAgICAgIGNsYXNzTmFtZT1cImhpc3RvcnktY29udGFpbmVyXCJcclxuICAgICAgICBkaXNwbGF5PVwiZmxleFwiXHJcbiAgICAgICAganVzdGlmeUNvbnRlbnQ9XCJjZW50ZXJcIlxyXG4gICAgICAgIG10PXs4fVxyXG4gICAgICA+XHJcbiAgICAgICAgPFR5cG9ncmFwaHk+UGxlYXNlIHNpZ24gaW4gdG8gdmlldyB5b3VyIGNvb2tpbmcgaGlzdG9yeS48L1R5cG9ncmFwaHk+XHJcbiAgICAgIDwvQm94PlxyXG4gICAgKTtcclxuXHJcbiAgaWYgKGlzTG9hZGluZylcclxuICAgIHJldHVybiAoXHJcbiAgICAgIDxCb3hcclxuICAgICAgICBjbGFzc05hbWU9XCJoaXN0b3J5LWNvbnRhaW5lclwiXHJcbiAgICAgICAgZGlzcGxheT1cImZsZXhcIlxyXG4gICAgICAgIGp1c3RpZnlDb250ZW50PVwiY2VudGVyXCJcclxuICAgICAgICBtdD17OH1cclxuICAgICAgPlxyXG4gICAgICAgIDxDaXJjdWxhclByb2dyZXNzIGNvbG9yPVwic3VjY2Vzc1wiIC8+XHJcbiAgICAgIDwvQm94PlxyXG4gICAgKTtcclxuXHJcbiAgaWYgKGVycm9yKVxyXG4gICAgcmV0dXJuIChcclxuICAgICAgPEJveFxyXG4gICAgICAgIGNsYXNzTmFtZT1cImhpc3RvcnktY29udGFpbmVyXCJcclxuICAgICAgICBkaXNwbGF5PVwiZmxleFwiXHJcbiAgICAgICAgZmxleERpcmVjdGlvbj1cImNvbHVtblwiXHJcbiAgICAgICAgYWxpZ25JdGVtcz1cImNlbnRlclwiXHJcbiAgICAgICAgbXQ9ezh9XHJcbiAgICAgID5cclxuICAgICAgICA8VHlwb2dyYXBoeSBjb2xvcj1cImVycm9yXCIgZ3V0dGVyQm90dG9tPlxyXG4gICAgICAgICAge2Vycm9yfVxyXG4gICAgICAgIDwvVHlwb2dyYXBoeT5cclxuICAgICAgICA8QnV0dG9uIHZhcmlhbnQ9XCJvdXRsaW5lZFwiIGNvbG9yPVwic3VjY2Vzc1wiIG9uQ2xpY2s9e2ZldGNoSGlzdG9yeX0+XHJcbiAgICAgICAgICBSZXRyeVxyXG4gICAgICAgIDwvQnV0dG9uPlxyXG4gICAgICA8L0JveD5cclxuICAgICk7XHJcblxyXG4gIGlmIChyZWNpcGVzLmxlbmd0aCA9PT0gMClcclxuICAgIHJldHVybiAoXHJcbiAgICAgIDxCb3ggY2xhc3NOYW1lPVwiaGlzdG9yeS1jb250YWluZXIgZW1wdHlcIj5cclxuICAgICAgICA8Qm94IGRpc3BsYXk9XCJmbGV4XCIgZmxleERpcmVjdGlvbj1cImNvbHVtblwiIGFsaWduSXRlbXM9XCJjZW50ZXJcIiBnYXA9ezJ9PlxyXG4gICAgICAgICAgPFR5cG9ncmFwaHkgdmFyaWFudD1cImgzXCIgZm9udFdlaWdodD1cImJvbGRcIj5cclxuICAgICAgICAgICAgPE1lbnVCb29rSWNvbiBzeD17eyBmb250U2l6ZTogNDUsIG1yOiAxIH19IC8+XHJcbiAgICAgICAgICAgIENvb2tpbmcgSGlzdG9yeVxyXG4gICAgICAgICAgPC9UeXBvZ3JhcGh5PlxyXG4gICAgICAgICAgPFR5cG9ncmFwaHkgdmFyaWFudD1cInN1YnRpdGxlMVwiIGNvbG9yPVwidGV4dC5zZWNvbmRhcnlcIj5cclxuICAgICAgICAgICAgWW91ciBjb29raW5nIGpvdXJuZXkgc3RhcnRzIGhlcmUhXHJcbiAgICAgICAgICA8L1R5cG9ncmFwaHk+XHJcbiAgICAgICAgICA8QnV0dG9uXHJcbiAgICAgICAgICAgIHZhcmlhbnQ9XCJjb250YWluZWRcIlxyXG4gICAgICAgICAgICBjb2xvcj1cInN1Y2Nlc3NcIlxyXG4gICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBuYXZpZ2F0ZShcIi9jb29rXCIpfVxyXG4gICAgICAgICAgPlxyXG4gICAgICAgICAgICBHZW5lcmF0ZSBZb3VyIEZpcnN0IFJlY2lwZVxyXG4gICAgICAgICAgPC9CdXR0b24+XHJcbiAgICAgICAgPC9Cb3g+XHJcbiAgICAgIDwvQm94PlxyXG4gICAgKTtcclxuICAvKiAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXHJcbiAgICogTWFpbiByZW5kZXJcclxuICAgKiAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tICovXHJcbiAgcmV0dXJuIChcclxuICAgIDxCb3ggY2xhc3NOYW1lPVwiaGlzdG9yeS1jb250YWluZXIgaGFzLWNvbnRlbnRcIj5cclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJoaXN0b3J5LWhlYWRlclwiPlxyXG4gICAgICAgIDxUeXBvZ3JhcGh5IHZhcmlhbnQ9XCJoM1wiIGZvbnRXZWlnaHQ9XCJib2xkXCIgZ3V0dGVyQm90dG9tPlxyXG4gICAgICAgICAgPE1lbnVCb29rSWNvbiBzeD17eyBmb250U2l6ZTogNDUsIG1yOiAxIH19IC8+XHJcbiAgICAgICAgICBDb29raW5nIEhpc3RvcnlcclxuICAgICAgICA8L1R5cG9ncmFwaHk+XHJcbiAgICAgICAgPFR5cG9ncmFwaHkgdmFyaWFudD1cInN1YnRpdGxlMVwiIGNvbG9yPVwidGV4dC5zZWNvbmRhcnlcIiBndXR0ZXJCb3R0b20+XHJcbiAgICAgICAgICBWaWV3IHlvdXIgcGFzdCByZWNpcGVzIGFuZCB0cmFjayB3aGF0IHlvdSd2ZSBjb29rZWQhXHJcbiAgICAgICAgPC9UeXBvZ3JhcGh5PlxyXG4gICAgICA8L2Rpdj5cclxuXHJcbiAgICAgIHsvKiBDb250cm9scyAqL31cclxuICAgICAgPEJveCBzeD17eyBtYjogMywgZGlzcGxheTogXCJmbGV4XCIsIGdhcDogMiwgYWxpZ25JdGVtczogXCJjZW50ZXJcIiB9fT5cclxuICAgICAgICA8VGV4dEZpZWxkXHJcbiAgICAgICAgICBwbGFjZWhvbGRlcj1cIlNlYXJjaCByZWNpcGVzLi4uXCJcclxuICAgICAgICAgIHNpemU9XCJzbWFsbFwiXHJcbiAgICAgICAgICBjb2xvcj1cInN1Y2Nlc3NcIlxyXG4gICAgICAgICAgdmFsdWU9e3NlYXJjaFRlcm19XHJcbiAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldFNlYXJjaFRlcm0oZS50YXJnZXQudmFsdWUpfVxyXG4gICAgICAgICAgb25LZXlEb3duPXtoYW5kbGVLZXlQcmVzc31cclxuICAgICAgICAgIElucHV0UHJvcHM9e3tcclxuICAgICAgICAgICAgZW5kQWRvcm5tZW50OiAoXHJcbiAgICAgICAgICAgICAgPElucHV0QWRvcm5tZW50IHBvc2l0aW9uPVwiZW5kXCI+XHJcbiAgICAgICAgICAgICAgICA8U2VhcmNoSWNvbiBzeD17eyBjb2xvcjogXCJhY3Rpb24uYWN0aXZlXCIgfX0gLz5cclxuICAgICAgICAgICAgICA8L0lucHV0QWRvcm5tZW50PlxyXG4gICAgICAgICAgICApLFxyXG4gICAgICAgICAgICBzdHlsZTogeyBoZWlnaHQ6IDM2IH0sXHJcbiAgICAgICAgICB9fVxyXG4gICAgICAgICAgc3g9e3sgZmxleEdyb3c6IDEgfX1cclxuICAgICAgICAvPlxyXG5cclxuICAgICAgICA8QnV0dG9uXHJcbiAgICAgICAgICB2YXJpYW50PXtzaG93RmF2b3JpdGVzT25seSA/IFwiY29udGFpbmVkXCIgOiBcIm91dGxpbmVkXCJ9XHJcbiAgICAgICAgICBjb2xvcj1cInN1Y2Nlc3NcIlxyXG4gICAgICAgICAgc3RhcnRJY29uPXs8RmF2b3JpdGVJY29uIC8+fVxyXG4gICAgICAgICAgb25DbGljaz17KCkgPT4ge1xyXG4gICAgICAgICAgICBzZXRTaG93RmF2b3JpdGVzT25seSgocHJldikgPT4gIXByZXYpO1xyXG4gICAgICAgICAgICBzZXRQYWdlKDEpO1xyXG4gICAgICAgICAgfX1cclxuICAgICAgICAgIHN4PXt7IGhlaWdodDogMzYsIHRleHRUcmFuc2Zvcm06IFwibm9uZVwiLCBweDogMiB9fVxyXG4gICAgICAgID5cclxuICAgICAgICAgIEZhdm9yaXRlc1xyXG4gICAgICAgIDwvQnV0dG9uPlxyXG5cclxuICAgICAgICA8VG9nZ2xlQnV0dG9uR3JvdXBcclxuICAgICAgICAgIGNvbG9yPVwic3VjY2Vzc1wiXHJcbiAgICAgICAgICB2YWx1ZT17c29ydE9yZGVyfVxyXG4gICAgICAgICAgZXhjbHVzaXZlXHJcbiAgICAgICAgICBvbkNoYW5nZT17KF8sIHZhbCkgPT4gdmFsICYmIHNldFNvcnRPcmRlcih2YWwpfVxyXG4gICAgICAgICAgYXJpYS1sYWJlbD1cInJlY2lwZSBzb3J0IG9yZGVyXCJcclxuICAgICAgICAgIHN4PXt7XHJcbiAgICAgICAgICAgIGhlaWdodDogMzYsXHJcbiAgICAgICAgICAgIFwiJiAuTXVpVG9nZ2xlQnV0dG9uLXJvb3RcIjoge1xyXG4gICAgICAgICAgICAgIHRleHRUcmFuc2Zvcm06IFwibm9uZVwiLFxyXG4gICAgICAgICAgICAgIHB4OiAyLFxyXG4gICAgICAgICAgICAgIFwiJi5NdWktc2VsZWN0ZWRcIjoge1xyXG4gICAgICAgICAgICAgICAgY29sb3I6IFwid2hpdGVcIixcclxuICAgICAgICAgICAgICAgIGJhY2tncm91bmRDb2xvcjogXCJzdWNjZXNzLm1haW5cIixcclxuICAgICAgICAgICAgICAgIFwiJjpob3ZlclwiOiB7IGJhY2tncm91bmRDb2xvcjogXCJzdWNjZXNzLmRhcmtcIiB9LFxyXG4gICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICB9fVxyXG4gICAgICAgID5cclxuICAgICAgICAgIDxUb2dnbGVCdXR0b24gdmFsdWU9XCJuZXdlc3RcIj5OZXdlc3Q8L1RvZ2dsZUJ1dHRvbj5cclxuICAgICAgICAgIDxUb2dnbGVCdXR0b24gdmFsdWU9XCJvbGRlc3RcIj5PbGRlc3Q8L1RvZ2dsZUJ1dHRvbj5cclxuICAgICAgICA8L1RvZ2dsZUJ1dHRvbkdyb3VwPlxyXG4gICAgICA8L0JveD5cclxuXHJcbiAgICAgIHsvKiBUYWJsZSAqL31cclxuICAgICAgPFJlY2lwZVRhYmxlXHJcbiAgICAgICAgcmVjaXBlcz17cmVjaXBlc31cclxuICAgICAgICBwYWdlPXtwYWdlfVxyXG4gICAgICAgIHJvd3NQZXJQYWdlPXtyb3dzUGVyUGFnZX1cclxuICAgICAgICBvblBhZ2VDaGFuZ2U9eyhfLCB2YWx1ZSkgPT4gc2V0UGFnZSh2YWx1ZSl9XHJcbiAgICAgICAgb25Ub2dnbGVGYXZvcml0ZT17aGFuZGxlVG9nZ2xlRmF2b3JpdGV9XHJcbiAgICAgIC8+XHJcbiAgICA8L0JveD5cclxuICApO1xyXG59O1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgSGlzdG9yeVJlY2lwZXM7XHJcbiJdLCJmaWxlIjoiQzovVXNlcnMvc19tYXIvY3MzMi9TbmFja1N0YWNrL2NsaWVudC9zcmMvcGFnZXMvUmVjaXBlSGlzdG9yeS50c3gifQ==