import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/App.tsx");import.meta.env = {"VITE_CLERK_PUBLISHABLE_KEY":"pk_test_YW1wbGUtZmVycmV0LTIzLmNsZXJrLmFjY291bnRzLmRldiQ","VITE_DISABLE_AUTH":"true","VITE_TEST_USERNAME":"test_user","VITE_TEST_EMAIL":"test_user@test.test","BASE_URL":"/","MODE":"development","DEV":true,"PROD":false,"SSR":false};import { jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/s_mar/cs32/SnackStack/client/src/components/App.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import { Route, BrowserRouter as Router, Routes } from "/node_modules/.vite/deps/react-router-dom.js?v=4d3a3d4b";
import Profile from "/src/components/Profile.tsx";
import InventoryManagement from "/src/pages/InventoryManagement.tsx";
import RecipeGeneration from "/src/pages/RecipeGeneration.tsx";
import "/src/styles/App.css";
import { Footer } from "/src/components/Footer.tsx";
import Home from "/src/components/Home.tsx";
import { Navbar } from "/src/components/Navbar.tsx";
import RecipesPage from "/src/pages/RecipesPage.tsx";
import HistoryRecipes from "/src/pages/RecipeHistory.tsx";
import ProtectedRoute from "/src/components/ProtectedRoute.tsx";
import { UserProvider } from "/src/contexts/UserContext.tsx";
const disableAuth = import.meta.env.VITE_DISABLE_AUTH === "true";
function App() {
  return /* @__PURE__ */ jsxDEV(Router, { children: /* @__PURE__ */ jsxDEV(UserProvider, { children: /* @__PURE__ */ jsxDEV("div", { className: "container", children: [
    /* @__PURE__ */ jsxDEV("header", { children: /* @__PURE__ */ jsxDEV(Navbar, { disableAuth }, void 0, false, {
      fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/components/App.tsx",
      lineNumber: 19,
      columnNumber: 13
    }, this) }, void 0, false, {
      fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/components/App.tsx",
      lineNumber: 18,
      columnNumber: 11
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "main-content", children: /* @__PURE__ */ jsxDEV(Routes, { children: [
      /* @__PURE__ */ jsxDEV(Route, { path: "/", element: /* @__PURE__ */ jsxDEV(Home, {}, void 0, false, {
        fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/components/App.tsx",
        lineNumber: 25,
        columnNumber: 40
      }, this) }, void 0, false, {
        fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/components/App.tsx",
        lineNumber: 25,
        columnNumber: 15
      }, this),
      !disableAuth && /* @__PURE__ */ jsxDEV(Route, { path: "/complete-profile", element: /* @__PURE__ */ jsxDEV(Profile, {}, void 0, false, {
        fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/components/App.tsx",
        lineNumber: 26,
        columnNumber: 73
      }, this) }, void 0, false, {
        fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/components/App.tsx",
        lineNumber: 26,
        columnNumber: 32
      }, this),
      /* @__PURE__ */ jsxDEV(Route, { path: "/recipes", element: disableAuth ? /* @__PURE__ */ jsxDEV(RecipesPage, {}, void 0, false, {
        fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/components/App.tsx",
        lineNumber: 29,
        columnNumber: 61
      }, this) : /* @__PURE__ */ jsxDEV(ProtectedRoute, { children: /* @__PURE__ */ jsxDEV(RecipesPage, {}, void 0, false, {
        fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/components/App.tsx",
        lineNumber: 30,
        columnNumber: 23
      }, this) }, void 0, false, {
        fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/components/App.tsx",
        lineNumber: 29,
        columnNumber: 79
      }, this) }, void 0, false, {
        fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/components/App.tsx",
        lineNumber: 29,
        columnNumber: 15
      }, this),
      /* @__PURE__ */ jsxDEV(Route, { path: "/history", element: disableAuth ? /* @__PURE__ */ jsxDEV(HistoryRecipes, {}, void 0, false, {
        fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/components/App.tsx",
        lineNumber: 33,
        columnNumber: 61
      }, this) : /* @__PURE__ */ jsxDEV(ProtectedRoute, { children: /* @__PURE__ */ jsxDEV(HistoryRecipes, {}, void 0, false, {
        fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/components/App.tsx",
        lineNumber: 34,
        columnNumber: 23
      }, this) }, void 0, false, {
        fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/components/App.tsx",
        lineNumber: 33,
        columnNumber: 82
      }, this) }, void 0, false, {
        fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/components/App.tsx",
        lineNumber: 33,
        columnNumber: 15
      }, this),
      /* @__PURE__ */ jsxDEV(Route, { path: "/inventory", element: disableAuth ? /* @__PURE__ */ jsxDEV(InventoryManagement, {}, void 0, false, {
        fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/components/App.tsx",
        lineNumber: 37,
        columnNumber: 63
      }, this) : /* @__PURE__ */ jsxDEV(ProtectedRoute, { children: /* @__PURE__ */ jsxDEV(InventoryManagement, {}, void 0, false, {
        fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/components/App.tsx",
        lineNumber: 38,
        columnNumber: 23
      }, this) }, void 0, false, {
        fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/components/App.tsx",
        lineNumber: 37,
        columnNumber: 89
      }, this) }, void 0, false, {
        fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/components/App.tsx",
        lineNumber: 37,
        columnNumber: 15
      }, this),
      /* @__PURE__ */ jsxDEV(Route, { path: "/cook", element: disableAuth ? /* @__PURE__ */ jsxDEV(RecipeGeneration, {}, void 0, false, {
        fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/components/App.tsx",
        lineNumber: 41,
        columnNumber: 58
      }, this) : /* @__PURE__ */ jsxDEV(ProtectedRoute, { children: /* @__PURE__ */ jsxDEV(RecipeGeneration, {}, void 0, false, {
        fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/components/App.tsx",
        lineNumber: 42,
        columnNumber: 23
      }, this) }, void 0, false, {
        fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/components/App.tsx",
        lineNumber: 41,
        columnNumber: 81
      }, this) }, void 0, false, {
        fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/components/App.tsx",
        lineNumber: 41,
        columnNumber: 15
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/components/App.tsx",
      lineNumber: 23,
      columnNumber: 13
    }, this) }, void 0, false, {
      fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/components/App.tsx",
      lineNumber: 22,
      columnNumber: 11
    }, this),
    /* @__PURE__ */ jsxDEV(Footer, {}, void 0, false, {
      fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/components/App.tsx",
      lineNumber: 47,
      columnNumber: 11
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/components/App.tsx",
    lineNumber: 17,
    columnNumber: 9
  }, this) }, void 0, false, {
    fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/components/App.tsx",
    lineNumber: 16,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/components/App.tsx",
    lineNumber: 15,
    columnNumber: 10
  }, this);
}
_c = App;
export default App;
var _c;
$RefreshReg$(_c, "App");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/s_mar/cs32/SnackStack/client/src/components/App.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBcUJZO0FBckJaLDJCQUFnQkE7QUFBeUJDLElBQU07QUFBUTtBQUFrQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFDekUsT0FBT0MsYUFBYTtBQUNwQixPQUFPQyx5QkFBeUI7QUFDaEMsT0FBT0Msc0JBQXNCO0FBQzdCLE9BQU87QUFDUCxTQUFTQyxjQUFjO0FBQ3ZCLE9BQU9DLFVBQVU7QUFDakIsU0FBU0MsY0FBYztBQUN2QixPQUFPQyxpQkFBaUI7QUFDeEIsT0FBT0Msb0JBQW9CO0FBQzNCLE9BQU9DLG9CQUFvQjtBQUMzQixTQUFTQyxvQkFBb0I7QUFFN0IsTUFBTUMsY0FBY0MsWUFBWUMsSUFBSUMsc0JBQXNCO0FBRTFELFNBQVNDLE1BQU07QUFDYixTQUNFLHVCQUFDLFVBQ0MsaUNBQUMsZ0JBQ0MsaUNBQUMsU0FBSSxXQUFVLGFBQ2I7QUFBQSwyQkFBQyxZQUNDLGlDQUFDLFVBQU8sZUFBUjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQWlDLEtBRG5DO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FFQTtBQUFBLElBRUEsdUJBQUMsU0FBSSxXQUFVLGdCQUNiLGlDQUFDLFVBRUM7QUFBQSw2QkFBQyxTQUFNLE1BQUssS0FBSSxTQUFTLHVCQUFDLFVBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFLLEtBQTlCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBa0M7QUFBQSxNQUNqQyxDQUFDSixlQUNBLHVCQUFDLFNBQU0sTUFBSyxxQkFBb0IsU0FBUyx1QkFBQyxhQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBUSxLQUFqRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXFEO0FBQUEsTUFJdkQsdUJBQUMsU0FDQyxNQUFLLFlBQ0wsU0FDRUEsY0FDRSx1QkFBQyxpQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQVksSUFFWix1QkFBQyxrQkFDQyxpQ0FBQyxpQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQVksS0FEZDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRUEsS0FSTjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBVUc7QUFBQSxNQUdILHVCQUFDLFNBQ0MsTUFBSyxZQUNMLFNBQ0VBLGNBQ0UsdUJBQUMsb0JBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFlLElBRWYsdUJBQUMsa0JBQ0MsaUNBQUMsb0JBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFlLEtBRGpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQSxLQVJOO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFVRztBQUFBLE1BR0gsdUJBQUMsU0FDQyxNQUFLLGNBQ0wsU0FDRUEsY0FDRSx1QkFBQyx5QkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQW9CLElBRXBCLHVCQUFDLGtCQUNDLGlDQUFDLHlCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBb0IsS0FEdEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBLEtBUk47QUFBQTtBQUFBO0FBQUE7QUFBQSxhQVVHO0FBQUEsTUFHSCx1QkFBQyxTQUNDLE1BQUssU0FDTCxTQUNFQSxjQUNFLHVCQUFDLHNCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBaUIsSUFFakIsdUJBQUMsa0JBQ0MsaUNBQUMsc0JBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFpQixLQURuQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRUEsS0FSTjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBVUc7QUFBQSxTQXpETDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBMkRBLEtBNURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0E2REE7QUFBQSxJQUVBLHVCQUFDLFlBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFPO0FBQUEsT0FwRVQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQXFFQSxLQXRFRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBdUVBLEtBeEVGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0F5RUE7QUFFSjtBQUFDSyxLQTdFUUQ7QUErRVQsZUFBZUE7QUFBSSxJQUFBQztBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsiQnJvd3NlclJvdXRlciIsIlJvdXRlcyIsIlByb2ZpbGUiLCJJbnZlbnRvcnlNYW5hZ2VtZW50IiwiUmVjaXBlR2VuZXJhdGlvbiIsIkZvb3RlciIsIkhvbWUiLCJOYXZiYXIiLCJSZWNpcGVzUGFnZSIsIkhpc3RvcnlSZWNpcGVzIiwiUHJvdGVjdGVkUm91dGUiLCJVc2VyUHJvdmlkZXIiLCJkaXNhYmxlQXV0aCIsImltcG9ydCIsImVudiIsIlZJVEVfRElTQUJMRV9BVVRIIiwiQXBwIiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJBcHAudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IFJvdXRlLCBCcm93c2VyUm91dGVyIGFzIFJvdXRlciwgUm91dGVzIH0gZnJvbSBcInJlYWN0LXJvdXRlci1kb21cIjtcclxuaW1wb3J0IFByb2ZpbGUgZnJvbSBcIi4uL2NvbXBvbmVudHMvUHJvZmlsZVwiO1xyXG5pbXBvcnQgSW52ZW50b3J5TWFuYWdlbWVudCBmcm9tIFwiLi4vcGFnZXMvSW52ZW50b3J5TWFuYWdlbWVudFwiO1xyXG5pbXBvcnQgUmVjaXBlR2VuZXJhdGlvbiBmcm9tIFwiLi4vcGFnZXMvUmVjaXBlR2VuZXJhdGlvblwiO1xyXG5pbXBvcnQgXCIuLi9zdHlsZXMvQXBwLmNzc1wiO1xyXG5pbXBvcnQgeyBGb290ZXIgfSBmcm9tIFwiLi9Gb290ZXJcIjtcclxuaW1wb3J0IEhvbWUgZnJvbSBcIi4vSG9tZVwiO1xyXG5pbXBvcnQgeyBOYXZiYXIgfSBmcm9tIFwiLi9OYXZiYXJcIjtcclxuaW1wb3J0IFJlY2lwZXNQYWdlIGZyb20gXCIuLi9wYWdlcy9SZWNpcGVzUGFnZVwiO1xyXG5pbXBvcnQgSGlzdG9yeVJlY2lwZXMgZnJvbSBcIi4uL3BhZ2VzL1JlY2lwZUhpc3RvcnlcIjtcclxuaW1wb3J0IFByb3RlY3RlZFJvdXRlIGZyb20gXCIuLi9jb21wb25lbnRzL1Byb3RlY3RlZFJvdXRlXCI7XHJcbmltcG9ydCB7IFVzZXJQcm92aWRlciB9IGZyb20gXCIuLi9jb250ZXh0cy9Vc2VyQ29udGV4dFwiO1xyXG5cclxuY29uc3QgZGlzYWJsZUF1dGggPSBpbXBvcnQubWV0YS5lbnYuVklURV9ESVNBQkxFX0FVVEggPT09IFwidHJ1ZVwiO1xyXG5cclxuZnVuY3Rpb24gQXBwKCkge1xyXG4gIHJldHVybiAoXHJcbiAgICA8Um91dGVyPlxyXG4gICAgICA8VXNlclByb3ZpZGVyPlxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY29udGFpbmVyXCI+XHJcbiAgICAgICAgICA8aGVhZGVyPlxyXG4gICAgICAgICAgICA8TmF2YmFyIGRpc2FibGVBdXRoPXtkaXNhYmxlQXV0aH0gLz5cclxuICAgICAgICAgIDwvaGVhZGVyPlxyXG5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWFpbi1jb250ZW50XCI+XHJcbiAgICAgICAgICAgIDxSb3V0ZXM+XHJcbiAgICAgICAgICAgICAgey8qIFB1YmxpYyByb3V0ZXMgKi99XHJcbiAgICAgICAgICAgICAgPFJvdXRlIHBhdGg9XCIvXCIgZWxlbWVudD17PEhvbWUgLz59IC8+XHJcbiAgICAgICAgICAgICAgeyFkaXNhYmxlQXV0aCAmJiAoXHJcbiAgICAgICAgICAgICAgICA8Um91dGUgcGF0aD1cIi9jb21wbGV0ZS1wcm9maWxlXCIgZWxlbWVudD17PFByb2ZpbGUgLz59IC8+XHJcbiAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICBcclxuICAgICAgICAgICAgICB7LyogUHJvdGVjdGVkIHJvdXRlcyAqL31cclxuICAgICAgICAgICAgICA8Um91dGVcclxuICAgICAgICAgICAgICAgIHBhdGg9XCIvcmVjaXBlc1wiXHJcbiAgICAgICAgICAgICAgICBlbGVtZW50PXtcclxuICAgICAgICAgICAgICAgICAgZGlzYWJsZUF1dGggPyAoXHJcbiAgICAgICAgICAgICAgICAgICAgPFJlY2lwZXNQYWdlIC8+XHJcbiAgICAgICAgICAgICAgICAgICkgOiAoXHJcbiAgICAgICAgICAgICAgICAgICAgPFByb3RlY3RlZFJvdXRlPlxyXG4gICAgICAgICAgICAgICAgICAgICAgPFJlY2lwZXNQYWdlIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9Qcm90ZWN0ZWRSb3V0ZT5cclxuICAgICAgICAgICAgICAgICAgKVxyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgICAgPFJvdXRlXHJcbiAgICAgICAgICAgICAgICBwYXRoPVwiL2hpc3RvcnlcIlxyXG4gICAgICAgICAgICAgICAgZWxlbWVudD17XHJcbiAgICAgICAgICAgICAgICAgIGRpc2FibGVBdXRoID8gKFxyXG4gICAgICAgICAgICAgICAgICAgIDxIaXN0b3J5UmVjaXBlcyAvPlxyXG4gICAgICAgICAgICAgICAgICApIDogKFxyXG4gICAgICAgICAgICAgICAgICAgIDxQcm90ZWN0ZWRSb3V0ZT5cclxuICAgICAgICAgICAgICAgICAgICAgIDxIaXN0b3J5UmVjaXBlcyAvPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvUHJvdGVjdGVkUm91dGU+XHJcbiAgICAgICAgICAgICAgICAgIClcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAvPlxyXG5cclxuICAgICAgICAgICAgICA8Um91dGVcclxuICAgICAgICAgICAgICAgIHBhdGg9XCIvaW52ZW50b3J5XCJcclxuICAgICAgICAgICAgICAgIGVsZW1lbnQ9e1xyXG4gICAgICAgICAgICAgICAgICBkaXNhYmxlQXV0aCA/IChcclxuICAgICAgICAgICAgICAgICAgICA8SW52ZW50b3J5TWFuYWdlbWVudCAvPlxyXG4gICAgICAgICAgICAgICAgICApIDogKFxyXG4gICAgICAgICAgICAgICAgICAgIDxQcm90ZWN0ZWRSb3V0ZT5cclxuICAgICAgICAgICAgICAgICAgICAgIDxJbnZlbnRvcnlNYW5hZ2VtZW50IC8+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9Qcm90ZWN0ZWRSb3V0ZT5cclxuICAgICAgICAgICAgICAgICAgKVxyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgIC8+XHJcblxyXG4gICAgICAgICAgICAgIDxSb3V0ZVxyXG4gICAgICAgICAgICAgICAgcGF0aD1cIi9jb29rXCJcclxuICAgICAgICAgICAgICAgIGVsZW1lbnQ9e1xyXG4gICAgICAgICAgICAgICAgICBkaXNhYmxlQXV0aCA/IChcclxuICAgICAgICAgICAgICAgICAgICA8UmVjaXBlR2VuZXJhdGlvbiAvPlxyXG4gICAgICAgICAgICAgICAgICApIDogKFxyXG4gICAgICAgICAgICAgICAgICAgIDxQcm90ZWN0ZWRSb3V0ZT5cclxuICAgICAgICAgICAgICAgICAgICAgIDxSZWNpcGVHZW5lcmF0aW9uIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9Qcm90ZWN0ZWRSb3V0ZT5cclxuICAgICAgICAgICAgICAgICAgKVxyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgIDwvUm91dGVzPlxyXG4gICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgPEZvb3RlciAvPlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICA8L1VzZXJQcm92aWRlcj5cclxuICAgIDwvUm91dGVyPlxyXG4gICk7XHJcbn1cclxuXHJcbmV4cG9ydCBkZWZhdWx0IEFwcDsiXSwiZmlsZSI6IkM6L1VzZXJzL3NfbWFyL2NzMzIvU25hY2tTdGFjay9jbGllbnQvc3JjL2NvbXBvbmVudHMvQXBwLnRzeCJ9