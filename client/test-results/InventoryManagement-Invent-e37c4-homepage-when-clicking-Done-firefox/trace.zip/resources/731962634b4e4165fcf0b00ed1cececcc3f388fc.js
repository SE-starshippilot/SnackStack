import {
  generateUtilityClass,
  generateUtilityClasses
} from "/node_modules/.vite/deps/chunk-TSMFREGN.js?v=4d3a3d4b";
import {
  require_react
} from "/node_modules/.vite/deps/chunk-K5YNGTCN.js?v=4d3a3d4b";
import {
  __toESM
} from "/node_modules/.vite/deps/chunk-ZC22LKFR.js?v=4d3a3d4b";

// node_modules/@mui/material/esm/ToggleButton/toggleButtonClasses.js
function getToggleButtonUtilityClass(slot) {
  return generateUtilityClass("MuiToggleButton", slot);
}
var toggleButtonClasses = generateUtilityClasses("MuiToggleButton", ["root", "disabled", "selected", "standard", "primary", "secondary", "sizeSmall", "sizeMedium", "sizeLarge", "fullWidth"]);
var toggleButtonClasses_default = toggleButtonClasses;

// node_modules/@mui/material/esm/ToggleButtonGroup/ToggleButtonGroupContext.js
var React = __toESM(require_react(), 1);
var ToggleButtonGroupContext = React.createContext({});
if (true) {
  ToggleButtonGroupContext.displayName = "ToggleButtonGroupContext";
}
var ToggleButtonGroupContext_default = ToggleButtonGroupContext;

// node_modules/@mui/material/esm/ToggleButtonGroup/ToggleButtonGroupButtonContext.js
var React2 = __toESM(require_react(), 1);
var ToggleButtonGroupButtonContext = React2.createContext(void 0);
if (true) {
  ToggleButtonGroupButtonContext.displayName = "ToggleButtonGroupButtonContext";
}
var ToggleButtonGroupButtonContext_default = ToggleButtonGroupButtonContext;

export {
  getToggleButtonUtilityClass,
  toggleButtonClasses_default,
  ToggleButtonGroupContext_default,
  ToggleButtonGroupButtonContext_default
};
//# sourceMappingURL=chunk-UMNCWEES.js.map
