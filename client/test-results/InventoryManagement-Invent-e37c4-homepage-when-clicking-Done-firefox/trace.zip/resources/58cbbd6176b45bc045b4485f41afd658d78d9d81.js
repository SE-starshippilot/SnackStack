import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/Navbar.tsx");import { jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/s_mar/cs32/SnackStack/client/src/components/Navbar.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import { Link, useLocation } from "/node_modules/.vite/deps/react-router-dom.js?v=4d3a3d4b";
import "/src/styles/Home.css";
import { SignedIn, SignedOut, SignInButton, SignOutButton, UserButton } from "/node_modules/.vite/deps/@clerk_clerk-react.js?v=4d3a3d4b";
const navItems = [{
  name: "Home",
  path: "/"
}, {
  name: "Cook",
  path: "/cook"
}, {
  name: "Inventory",
  path: "/inventory"
}, {
  name: "History",
  path: "/history"
}];
export const Navbar = ({
  disableAuth
}) => {
  _s();
  const location = useLocation();
  return /* @__PURE__ */ jsxDEV("nav", { className: "navbar", children: /* @__PURE__ */ jsxDEV("div", { className: "navbar-content", children: [
    /* @__PURE__ */ jsxDEV("div", { className: "logo", children: "Snack Stack" }, void 0, false, {
      fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/components/Navbar.tsx",
      lineNumber: 28,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "links-wrapper", children: /* @__PURE__ */ jsxDEV("div", { className: "nav-links", children: [
      navItems.map((item) => /* @__PURE__ */ jsxDEV(Link, { to: item.path, className: `nav-link ${location.pathname === item.path ? "active" : ""}`, children: item.name }, item.path, false, {
        fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/components/Navbar.tsx",
        lineNumber: 32,
        columnNumber: 35
      }, this)),
      !disableAuth && /* @__PURE__ */ jsxDEV("div", { className: "auth-controls", children: [
        /* @__PURE__ */ jsxDEV(SignedOut, { children: /* @__PURE__ */ jsxDEV(SignInButton, { mode: "modal", children: /* @__PURE__ */ jsxDEV("button", { className: "auth-button", children: "Sign In" }, void 0, false, {
          fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/components/Navbar.tsx",
          lineNumber: 38,
          columnNumber: 21
        }, this) }, void 0, false, {
          fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/components/Navbar.tsx",
          lineNumber: 37,
          columnNumber: 19
        }, this) }, void 0, false, {
          fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/components/Navbar.tsx",
          lineNumber: 36,
          columnNumber: 17
        }, this),
        /* @__PURE__ */ jsxDEV(SignedIn, { children: [
          /* @__PURE__ */ jsxDEV(UserButton, {}, void 0, false, {
            fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/components/Navbar.tsx",
            lineNumber: 43,
            columnNumber: 19
          }, this),
          " ",
          /* @__PURE__ */ jsxDEV(SignOutButton, { children: /* @__PURE__ */ jsxDEV("button", { className: "auth-button", children: "Sign Out" }, void 0, false, {
            fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/components/Navbar.tsx",
            lineNumber: 45,
            columnNumber: 21
          }, this) }, void 0, false, {
            fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/components/Navbar.tsx",
            lineNumber: 44,
            columnNumber: 19
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/components/Navbar.tsx",
          lineNumber: 42,
          columnNumber: 17
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/components/Navbar.tsx",
        lineNumber: 35,
        columnNumber: 30
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/components/Navbar.tsx",
      lineNumber: 31,
      columnNumber: 11
    }, this) }, void 0, false, {
      fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/components/Navbar.tsx",
      lineNumber: 30,
      columnNumber: 9
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/components/Navbar.tsx",
    lineNumber: 27,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/components/Navbar.tsx",
    lineNumber: 26,
    columnNumber: 10
  }, this);
};
_s(Navbar, "pkHmaVRPskBaU4tMJuJJpV42k1I=", false, function() {
  return [useLocation];
});
_c = Navbar;
var _c;
$RefreshReg$(_c, "Navbar");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/s_mar/cs32/SnackStack/client/src/components/Navbar.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBNEJROzs7Ozs7Ozs7Ozs7Ozs7O0FBNUJSLFNBQVNBLE1BQU1DLG1CQUFtQjtBQUNsQyxPQUFPO0FBRVAsU0FDRUMsVUFDQUMsV0FDQUMsY0FDQUMsZUFDQUMsa0JBQ0s7QUFFUCxNQUFNQyxXQUFXLENBQ2Y7QUFBQSxFQUFFQyxNQUFNO0FBQUEsRUFBUUMsTUFBTTtBQUFJLEdBQzFCO0FBQUEsRUFBRUQsTUFBTTtBQUFBLEVBQVFDLE1BQU07QUFBUSxHQUM5QjtBQUFBLEVBQUVELE1BQU07QUFBQSxFQUFhQyxNQUFNO0FBQWEsR0FDeEM7QUFBQSxFQUFFRCxNQUFNO0FBQUEsRUFBV0MsTUFBTTtBQUFXLENBQUM7QUFPaEMsYUFBTUMsU0FBU0EsQ0FBQztBQUFBLEVBQUVDO0FBQXlCLE1BQU07QUFBQUMsS0FBQTtBQUN0RCxRQUFNQyxXQUFXWixZQUFZO0FBRTdCLFNBQ0UsdUJBQUMsU0FBSSxXQUFVLFVBQ2IsaUNBQUMsU0FBSSxXQUFVLGtCQUNiO0FBQUEsMkJBQUMsU0FBSSxXQUFVLFFBQU8sMkJBQXRCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBaUM7QUFBQSxJQUVqQyx1QkFBQyxTQUFJLFdBQVUsaUJBQ2IsaUNBQUMsU0FBSSxXQUFVLGFBQ1pNO0FBQUFBLGVBQVNPLElBQUtDLFVBQ2IsdUJBQUMsUUFFQyxJQUFJQSxLQUFLTixNQUNULFdBQVcsWUFDVEksU0FBU0csYUFBYUQsS0FBS04sT0FBTyxXQUFXLEVBQUUsSUFHaERNLGVBQUtQLFFBTkRPLEtBQUtOLE1BRFo7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQVFBLENBQ0Q7QUFBQSxNQUNBLENBQUNFLGVBQ0EsdUJBQUMsU0FBSSxXQUFVLGlCQUNiO0FBQUEsK0JBQUMsYUFDQyxpQ0FBQyxnQkFBYSxNQUFLLFNBQ2pCLGlDQUFDLFlBQU8sV0FBVSxlQUFjLHVCQUFoQztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXVDLEtBRHpDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQSxLQUhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFJQTtBQUFBLFFBRUEsdUJBQUMsWUFDQztBQUFBLGlDQUFDLGdCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQVc7QUFBQSxVQUFJO0FBQUEsVUFDZix1QkFBQyxpQkFDQyxpQ0FBQyxZQUFPLFdBQVUsZUFBYyx3QkFBaEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBd0MsS0FEMUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLGFBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUtBO0FBQUEsV0FaRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBYUE7QUFBQSxTQTFCSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBNEJBLEtBN0JGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0E4QkE7QUFBQSxPQWpDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBa0NBLEtBbkNGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FvQ0E7QUFFSjtBQUFFQyxHQTFDV0YsUUFBTTtBQUFBLFVBQ0FULFdBQVc7QUFBQTtBQUFBZ0IsS0FEakJQO0FBQU0sSUFBQU87QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbIkxpbmsiLCJ1c2VMb2NhdGlvbiIsIlNpZ25lZEluIiwiU2lnbmVkT3V0IiwiU2lnbkluQnV0dG9uIiwiU2lnbk91dEJ1dHRvbiIsIlVzZXJCdXR0b24iLCJuYXZJdGVtcyIsIm5hbWUiLCJwYXRoIiwiTmF2YmFyIiwiZGlzYWJsZUF1dGgiLCJfcyIsImxvY2F0aW9uIiwibWFwIiwiaXRlbSIsInBhdGhuYW1lIiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJOYXZiYXIudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IExpbmssIHVzZUxvY2F0aW9uIH0gZnJvbSBcInJlYWN0LXJvdXRlci1kb21cIjtcclxuaW1wb3J0IFwiLi4vc3R5bGVzL0hvbWUuY3NzXCI7XHJcblxyXG5pbXBvcnQge1xyXG4gIFNpZ25lZEluLFxyXG4gIFNpZ25lZE91dCxcclxuICBTaWduSW5CdXR0b24sXHJcbiAgU2lnbk91dEJ1dHRvbixcclxuICBVc2VyQnV0dG9uLFxyXG59IGZyb20gXCJAY2xlcmsvY2xlcmstcmVhY3RcIjtcclxuXHJcbmNvbnN0IG5hdkl0ZW1zID0gW1xyXG4gIHsgbmFtZTogXCJIb21lXCIsIHBhdGg6IFwiL1wiIH0sXHJcbiAgeyBuYW1lOiBcIkNvb2tcIiwgcGF0aDogXCIvY29va1wiIH0sXHJcbiAgeyBuYW1lOiBcIkludmVudG9yeVwiLCBwYXRoOiBcIi9pbnZlbnRvcnlcIiB9LFxyXG4gIHsgbmFtZTogXCJIaXN0b3J5XCIsIHBhdGg6IFwiL2hpc3RvcnlcIiB9LFxyXG5dO1xyXG5cclxuaW50ZXJmYWNlIE5hdmJhclByb3BzIHtcclxuICBkaXNhYmxlQXV0aDogYm9vbGVhbjtcclxufVxyXG5cclxuZXhwb3J0IGNvbnN0IE5hdmJhciA9ICh7IGRpc2FibGVBdXRoIH06IE5hdmJhclByb3BzKSA9PiB7XHJcbiAgY29uc3QgbG9jYXRpb24gPSB1c2VMb2NhdGlvbigpO1xyXG5cclxuICByZXR1cm4gKFxyXG4gICAgPG5hdiBjbGFzc05hbWU9XCJuYXZiYXJcIj5cclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJuYXZiYXItY29udGVudFwiPlxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibG9nb1wiPlNuYWNrIFN0YWNrPC9kaXY+XHJcblxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibGlua3Mtd3JhcHBlclwiPlxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJuYXYtbGlua3NcIj5cclxuICAgICAgICAgICAge25hdkl0ZW1zLm1hcCgoaXRlbSkgPT4gKFxyXG4gICAgICAgICAgICAgIDxMaW5rXHJcbiAgICAgICAgICAgICAgICBrZXk9e2l0ZW0ucGF0aH1cclxuICAgICAgICAgICAgICAgIHRvPXtpdGVtLnBhdGh9XHJcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BuYXYtbGluayAke1xyXG4gICAgICAgICAgICAgICAgICBsb2NhdGlvbi5wYXRobmFtZSA9PT0gaXRlbS5wYXRoID8gXCJhY3RpdmVcIiA6IFwiXCJcclxuICAgICAgICAgICAgICAgIH1gfVxyXG4gICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgIHtpdGVtLm5hbWV9XHJcbiAgICAgICAgICAgICAgPC9MaW5rPlxyXG4gICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgeyFkaXNhYmxlQXV0aCAmJiAoXHJcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJhdXRoLWNvbnRyb2xzXCI+XHJcbiAgICAgICAgICAgICAgICA8U2lnbmVkT3V0PlxyXG4gICAgICAgICAgICAgICAgICA8U2lnbkluQnV0dG9uIG1vZGU9XCJtb2RhbFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxidXR0b24gY2xhc3NOYW1lPVwiYXV0aC1idXR0b25cIj5TaWduIEluPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgICAgIDwvU2lnbkluQnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgPC9TaWduZWRPdXQ+XHJcblxyXG4gICAgICAgICAgICAgICAgPFNpZ25lZEluPlxyXG4gICAgICAgICAgICAgICAgICA8VXNlckJ1dHRvbiAvPntcIiBcIn1cclxuICAgICAgICAgICAgICAgICAgPFNpZ25PdXRCdXR0b24+XHJcbiAgICAgICAgICAgICAgICAgICAgPGJ1dHRvbiBjbGFzc05hbWU9XCJhdXRoLWJ1dHRvblwiPlNpZ24gT3V0PC9idXR0b24+XHJcbiAgICAgICAgICAgICAgICAgIDwvU2lnbk91dEJ1dHRvbj5cclxuICAgICAgICAgICAgICAgIDwvU2lnbmVkSW4+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICl9XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgPC9kaXY+XHJcbiAgICA8L25hdj5cclxuICApO1xyXG59O1xyXG4iXSwiZmlsZSI6IkM6L1VzZXJzL3NfbWFyL2NzMzIvU25hY2tTdGFjay9jbGllbnQvc3JjL2NvbXBvbmVudHMvTmF2YmFyLnRzeCJ9