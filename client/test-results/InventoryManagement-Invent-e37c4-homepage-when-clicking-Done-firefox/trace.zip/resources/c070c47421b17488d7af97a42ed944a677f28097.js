import { styled } from "/node_modules/.vite/deps/@mui_material_styles.js?v=4d3a3d4b";
import TableCell, { tableCellClasses } from "/node_modules/.vite/deps/@mui_material_TableCell.js?v=4d3a3d4b";
import TableRow from "/node_modules/.vite/deps/@mui_material_TableRow.js?v=4d3a3d4b";
import Pagination from "/node_modules/.vite/deps/@mui_material_Pagination.js?v=4d3a3d4b";
import { green } from "/node_modules/.vite/deps/@mui_material_colors.js?v=4d3a3d4b";
export const StyledTableCell = styled(TableCell)(({
  theme
}) => ({
  [`&.${tableCellClasses.head}`]: {
    backgroundColor: green[700],
    color: "#f0f4c3",
    fontSize: 16,
    fontWeight: 500,
    fontFamily: "inherit"
  },
  [`&.${tableCellClasses.body}`]: {
    fontSize: 14,
    fontFamily: "inherit",
    color: green[900]
  }
}));
export const StyledTableRow = styled(TableRow)(({
  theme
}) => ({
  "&:nth-of-type(odd)": {
    backgroundColor: green[50]
  },
  "&:nth-of-type(even)": {
    backgroundColor: "white"
  },
  "&:last-child td, &:last-child th": {
    border: 0
  },
  "& .MuiTableCell-root": {
    fontFamily: "inherit"
  },
  cursor: "pointer",
  "&:hover": {
    backgroundColor: `${green[100]} !important`
  }
}));
export const StyledPagination = styled(Pagination)(({
  theme
}) => ({
  "& .MuiPaginationItem-root": {
    "&.Mui-selected": {
      backgroundColor: green[500],
      color: theme.palette.common.white,
      "&:hover": {
        backgroundColor: green[600]
      }
    }
  }
}));

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBQUEsU0FBU0EsY0FBYztBQUN2QixPQUFPQyxhQUFhQyx3QkFBd0I7QUFDNUMsT0FBT0MsY0FBYztBQUNyQixPQUFPQyxnQkFBZ0I7QUFDdkIsU0FBU0MsYUFBYTtBQUVmLGFBQU1DLGtCQUFrQk4sT0FBT0MsU0FBUyxFQUFFLENBQUM7QUFBQSxFQUFFTTtBQUFNLE9BQU87QUFBQSxFQUMvRCxDQUFDLEtBQUtMLGlCQUFpQk0sSUFBSSxFQUFFLEdBQUc7QUFBQSxJQUM5QkMsaUJBQWlCSixNQUFNLEdBQUc7QUFBQSxJQUMxQkssT0FBTztBQUFBLElBQ1BDLFVBQVU7QUFBQSxJQUNWQyxZQUFZO0FBQUEsSUFDWkMsWUFBWTtBQUFBLEVBQ2Q7QUFBQSxFQUNBLENBQUMsS0FBS1gsaUJBQWlCWSxJQUFJLEVBQUUsR0FBRztBQUFBLElBQzlCSCxVQUFVO0FBQUEsSUFDVkUsWUFBWTtBQUFBLElBQ1pILE9BQU9MLE1BQU0sR0FBRztBQUFBLEVBQ2xCO0FBQ0YsRUFBRTtBQUVLLGFBQU1VLGlCQUFpQmYsT0FBT0csUUFBUSxFQUFFLENBQUM7QUFBQSxFQUFFSTtBQUFNLE9BQU87QUFBQSxFQUM3RCxzQkFBc0I7QUFBQSxJQUNwQkUsaUJBQWlCSixNQUFNLEVBQUU7QUFBQSxFQUMzQjtBQUFBLEVBQ0EsdUJBQXVCO0FBQUEsSUFDckJJLGlCQUFpQjtBQUFBLEVBQ25CO0FBQUEsRUFDQSxvQ0FBb0M7QUFBQSxJQUNsQ08sUUFBUTtBQUFBLEVBQ1Y7QUFBQSxFQUNBLHdCQUF3QjtBQUFBLElBQ3RCSCxZQUFZO0FBQUEsRUFDZDtBQUFBLEVBQ0FJLFFBQVE7QUFBQSxFQUNSLFdBQVc7QUFBQSxJQUNUUixpQkFBaUIsR0FBR0osTUFBTSxHQUFHLENBQUM7QUFBQSxFQUNoQztBQUNGLEVBQUU7QUFFSyxhQUFNYSxtQkFBbUJsQixPQUFPSSxVQUFVLEVBQUUsQ0FBQztBQUFBLEVBQUVHO0FBQU0sT0FBTztBQUFBLEVBQ2pFLDZCQUE2QjtBQUFBLElBQzNCLGtCQUFrQjtBQUFBLE1BQ2hCRSxpQkFBaUJKLE1BQU0sR0FBRztBQUFBLE1BQzFCSyxPQUFPSCxNQUFNWSxRQUFRQyxPQUFPQztBQUFBQSxNQUM1QixXQUFXO0FBQUEsUUFDVFosaUJBQWlCSixNQUFNLEdBQUc7QUFBQSxNQUM1QjtBQUFBLElBQ0Y7QUFBQSxFQUNGO0FBQ0YsRUFBRSIsIm5hbWVzIjpbInN0eWxlZCIsIlRhYmxlQ2VsbCIsInRhYmxlQ2VsbENsYXNzZXMiLCJUYWJsZVJvdyIsIlBhZ2luYXRpb24iLCJncmVlbiIsIlN0eWxlZFRhYmxlQ2VsbCIsInRoZW1lIiwiaGVhZCIsImJhY2tncm91bmRDb2xvciIsImNvbG9yIiwiZm9udFNpemUiLCJmb250V2VpZ2h0IiwiZm9udEZhbWlseSIsImJvZHkiLCJTdHlsZWRUYWJsZVJvdyIsImJvcmRlciIsImN1cnNvciIsIlN0eWxlZFBhZ2luYXRpb24iLCJwYWxldHRlIiwiY29tbW9uIiwid2hpdGUiXSwic291cmNlcyI6WyJSZWNpcGVUYWJsZVN0eWxlcy50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgc3R5bGVkIH0gZnJvbSBcIkBtdWkvbWF0ZXJpYWwvc3R5bGVzXCI7XHJcbmltcG9ydCBUYWJsZUNlbGwsIHsgdGFibGVDZWxsQ2xhc3NlcyB9IGZyb20gXCJAbXVpL21hdGVyaWFsL1RhYmxlQ2VsbFwiO1xyXG5pbXBvcnQgVGFibGVSb3cgZnJvbSBcIkBtdWkvbWF0ZXJpYWwvVGFibGVSb3dcIjtcclxuaW1wb3J0IFBhZ2luYXRpb24gZnJvbSBcIkBtdWkvbWF0ZXJpYWwvUGFnaW5hdGlvblwiO1xyXG5pbXBvcnQgeyBncmVlbiB9IGZyb20gXCJAbXVpL21hdGVyaWFsL2NvbG9yc1wiO1xyXG5cclxuZXhwb3J0IGNvbnN0IFN0eWxlZFRhYmxlQ2VsbCA9IHN0eWxlZChUYWJsZUNlbGwpKCh7IHRoZW1lIH0pID0+ICh7XHJcbiAgW2AmLiR7dGFibGVDZWxsQ2xhc3Nlcy5oZWFkfWBdOiB7XHJcbiAgICBiYWNrZ3JvdW5kQ29sb3I6IGdyZWVuWzcwMF0sXHJcbiAgICBjb2xvcjogXCIjZjBmNGMzXCIsXHJcbiAgICBmb250U2l6ZTogMTYsXHJcbiAgICBmb250V2VpZ2h0OiA1MDAsXHJcbiAgICBmb250RmFtaWx5OiBcImluaGVyaXRcIixcclxuICB9LFxyXG4gIFtgJi4ke3RhYmxlQ2VsbENsYXNzZXMuYm9keX1gXToge1xyXG4gICAgZm9udFNpemU6IDE0LFxyXG4gICAgZm9udEZhbWlseTogXCJpbmhlcml0XCIsXHJcbiAgICBjb2xvcjogZ3JlZW5bOTAwXSxcclxuICB9LFxyXG59KSk7XHJcblxyXG5leHBvcnQgY29uc3QgU3R5bGVkVGFibGVSb3cgPSBzdHlsZWQoVGFibGVSb3cpKCh7IHRoZW1lIH0pID0+ICh7XHJcbiAgXCImOm50aC1vZi10eXBlKG9kZClcIjoge1xyXG4gICAgYmFja2dyb3VuZENvbG9yOiBncmVlbls1MF0sXHJcbiAgfSxcclxuICBcIiY6bnRoLW9mLXR5cGUoZXZlbilcIjoge1xyXG4gICAgYmFja2dyb3VuZENvbG9yOiBcIndoaXRlXCIsXHJcbiAgfSxcclxuICBcIiY6bGFzdC1jaGlsZCB0ZCwgJjpsYXN0LWNoaWxkIHRoXCI6IHtcclxuICAgIGJvcmRlcjogMCxcclxuICB9LFxyXG4gIFwiJiAuTXVpVGFibGVDZWxsLXJvb3RcIjoge1xyXG4gICAgZm9udEZhbWlseTogXCJpbmhlcml0XCIsXHJcbiAgfSxcclxuICBjdXJzb3I6IFwicG9pbnRlclwiLFxyXG4gIFwiJjpob3ZlclwiOiB7XHJcbiAgICBiYWNrZ3JvdW5kQ29sb3I6IGAke2dyZWVuWzEwMF19ICFpbXBvcnRhbnRgLFxyXG4gIH0sXHJcbn0pKTtcclxuXHJcbmV4cG9ydCBjb25zdCBTdHlsZWRQYWdpbmF0aW9uID0gc3R5bGVkKFBhZ2luYXRpb24pKCh7IHRoZW1lIH0pID0+ICh7XHJcbiAgXCImIC5NdWlQYWdpbmF0aW9uSXRlbS1yb290XCI6IHtcclxuICAgIFwiJi5NdWktc2VsZWN0ZWRcIjoge1xyXG4gICAgICBiYWNrZ3JvdW5kQ29sb3I6IGdyZWVuWzUwMF0sXHJcbiAgICAgIGNvbG9yOiB0aGVtZS5wYWxldHRlLmNvbW1vbi53aGl0ZSxcclxuICAgICAgXCImOmhvdmVyXCI6IHtcclxuICAgICAgICBiYWNrZ3JvdW5kQ29sb3I6IGdyZWVuWzYwMF0sXHJcbiAgICAgIH0sXHJcbiAgICB9LFxyXG4gIH0sXHJcbn0pKTtcclxuIl0sImZpbGUiOiJDOi9Vc2Vycy9zX21hci9jczMyL1NuYWNrU3RhY2svY2xpZW50L3NyYy9zdHlsZXMvUmVjaXBlVGFibGVTdHlsZXMudHN4In0=