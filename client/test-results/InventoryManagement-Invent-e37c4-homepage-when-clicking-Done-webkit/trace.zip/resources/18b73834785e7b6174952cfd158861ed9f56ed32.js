import {
  amber_default,
  blueGrey_default,
  brown_default,
  cyan_default,
  deepOrange_default,
  deepPurple_default,
  indigo_default,
  lightGreen_default,
  lime_default,
  pink_default,
  teal_default,
  yellow_default
} from "/node_modules/.vite/deps/chunk-B3FWSR2K.js?v=4d3a3d4b";
import {
  blue_default,
  common_default,
  green_default,
  grey_default,
  lightBlue_default,
  orange_default,
  purple_default,
  red_default
} from "/node_modules/.vite/deps/chunk-64FVIM6J.js?v=4d3a3d4b";
import "/node_modules/.vite/deps/chunk-ZC22LKFR.js?v=4d3a3d4b";
export {
  amber_default as amber,
  blue_default as blue,
  blueGrey_default as blueGrey,
  brown_default as brown,
  common_default as common,
  cyan_default as cyan,
  deepOrange_default as deepOrange,
  deepPurple_default as deepPurple,
  green_default as green,
  grey_default as grey,
  indigo_default as indigo,
  lightBlue_default as lightBlue,
  lightGreen_default as lightGreen,
  lime_default as lime,
  orange_default as orange,
  pink_default as pink,
  purple_default as purple,
  red_default as red,
  teal_default as teal,
  yellow_default as yellow
};
//# sourceMappingURL=@mui_material_colors.js.map
