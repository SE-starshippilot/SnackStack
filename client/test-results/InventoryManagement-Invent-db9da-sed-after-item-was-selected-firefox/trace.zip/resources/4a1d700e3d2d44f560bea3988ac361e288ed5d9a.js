import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/RecipeTable.tsx");import { jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/s_mar/cs32/SnackStack/client/src/components/RecipeTable.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import { TableContainer, Table, TableHead, TableBody, TableRow, Paper, Box, Stack } from "/node_modules/.vite/deps/@mui_material.js?v=4d3a3d4b";
import RestaurantMenuIcon from "/node_modules/.vite/deps/@mui_icons-material_RestaurantMenu.js?v=4d3a3d4b";
import EventIcon from "/node_modules/.vite/deps/@mui_icons-material_Event.js?v=4d3a3d4b";
import DescriptionIcon from "/node_modules/.vite/deps/@mui_icons-material_Description.js?v=4d3a3d4b";
import RestaurantIcon from "/node_modules/.vite/deps/@mui_icons-material_Restaurant.js?v=4d3a3d4b";
import { RecipeTableRow } from "/src/components/RecipeTableRow/RecipeTableRow.tsx";
import { StyledTableCell, StyledPagination } from "/src/styles/RecipeTableStyles.tsx";
const columns = [{
  id: "expand",
  label: "",
  minWidth: 50
}, {
  id: "recipeName",
  label: "Recipe Name",
  minWidth: 170,
  icon: /* @__PURE__ */ jsxDEV(RestaurantMenuIcon, { sx: {
    fontSize: 20
  } }, void 0, false, {
    fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/components/RecipeTable.tsx",
    lineNumber: 18,
    columnNumber: 9
  }, this)
}, {
  id: "date",
  label: "Generated On",
  minWidth: 160,
  icon: /* @__PURE__ */ jsxDEV(EventIcon, { sx: {
    fontSize: 20
  } }, void 0, false, {
    fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/components/RecipeTable.tsx",
    lineNumber: 25,
    columnNumber: 9
  }, this)
}, {
  id: "description",
  label: "Description",
  minWidth: 200,
  icon: /* @__PURE__ */ jsxDEV(DescriptionIcon, { sx: {
    fontSize: 20
  } }, void 0, false, {
    fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/components/RecipeTable.tsx",
    lineNumber: 32,
    columnNumber: 9
  }, this)
}, {
  id: "ingredients",
  label: "Ingredients Used",
  minWidth: 200,
  icon: /* @__PURE__ */ jsxDEV(RestaurantIcon, { sx: {
    fontSize: 20
  } }, void 0, false, {
    fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/components/RecipeTable.tsx",
    lineNumber: 39,
    columnNumber: 9
  }, this)
}, {
  id: "favorite",
  label: "",
  minWidth: 50
}];
export const RecipeTable = ({
  recipes,
  page,
  rowsPerPage,
  onPageChange,
  onToggleFavorite
}) => {
  const pageCount = Math.ceil(recipes.length / rowsPerPage);
  return /* @__PURE__ */ jsxDEV("div", { className: "history-table-container", children: [
    /* @__PURE__ */ jsxDEV(TableContainer, { component: Paper, children: /* @__PURE__ */ jsxDEV(Table, { stickyHeader: true, "aria-label": "cooking history table", children: [
      /* @__PURE__ */ jsxDEV(TableHead, { children: /* @__PURE__ */ jsxDEV(TableRow, { children: columns.map((column) => /* @__PURE__ */ jsxDEV(StyledTableCell, { style: {
        minWidth: column.minWidth
      }, children: column.id === "expand" ? null : /* @__PURE__ */ jsxDEV(Box, { sx: {
        display: "flex",
        alignItems: "center",
        gap: 0.5
      }, children: [
        column.icon,
        column.label
      ] }, void 0, true, {
        fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/components/RecipeTable.tsx",
        lineNumber: 70,
        columnNumber: 52
      }, this) }, column.id, false, {
        fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/components/RecipeTable.tsx",
        lineNumber: 67,
        columnNumber: 38
      }, this)) }, void 0, false, {
        fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/components/RecipeTable.tsx",
        lineNumber: 66,
        columnNumber: 13
      }, this) }, void 0, false, {
        fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/components/RecipeTable.tsx",
        lineNumber: 65,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV(TableBody, { children: recipes.map((row) => /* @__PURE__ */ jsxDEV(RecipeTableRow, { row, onToggleFavorite }, row.id, false, {
        fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/components/RecipeTable.tsx",
        lineNumber: 82,
        columnNumber: 33
      }, this)) }, void 0, false, {
        fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/components/RecipeTable.tsx",
        lineNumber: 81,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/components/RecipeTable.tsx",
      lineNumber: 64,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/components/RecipeTable.tsx",
      lineNumber: 63,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(Stack, { spacing: 2, sx: {
      mt: 2,
      display: "flex",
      alignItems: "flex-end",
      justifyContent: "flex-end"
    }, children: /* @__PURE__ */ jsxDEV(StyledPagination, { count: pageCount, page, onChange: onPageChange, showFirstButton: true, showLastButton: true }, void 0, false, {
      fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/components/RecipeTable.tsx",
      lineNumber: 92,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/components/RecipeTable.tsx",
      lineNumber: 86,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/components/RecipeTable.tsx",
    lineNumber: 62,
    columnNumber: 10
  }, this);
};
_c = RecipeTable;
var _c;
$RefreshReg$(_c, "RecipeTable");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/s_mar/cs32/SnackStack/client/src/components/RecipeTable.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBNkJVO0FBN0JWLE9BQU9BLG9CQUFrQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQ3pCLFNBQ0VDLGdCQUNBQyxPQUNBQyxXQUNBQyxXQUNBQyxVQUNBQyxPQUNBQyxLQUNBQyxhQUNLO0FBQ1AsT0FBT0Msd0JBQXdCO0FBQy9CLE9BQU9DLGVBQWU7QUFDdEIsT0FBT0MscUJBQXFCO0FBQzVCLE9BQU9DLG9CQUFvQjtBQUUzQixTQUFTQyxzQkFBc0I7QUFDL0IsU0FBU0MsaUJBQWlCQyx3QkFBd0I7QUFFbEQsTUFBTUMsVUFBVSxDQUNkO0FBQUEsRUFDRUMsSUFBSTtBQUFBLEVBQ0pDLE9BQU87QUFBQSxFQUNQQyxVQUFVO0FBQ1osR0FDQTtBQUFBLEVBQ0VGLElBQUk7QUFBQSxFQUNKQyxPQUFPO0FBQUEsRUFDUEMsVUFBVTtBQUFBLEVBQ1ZDLE1BQU0sdUJBQUMsc0JBQW1CLElBQUk7QUFBQSxJQUFFQyxVQUFVO0FBQUEsRUFBRyxLQUF2QztBQUFBO0FBQUE7QUFBQTtBQUFBLFNBQXlDO0FBQ2pELEdBQ0E7QUFBQSxFQUNFSixJQUFJO0FBQUEsRUFDSkMsT0FBTztBQUFBLEVBQ1BDLFVBQVU7QUFBQSxFQUNWQyxNQUFNLHVCQUFDLGFBQVUsSUFBSTtBQUFBLElBQUVDLFVBQVU7QUFBQSxFQUFHLEtBQTlCO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FBZ0M7QUFDeEMsR0FDQTtBQUFBLEVBQ0VKLElBQUk7QUFBQSxFQUNKQyxPQUFPO0FBQUEsRUFDUEMsVUFBVTtBQUFBLEVBQ1ZDLE1BQU0sdUJBQUMsbUJBQWdCLElBQUk7QUFBQSxJQUFFQyxVQUFVO0FBQUEsRUFBRyxLQUFwQztBQUFBO0FBQUE7QUFBQTtBQUFBLFNBQXNDO0FBQzlDLEdBQ0E7QUFBQSxFQUNFSixJQUFJO0FBQUEsRUFDSkMsT0FBTztBQUFBLEVBQ1BDLFVBQVU7QUFBQSxFQUNWQyxNQUFNLHVCQUFDLGtCQUFlLElBQUk7QUFBQSxJQUFFQyxVQUFVO0FBQUEsRUFBRyxLQUFuQztBQUFBO0FBQUE7QUFBQTtBQUFBLFNBQXFDO0FBQzdDLEdBQ0E7QUFBQSxFQUNFSixJQUFJO0FBQUEsRUFDSkMsT0FBTztBQUFBLEVBQ1BDLFVBQVU7QUFDWixDQUFDO0FBV0ksYUFBTUcsY0FBMENBLENBQUM7QUFBQSxFQUN0REM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFDRixNQUFNO0FBQ0osUUFBTUMsWUFBWUMsS0FBS0MsS0FBS1AsUUFBUVEsU0FBU04sV0FBVztBQUV4RCxTQUNFLHVCQUFDLFNBQUksV0FBVSwyQkFDYjtBQUFBLDJCQUFDLGtCQUFlLFdBQVduQixPQUN6QixpQ0FBQyxTQUFNLGNBQVksTUFBQyxjQUFXLHlCQUM3QjtBQUFBLDZCQUFDLGFBQ0MsaUNBQUMsWUFDRVUsa0JBQVFnQixJQUFLQyxZQUNaLHVCQUFDLG1CQUVDLE9BQU87QUFBQSxRQUFFZCxVQUFVYyxPQUFPZDtBQUFBQSxNQUFTLEdBRWxDYyxpQkFBT2hCLE9BQU8sV0FBVyxPQUN4Qix1QkFBQyxPQUNDLElBQUk7QUFBQSxRQUFFaUIsU0FBUztBQUFBLFFBQVFDLFlBQVk7QUFBQSxRQUFVQyxLQUFLO0FBQUEsTUFBSSxHQUVyREg7QUFBQUEsZUFBT2I7QUFBQUEsUUFDUGEsT0FBT2Y7QUFBQUEsV0FKVjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBS0EsS0FUR2UsT0FBT2hCLElBRGQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQVlBLENBQ0QsS0FmSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBZ0JBLEtBakJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFrQkE7QUFBQSxNQUNBLHVCQUFDLGFBQ0VNLGtCQUNFUyxJQUFLSyxTQUNKLHVCQUFDLGtCQUVDLEtBQ0Esb0JBRktBLElBQUlwQixJQURYO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFHcUMsQ0FFdEMsS0FSTDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBU0E7QUFBQSxTQTdCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBOEJBLEtBL0JGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FnQ0E7QUFBQSxJQUNBLHVCQUFDLFNBQ0MsU0FBUyxHQUNULElBQUk7QUFBQSxNQUNGcUIsSUFBSTtBQUFBLE1BQ0pKLFNBQVM7QUFBQSxNQUNUQyxZQUFZO0FBQUEsTUFDWkksZ0JBQWdCO0FBQUEsSUFDbEIsR0FFQSxpQ0FBQyxvQkFDQyxPQUFPWCxXQUNQLE1BQ0EsVUFBVUYsY0FDVixpQkFBZSxNQUNmLGdCQUFjLFFBTGhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FLZ0IsS0FkbEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQWdCQTtBQUFBLE9BbERGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FtREE7QUFFSjtBQUFFYyxLQS9EV2xCO0FBQXVDLElBQUFrQjtBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsiUmVhY3QiLCJUYWJsZUNvbnRhaW5lciIsIlRhYmxlIiwiVGFibGVIZWFkIiwiVGFibGVCb2R5IiwiVGFibGVSb3ciLCJQYXBlciIsIkJveCIsIlN0YWNrIiwiUmVzdGF1cmFudE1lbnVJY29uIiwiRXZlbnRJY29uIiwiRGVzY3JpcHRpb25JY29uIiwiUmVzdGF1cmFudEljb24iLCJSZWNpcGVUYWJsZVJvdyIsIlN0eWxlZFRhYmxlQ2VsbCIsIlN0eWxlZFBhZ2luYXRpb24iLCJjb2x1bW5zIiwiaWQiLCJsYWJlbCIsIm1pbldpZHRoIiwiaWNvbiIsImZvbnRTaXplIiwiUmVjaXBlVGFibGUiLCJyZWNpcGVzIiwicGFnZSIsInJvd3NQZXJQYWdlIiwib25QYWdlQ2hhbmdlIiwib25Ub2dnbGVGYXZvcml0ZSIsInBhZ2VDb3VudCIsIk1hdGgiLCJjZWlsIiwibGVuZ3RoIiwibWFwIiwiY29sdW1uIiwiZGlzcGxheSIsImFsaWduSXRlbXMiLCJnYXAiLCJyb3ciLCJtdCIsImp1c3RpZnlDb250ZW50IiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJSZWNpcGVUYWJsZS50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFJlYWN0IGZyb20gXCJyZWFjdFwiO1xyXG5pbXBvcnQge1xyXG4gIFRhYmxlQ29udGFpbmVyLFxyXG4gIFRhYmxlLFxyXG4gIFRhYmxlSGVhZCxcclxuICBUYWJsZUJvZHksXHJcbiAgVGFibGVSb3csXHJcbiAgUGFwZXIsXHJcbiAgQm94LFxyXG4gIFN0YWNrLFxyXG59IGZyb20gXCJAbXVpL21hdGVyaWFsXCI7XHJcbmltcG9ydCBSZXN0YXVyYW50TWVudUljb24gZnJvbSBcIkBtdWkvaWNvbnMtbWF0ZXJpYWwvUmVzdGF1cmFudE1lbnVcIjtcclxuaW1wb3J0IEV2ZW50SWNvbiBmcm9tIFwiQG11aS9pY29ucy1tYXRlcmlhbC9FdmVudFwiO1xyXG5pbXBvcnQgRGVzY3JpcHRpb25JY29uIGZyb20gXCJAbXVpL2ljb25zLW1hdGVyaWFsL0Rlc2NyaXB0aW9uXCI7XHJcbmltcG9ydCBSZXN0YXVyYW50SWNvbiBmcm9tIFwiQG11aS9pY29ucy1tYXRlcmlhbC9SZXN0YXVyYW50XCI7XHJcbmltcG9ydCB7IFJlY2lwZSB9IGZyb20gXCIuLi90eXBlcy9yZWNpcGVcIjtcclxuaW1wb3J0IHsgUmVjaXBlVGFibGVSb3cgfSBmcm9tIFwiLi9SZWNpcGVUYWJsZVJvdy9SZWNpcGVUYWJsZVJvd1wiO1xyXG5pbXBvcnQgeyBTdHlsZWRUYWJsZUNlbGwsIFN0eWxlZFBhZ2luYXRpb24gfSBmcm9tIFwiLi4vc3R5bGVzL1JlY2lwZVRhYmxlU3R5bGVzXCI7XHJcblxyXG5jb25zdCBjb2x1bW5zID0gW1xyXG4gIHtcclxuICAgIGlkOiBcImV4cGFuZFwiLFxyXG4gICAgbGFiZWw6IFwiXCIsXHJcbiAgICBtaW5XaWR0aDogNTAsXHJcbiAgfSxcclxuICB7XHJcbiAgICBpZDogXCJyZWNpcGVOYW1lXCIsXHJcbiAgICBsYWJlbDogXCJSZWNpcGUgTmFtZVwiLFxyXG4gICAgbWluV2lkdGg6IDE3MCxcclxuICAgIGljb246IDxSZXN0YXVyYW50TWVudUljb24gc3g9e3sgZm9udFNpemU6IDIwIH19IC8+LFxyXG4gIH0sXHJcbiAge1xyXG4gICAgaWQ6IFwiZGF0ZVwiLFxyXG4gICAgbGFiZWw6IFwiR2VuZXJhdGVkIE9uXCIsXHJcbiAgICBtaW5XaWR0aDogMTYwLFxyXG4gICAgaWNvbjogPEV2ZW50SWNvbiBzeD17eyBmb250U2l6ZTogMjAgfX0gLz4sXHJcbiAgfSxcclxuICB7XHJcbiAgICBpZDogXCJkZXNjcmlwdGlvblwiLFxyXG4gICAgbGFiZWw6IFwiRGVzY3JpcHRpb25cIixcclxuICAgIG1pbldpZHRoOiAyMDAsXHJcbiAgICBpY29uOiA8RGVzY3JpcHRpb25JY29uIHN4PXt7IGZvbnRTaXplOiAyMCB9fSAvPixcclxuICB9LFxyXG4gIHtcclxuICAgIGlkOiBcImluZ3JlZGllbnRzXCIsXHJcbiAgICBsYWJlbDogXCJJbmdyZWRpZW50cyBVc2VkXCIsXHJcbiAgICBtaW5XaWR0aDogMjAwLFxyXG4gICAgaWNvbjogPFJlc3RhdXJhbnRJY29uIHN4PXt7IGZvbnRTaXplOiAyMCB9fSAvPixcclxuICB9LFxyXG4gIHtcclxuICAgIGlkOiBcImZhdm9yaXRlXCIsXHJcbiAgICBsYWJlbDogXCJcIixcclxuICAgIG1pbldpZHRoOiA1MCxcclxuICB9LFxyXG5dO1xyXG5cclxuaW50ZXJmYWNlIFJlY2lwZVRhYmxlUHJvcHMge1xyXG4gIHJlY2lwZXM6IFJlY2lwZVtdO1xyXG4gIHBhZ2U6IG51bWJlcjtcclxuICByb3dzUGVyUGFnZTogbnVtYmVyO1xyXG4gIG9uUGFnZUNoYW5nZTogKGV2ZW50OiBSZWFjdC5DaGFuZ2VFdmVudDx1bmtub3duPiwgdmFsdWU6IG51bWJlcikgPT4gdm9pZDtcclxuICBvblRvZ2dsZUZhdm9yaXRlOiAocmVjaXBlOiBSZWNpcGUpID0+IHZvaWQ7XHJcbn1cclxuXHJcbmV4cG9ydCBjb25zdCBSZWNpcGVUYWJsZTogUmVhY3QuRkM8UmVjaXBlVGFibGVQcm9wcz4gPSAoe1xyXG4gIHJlY2lwZXMsXHJcbiAgcGFnZSxcclxuICByb3dzUGVyUGFnZSxcclxuICBvblBhZ2VDaGFuZ2UsXHJcbiAgb25Ub2dnbGVGYXZvcml0ZSxcclxufSkgPT4ge1xyXG4gIGNvbnN0IHBhZ2VDb3VudCA9IE1hdGguY2VpbChyZWNpcGVzLmxlbmd0aCAvIHJvd3NQZXJQYWdlKTtcclxuXHJcbiAgcmV0dXJuIChcclxuICAgIDxkaXYgY2xhc3NOYW1lPVwiaGlzdG9yeS10YWJsZS1jb250YWluZXJcIj5cclxuICAgICAgPFRhYmxlQ29udGFpbmVyIGNvbXBvbmVudD17UGFwZXJ9PlxyXG4gICAgICAgIDxUYWJsZSBzdGlja3lIZWFkZXIgYXJpYS1sYWJlbD1cImNvb2tpbmcgaGlzdG9yeSB0YWJsZVwiPlxyXG4gICAgICAgICAgPFRhYmxlSGVhZD5cclxuICAgICAgICAgICAgPFRhYmxlUm93PlxyXG4gICAgICAgICAgICAgIHtjb2x1bW5zLm1hcCgoY29sdW1uKSA9PiAoXHJcbiAgICAgICAgICAgICAgICA8U3R5bGVkVGFibGVDZWxsXHJcbiAgICAgICAgICAgICAgICAgIGtleT17Y29sdW1uLmlkfVxyXG4gICAgICAgICAgICAgICAgICBzdHlsZT17eyBtaW5XaWR0aDogY29sdW1uLm1pbldpZHRoIH19XHJcbiAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgIHtjb2x1bW4uaWQgPT09IFwiZXhwYW5kXCIgPyBudWxsIDogKFxyXG4gICAgICAgICAgICAgICAgICAgIDxCb3hcclxuICAgICAgICAgICAgICAgICAgICAgIHN4PXt7IGRpc3BsYXk6IFwiZmxleFwiLCBhbGlnbkl0ZW1zOiBcImNlbnRlclwiLCBnYXA6IDAuNSB9fVxyXG4gICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgIHtjb2x1bW4uaWNvbn1cclxuICAgICAgICAgICAgICAgICAgICAgIHtjb2x1bW4ubGFiZWx9XHJcbiAgICAgICAgICAgICAgICAgICAgPC9Cb3g+XHJcbiAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICA8L1N0eWxlZFRhYmxlQ2VsbD5cclxuICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgPC9UYWJsZVJvdz5cclxuICAgICAgICAgIDwvVGFibGVIZWFkPlxyXG4gICAgICAgICAgPFRhYmxlQm9keT5cclxuICAgICAgICAgICAge3JlY2lwZXNcclxuICAgICAgICAgICAgICAubWFwKChyb3cpID0+IChcclxuICAgICAgICAgICAgICAgIDxSZWNpcGVUYWJsZVJvd1xyXG4gICAgICAgICAgICAgICAgICBrZXk9e3Jvdy5pZH1cclxuICAgICAgICAgICAgICAgICAgcm93PXtyb3d9XHJcbiAgICAgICAgICAgICAgICAgIG9uVG9nZ2xlRmF2b3JpdGU9e29uVG9nZ2xlRmF2b3JpdGV9XHJcbiAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgPC9UYWJsZUJvZHk+XHJcbiAgICAgICAgPC9UYWJsZT5cclxuICAgICAgPC9UYWJsZUNvbnRhaW5lcj5cclxuICAgICAgPFN0YWNrXHJcbiAgICAgICAgc3BhY2luZz17Mn1cclxuICAgICAgICBzeD17e1xyXG4gICAgICAgICAgbXQ6IDIsXHJcbiAgICAgICAgICBkaXNwbGF5OiBcImZsZXhcIixcclxuICAgICAgICAgIGFsaWduSXRlbXM6IFwiZmxleC1lbmRcIixcclxuICAgICAgICAgIGp1c3RpZnlDb250ZW50OiBcImZsZXgtZW5kXCIsXHJcbiAgICAgICAgfX1cclxuICAgICAgPlxyXG4gICAgICAgIDxTdHlsZWRQYWdpbmF0aW9uXHJcbiAgICAgICAgICBjb3VudD17cGFnZUNvdW50fVxyXG4gICAgICAgICAgcGFnZT17cGFnZX1cclxuICAgICAgICAgIG9uQ2hhbmdlPXtvblBhZ2VDaGFuZ2V9XHJcbiAgICAgICAgICBzaG93Rmlyc3RCdXR0b25cclxuICAgICAgICAgIHNob3dMYXN0QnV0dG9uXHJcbiAgICAgICAgLz5cclxuICAgICAgPC9TdGFjaz5cclxuICAgIDwvZGl2PlxyXG4gICk7XHJcbn07XHJcbiJdLCJmaWxlIjoiQzovVXNlcnMvc19tYXIvY3MzMi9TbmFja1N0YWNrL2NsaWVudC9zcmMvY29tcG9uZW50cy9SZWNpcGVUYWJsZS50c3gifQ==