import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/contexts/UserContext.tsx");import.meta.env = {"VITE_CLERK_PUBLISHABLE_KEY":"pk_test_YW1wbGUtZmVycmV0LTIzLmNsZXJrLmFjY291bnRzLmRldiQ","VITE_DISABLE_AUTH":"true","VITE_TEST_USERNAME":"test_user","VITE_TEST_EMAIL":"test_user@test.test","BASE_URL":"/","MODE":"development","DEV":true,"PROD":false,"SSR":false};import { jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/s_mar/cs32/SnackStack/client/src/contexts/UserContext.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$(), _s2 = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=4d3a3d4b"; const createContext = __vite__cjsImport3_react["createContext"]; const useState = __vite__cjsImport3_react["useState"]; const useEffect = __vite__cjsImport3_react["useEffect"]; const useContext = __vite__cjsImport3_react["useContext"];
import axios from "/node_modules/.vite/deps/axios.js?v=4d3a3d4b";
import { useUser } from "/node_modules/.vite/deps/@clerk_clerk-react.js?v=4d3a3d4b";
const disableAuth = import.meta.env.VITE_DISABLE_AUTH === "true";
const testUsername = import.meta.env.VITE_TEST_USERNAME;
const testEmail = import.meta.env.VITE_TEST_EMAIL;
export const UserContext = createContext(void 0);
export const UserProvider = ({
  children
}) => {
  _s();
  const {
    user,
    isLoaded,
    isSignedIn
  } = useUser();
  const [dbUserId, setDbUserId] = useState(null);
  const [username, setUsername] = useState("");
  const [email, setEmail] = useState("");
  const [isProfileComplete, setIsProfileComplete] = useState(false);
  const clearUserData = () => {
    setDbUserId(null);
    setUsername("");
    setEmail("");
    setIsProfileComplete(false);
    localStorage.removeItem("userProfile");
  };
  useEffect(() => {
    if (disableAuth && testUsername && testEmail) {
      setDbUserId(-1);
      setUsername(testUsername);
      setEmail(testEmail);
      setIsProfileComplete(true);
      return;
    }
    if (isLoaded) {
      if (!isSignedIn) {
        clearUserData();
      } else if (user) {
        const userEmail = user.primaryEmailAddress?.emailAddress || "";
        const savedUser = localStorage.getItem("userProfile");
        if (savedUser) {
          try {
            const userData = JSON.parse(savedUser);
            if (userData.email === userEmail) {
              setDbUserId(userData.id);
              setUsername(userData.username);
              setEmail(userData.email);
              setIsProfileComplete(true);
            } else {
              clearUserData();
            }
          } catch (e) {
            clearUserData();
          }
        }
        if (!isProfileComplete && userEmail) {
          checkUserProfileByEmail(userEmail);
        }
      }
    }
  }, [disableAuth, testUsername, testEmail, isLoaded, isSignedIn, user]);
  const checkUserProfileByEmail = (email2) => {
    console.log("Checking profile for email:", email2);
    axios.get(`http://localhost:8080/api/users/email/${email2}`).then((response) => {
      console.log("Backend response:", response.data);
      if (response.data && response.data.userId) {
        const userData = {
          id: response.data.userId,
          // CHANGE: map userId to id
          username: response.data.userName,
          // CHANGE: map userName to username
          email: response.data.email
        };
        console.log("Setting user data:", userData);
        setDbUserId(userData.id);
        setUsername(userData.username);
        setEmail(userData.email);
        setIsProfileComplete(true);
        localStorage.setItem("userProfile", JSON.stringify(userData));
      }
    }).catch((error) => {
      console.error("Error checking user profile:", error);
      setIsProfileComplete(false);
    });
  };
  const setUserData = (data) => {
    setDbUserId(data.id);
    setUsername(data.username);
    setEmail(data.email);
    setIsProfileComplete(true);
    localStorage.setItem("userProfile", JSON.stringify(data));
  };
  return /* @__PURE__ */ jsxDEV(UserContext.Provider, { value: {
    dbUserId,
    username,
    email,
    isProfileComplete,
    setUserData,
    clearUserData
  }, children }, void 0, false, {
    fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/contexts/UserContext.tsx",
    lineNumber: 173,
    columnNumber: 10
  }, this);
};
_s(UserProvider, "yJGB5WNC7SekfSq6g4MwgnqHrpg=", false, function() {
  return [useUser];
});
_c = UserProvider;
export const useUserContext = () => {
  _s2();
  const context = useContext(UserContext);
  if (context === void 0) {
    throw new Error("useUserContext must be used within a UserProvider");
  }
  return context;
};
_s2(useUserContext, "b9L3QQ+jgeyIrH0NfHrJ8nn7VMU=");
var _c;
$RefreshReg$(_c, "UserProvider");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/s_mar/cs32/SnackStack/client/src/contexts/UserContext.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBa0xJOzs7Ozs7Ozs7Ozs7Ozs7O0FBakxKLFNBQ0VBLGVBQ0FDLFVBQ0FDLFdBQ0FDLGtCQUVLO0FBQ1AsT0FBT0MsV0FBVztBQUNsQixTQUFTQyxlQUFlO0FBRXhCLE1BQU1DLGNBQWVDLFlBQVlDLElBQUlDLHNCQUFzQjtBQUMzRCxNQUFNQyxlQUFlSCxZQUFZQyxJQUFJRztBQUNyQyxNQUFNQyxZQUFlTCxZQUFZQyxJQUFJSztBQVc5QixhQUFNQyxjQUFjZCxjQUN6QmUsTUFDRjtBQUVPLGFBQU1DLGVBQWVBLENBQUM7QUFBQSxFQUFFQztBQUFrQyxNQUFNO0FBQUFDLEtBQUE7QUFDckUsUUFBTTtBQUFBLElBQUVDO0FBQUFBLElBQU1DO0FBQUFBLElBQVVDO0FBQUFBLEVBQVcsSUFBSWhCLFFBQVE7QUFDL0MsUUFBTSxDQUFDaUIsVUFBVUMsV0FBVyxJQUFJdEIsU0FBd0IsSUFBSTtBQUM1RCxRQUFNLENBQUN1QixVQUFVQyxXQUFXLElBQUl4QixTQUFTLEVBQUU7QUFDM0MsUUFBTSxDQUFDeUIsT0FBT0MsUUFBUSxJQUFJMUIsU0FBUyxFQUFFO0FBQ3JDLFFBQU0sQ0FBQzJCLG1CQUFtQkMsb0JBQW9CLElBQUk1QixTQUFTLEtBQUs7QUFHaEUsUUFBTTZCLGdCQUFnQkEsTUFBTTtBQUMxQlAsZ0JBQVksSUFBSTtBQUNoQkUsZ0JBQVksRUFBRTtBQUNkRSxhQUFTLEVBQUU7QUFDWEUseUJBQXFCLEtBQUs7QUFDMUJFLGlCQUFhQyxXQUFXLGFBQWE7QUFBQSxFQUN2QztBQUVBOUIsWUFBVSxNQUFNO0FBRWQsUUFBSUksZUFBZUksZ0JBQWdCRSxXQUFXO0FBQzVDVyxrQkFBWSxFQUFFO0FBQ2RFLGtCQUFZZixZQUFZO0FBQ3hCaUIsZUFBU2YsU0FBUztBQUNsQmlCLDJCQUFxQixJQUFJO0FBQ3pCO0FBQUEsSUFDRjtBQUdBLFFBQUlULFVBQVU7QUFDWixVQUFJLENBQUNDLFlBQVk7QUFDZlMsc0JBQWM7QUFBQSxNQUNoQixXQUFXWCxNQUFNO0FBRWYsY0FBTWMsWUFBWWQsS0FBS2UscUJBQXFCQyxnQkFBZ0I7QUFHNUQsY0FBTUMsWUFBWUwsYUFBYU0sUUFBUSxhQUFhO0FBQ3BELFlBQUlELFdBQVc7QUFDYixjQUFJO0FBQ0Ysa0JBQU1FLFdBQVdDLEtBQUtDLE1BQU1KLFNBQVM7QUFFckMsZ0JBQUlFLFNBQVNaLFVBQVVPLFdBQVc7QUFDaENWLDBCQUFZZSxTQUFTRyxFQUFFO0FBQ3ZCaEIsMEJBQVlhLFNBQVNkLFFBQVE7QUFDN0JHLHVCQUFTVyxTQUFTWixLQUFLO0FBQ3ZCRyxtQ0FBcUIsSUFBSTtBQUFBLFlBQzNCLE9BQU87QUFFTEMsNEJBQWM7QUFBQSxZQUNoQjtBQUFBLFVBQ0YsU0FBU1ksR0FBRztBQUNWWiwwQkFBYztBQUFBLFVBQ2hCO0FBQUEsUUFDRjtBQUdBLFlBQUksQ0FBQ0YscUJBQXFCSyxXQUFXO0FBQ25DVSxrQ0FBd0JWLFNBQVM7QUFBQSxRQUNuQztBQUFBLE1BQ0Y7QUFBQSxJQUNGO0FBQUEsRUFDRixHQUFHLENBQUMzQixhQUFhSSxjQUFjRSxXQUFXUSxVQUFVQyxZQUFZRixJQUFJLENBQUM7QUF5Q3JFLFFBQU13QiwwQkFBMEJBLENBQUNqQixXQUFrQjtBQUNqRGtCLFlBQVFDLElBQUksK0JBQStCbkIsTUFBSztBQUVoRHRCLFVBQ0cwQyxJQUFJLHlDQUF5Q3BCLE1BQUssRUFBRSxFQUNwRHFCLEtBQU1DLGNBQWE7QUFDbEJKLGNBQVFDLElBQUkscUJBQXFCRyxTQUFTQyxJQUFJO0FBRTlDLFVBQUlELFNBQVNDLFFBQVFELFNBQVNDLEtBQUtDLFFBQVE7QUFHekMsY0FBTVosV0FBVztBQUFBLFVBQ2ZHLElBQUlPLFNBQVNDLEtBQUtDO0FBQUFBO0FBQUFBLFVBQ2xCMUIsVUFBVXdCLFNBQVNDLEtBQUtFO0FBQUFBO0FBQUFBLFVBQ3hCekIsT0FBT3NCLFNBQVNDLEtBQUt2QjtBQUFBQSxRQUN2QjtBQUVBa0IsZ0JBQVFDLElBQUksc0JBQXNCUCxRQUFRO0FBRTFDZixvQkFBWWUsU0FBU0csRUFBRTtBQUN2QmhCLG9CQUFZYSxTQUFTZCxRQUFRO0FBQzdCRyxpQkFBU1csU0FBU1osS0FBSztBQUN2QkcsNkJBQXFCLElBQUk7QUFHekJFLHFCQUFhcUIsUUFBUSxlQUFlYixLQUFLYyxVQUFVZixRQUFRLENBQUM7QUFBQSxNQUM5RDtBQUFBLElBQ0YsQ0FBQyxFQUNBZ0IsTUFBT0MsV0FBVTtBQUNoQlgsY0FBUVcsTUFBTSxnQ0FBZ0NBLEtBQUs7QUFDbkQxQiwyQkFBcUIsS0FBSztBQUFBLElBQzVCLENBQUM7QUFBQSxFQUNMO0FBRUEsUUFBTTJCLGNBQWNBLENBQUNQLFNBSWY7QUFDSjFCLGdCQUFZMEIsS0FBS1IsRUFBRTtBQUNuQmhCLGdCQUFZd0IsS0FBS3pCLFFBQVE7QUFDekJHLGFBQVNzQixLQUFLdkIsS0FBSztBQUNuQkcseUJBQXFCLElBQUk7QUFHekJFLGlCQUFhcUIsUUFBUSxlQUFlYixLQUFLYyxVQUFVSixJQUFJLENBQUM7QUFBQSxFQUMxRDtBQUVBLFNBQ0UsdUJBQUMsWUFBWSxVQUFaLEVBQ0MsT0FBTztBQUFBLElBQ0wzQjtBQUFBQSxJQUNBRTtBQUFBQSxJQUNBRTtBQUFBQSxJQUNBRTtBQUFBQSxJQUNBNEI7QUFBQUEsSUFDQTFCO0FBQUFBLEVBQ0YsR0FFQ2IsWUFWSDtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBV0E7QUFFSjtBQUFFQyxHQW5LV0YsY0FBWTtBQUFBLFVBQ2dCWCxPQUFPO0FBQUE7QUFBQW9ELEtBRG5DekM7QUFxS04sYUFBTTBDLGlCQUFpQkEsTUFBTTtBQUFBQyxNQUFBO0FBQ2xDLFFBQU1DLFVBQVV6RCxXQUFXVyxXQUFXO0FBQ3RDLE1BQUk4QyxZQUFZN0MsUUFBVztBQUN6QixVQUFNLElBQUk4QyxNQUFNLG1EQUFtRDtBQUFBLEVBQ3JFO0FBQ0EsU0FBT0Q7QUFDVDtBQUFFRCxJQU5XRCxnQkFBYztBQUFBLElBQUFEO0FBQUFLLGFBQUFMLElBQUEiLCJuYW1lcyI6WyJjcmVhdGVDb250ZXh0IiwidXNlU3RhdGUiLCJ1c2VFZmZlY3QiLCJ1c2VDb250ZXh0IiwiYXhpb3MiLCJ1c2VVc2VyIiwiZGlzYWJsZUF1dGgiLCJpbXBvcnQiLCJlbnYiLCJWSVRFX0RJU0FCTEVfQVVUSCIsInRlc3RVc2VybmFtZSIsIlZJVEVfVEVTVF9VU0VSTkFNRSIsInRlc3RFbWFpbCIsIlZJVEVfVEVTVF9FTUFJTCIsIlVzZXJDb250ZXh0IiwidW5kZWZpbmVkIiwiVXNlclByb3ZpZGVyIiwiY2hpbGRyZW4iLCJfcyIsInVzZXIiLCJpc0xvYWRlZCIsImlzU2lnbmVkSW4iLCJkYlVzZXJJZCIsInNldERiVXNlcklkIiwidXNlcm5hbWUiLCJzZXRVc2VybmFtZSIsImVtYWlsIiwic2V0RW1haWwiLCJpc1Byb2ZpbGVDb21wbGV0ZSIsInNldElzUHJvZmlsZUNvbXBsZXRlIiwiY2xlYXJVc2VyRGF0YSIsImxvY2FsU3RvcmFnZSIsInJlbW92ZUl0ZW0iLCJ1c2VyRW1haWwiLCJwcmltYXJ5RW1haWxBZGRyZXNzIiwiZW1haWxBZGRyZXNzIiwic2F2ZWRVc2VyIiwiZ2V0SXRlbSIsInVzZXJEYXRhIiwiSlNPTiIsInBhcnNlIiwiaWQiLCJlIiwiY2hlY2tVc2VyUHJvZmlsZUJ5RW1haWwiLCJjb25zb2xlIiwibG9nIiwiZ2V0IiwidGhlbiIsInJlc3BvbnNlIiwiZGF0YSIsInVzZXJJZCIsInVzZXJOYW1lIiwic2V0SXRlbSIsInN0cmluZ2lmeSIsImNhdGNoIiwiZXJyb3IiLCJzZXRVc2VyRGF0YSIsIl9jIiwidXNlVXNlckNvbnRleHQiLCJfczIiLCJjb250ZXh0IiwiRXJyb3IiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJVc2VyQ29udGV4dC50c3giXSwic291cmNlc0NvbnRlbnQiOlsiLy8gY29udGV4dHMvVXNlckNvbnRleHQudHN4XHJcbmltcG9ydCB7XHJcbiAgY3JlYXRlQ29udGV4dCxcclxuICB1c2VTdGF0ZSxcclxuICB1c2VFZmZlY3QsXHJcbiAgdXNlQ29udGV4dCxcclxuICBSZWFjdE5vZGUsXHJcbn0gZnJvbSBcInJlYWN0XCI7XHJcbmltcG9ydCBheGlvcyBmcm9tIFwiYXhpb3NcIjtcclxuaW1wb3J0IHsgdXNlVXNlciB9IGZyb20gXCJAY2xlcmsvY2xlcmstcmVhY3RcIjtcclxuXHJcbmNvbnN0IGRpc2FibGVBdXRoICA9IGltcG9ydC5tZXRhLmVudi5WSVRFX0RJU0FCTEVfQVVUSCA9PT0gXCJ0cnVlXCI7XHJcbmNvbnN0IHRlc3RVc2VybmFtZSA9IGltcG9ydC5tZXRhLmVudi5WSVRFX1RFU1RfVVNFUk5BTUU7XHJcbmNvbnN0IHRlc3RFbWFpbCAgICA9IGltcG9ydC5tZXRhLmVudi5WSVRFX1RFU1RfRU1BSUw7XHJcblxyXG5pbnRlcmZhY2UgVXNlckNvbnRleHRUeXBlIHtcclxuICBkYlVzZXJJZDogbnVtYmVyIHwgbnVsbDtcclxuICB1c2VybmFtZTogc3RyaW5nO1xyXG4gIGVtYWlsOiBzdHJpbmc7XHJcbiAgaXNQcm9maWxlQ29tcGxldGU6IGJvb2xlYW47XHJcbiAgc2V0VXNlckRhdGE6IChkYXRhOiB7IGlkOiBudW1iZXI7IHVzZXJuYW1lOiBzdHJpbmc7IGVtYWlsOiBzdHJpbmcgfSkgPT4gdm9pZDtcclxuICBjbGVhclVzZXJEYXRhOiAoKSA9PiB2b2lkO1xyXG59XHJcblxyXG5leHBvcnQgY29uc3QgVXNlckNvbnRleHQgPSBjcmVhdGVDb250ZXh0PFVzZXJDb250ZXh0VHlwZSB8IHVuZGVmaW5lZD4oXHJcbiAgdW5kZWZpbmVkXHJcbik7XHJcblxyXG5leHBvcnQgY29uc3QgVXNlclByb3ZpZGVyID0gKHsgY2hpbGRyZW4gfTogeyBjaGlsZHJlbjogUmVhY3ROb2RlIH0pID0+IHtcclxuICBjb25zdCB7IHVzZXIsIGlzTG9hZGVkLCBpc1NpZ25lZEluIH0gPSB1c2VVc2VyKCk7XHJcbiAgY29uc3QgW2RiVXNlcklkLCBzZXREYlVzZXJJZF0gPSB1c2VTdGF0ZTxudW1iZXIgfCBudWxsPihudWxsKTtcclxuICBjb25zdCBbdXNlcm5hbWUsIHNldFVzZXJuYW1lXSA9IHVzZVN0YXRlKFwiXCIpO1xyXG4gIGNvbnN0IFtlbWFpbCwgc2V0RW1haWxdID0gdXNlU3RhdGUoXCJcIik7XHJcbiAgY29uc3QgW2lzUHJvZmlsZUNvbXBsZXRlLCBzZXRJc1Byb2ZpbGVDb21wbGV0ZV0gPSB1c2VTdGF0ZShmYWxzZSk7XHJcblxyXG4gIC8vIENsZWFyIHVzZXIgZGF0YVxyXG4gIGNvbnN0IGNsZWFyVXNlckRhdGEgPSAoKSA9PiB7XHJcbiAgICBzZXREYlVzZXJJZChudWxsKTtcclxuICAgIHNldFVzZXJuYW1lKFwiXCIpO1xyXG4gICAgc2V0RW1haWwoXCJcIik7XHJcbiAgICBzZXRJc1Byb2ZpbGVDb21wbGV0ZShmYWxzZSk7XHJcbiAgICBsb2NhbFN0b3JhZ2UucmVtb3ZlSXRlbShcInVzZXJQcm9maWxlXCIpO1xyXG4gIH07XHJcblxyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICAvLyAxKSBJZiBkaXNhYmxlQXV0aCBpcyB0cnVlLCBpbW1lZGlhdGVseSBzZWVkIHRoZSB0ZXN0IHVzZXIgYW5kIHNraXAgZXZlcnl0aGluZyBlbHNlXHJcbiAgICBpZiAoZGlzYWJsZUF1dGggJiYgdGVzdFVzZXJuYW1lICYmIHRlc3RFbWFpbCkge1xyXG4gICAgICBzZXREYlVzZXJJZCgtMSk7ICAgICAgICAgICAgLy8gZHVtbXkgaWRcclxuICAgICAgc2V0VXNlcm5hbWUodGVzdFVzZXJuYW1lKTtcclxuICAgICAgc2V0RW1haWwodGVzdEVtYWlsKTtcclxuICAgICAgc2V0SXNQcm9maWxlQ29tcGxldGUodHJ1ZSk7XHJcbiAgICAgIHJldHVybjsgICAgICAgICAgICAgICAgICAgICAvLyBTVE9QIGhlcmXigJRubyBDbGVyayBvciBBUEkgY2FsbHNcclxuICAgIH1cclxuICBcclxuICAgIC8vIDIpIE90aGVyd2lzZSwgcnVuIHlvdXIgZXhpc3RpbmcgQ2xlcmsgKyBsb2NhbFN0b3JhZ2UgKyBiYWNrZW5k4oCQY2hlY2sgbG9naWM6XHJcbiAgICBpZiAoaXNMb2FkZWQpIHtcclxuICAgICAgaWYgKCFpc1NpZ25lZEluKSB7XHJcbiAgICAgICAgY2xlYXJVc2VyRGF0YSgpO1xyXG4gICAgICB9IGVsc2UgaWYgKHVzZXIpIHtcclxuICAgICAgICAvLyBHZXQgdXNlcidzIGVtYWlsIGZyb20gQ2xlcmtcclxuICAgICAgICBjb25zdCB1c2VyRW1haWwgPSB1c2VyLnByaW1hcnlFbWFpbEFkZHJlc3M/LmVtYWlsQWRkcmVzcyB8fCBcIlwiO1xyXG5cclxuICAgICAgICAvLyBVc2VyIGlzIGxvZ2dlZCBpbiwgYXR0ZW1wdCB0byBsb2FkIHByb2ZpbGUgZnJvbSBsb2NhbFN0b3JhZ2UgZmlyc3RcclxuICAgICAgICBjb25zdCBzYXZlZFVzZXIgPSBsb2NhbFN0b3JhZ2UuZ2V0SXRlbShcInVzZXJQcm9maWxlXCIpO1xyXG4gICAgICAgIGlmIChzYXZlZFVzZXIpIHtcclxuICAgICAgICAgIHRyeSB7XHJcbiAgICAgICAgICAgIGNvbnN0IHVzZXJEYXRhID0gSlNPTi5wYXJzZShzYXZlZFVzZXIpO1xyXG4gICAgICAgICAgICAvLyBWZXJpZnkgdGhlIHNhdmVkIGVtYWlsIG1hdGNoZXMgdGhlIGN1cnJlbnQgQ2xlcmsgdXNlcidzIGVtYWlsXHJcbiAgICAgICAgICAgIGlmICh1c2VyRGF0YS5lbWFpbCA9PT0gdXNlckVtYWlsKSB7XHJcbiAgICAgICAgICAgICAgc2V0RGJVc2VySWQodXNlckRhdGEuaWQpO1xyXG4gICAgICAgICAgICAgIHNldFVzZXJuYW1lKHVzZXJEYXRhLnVzZXJuYW1lKTtcclxuICAgICAgICAgICAgICBzZXRFbWFpbCh1c2VyRGF0YS5lbWFpbCk7XHJcbiAgICAgICAgICAgICAgc2V0SXNQcm9maWxlQ29tcGxldGUodHJ1ZSk7XHJcbiAgICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgICAgLy8gU3RvcmVkIGRhdGEgaXMgZm9yIGEgZGlmZmVyZW50IHVzZXIsIGNsZWFyIGl0XHJcbiAgICAgICAgICAgICAgY2xlYXJVc2VyRGF0YSgpO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICB9IGNhdGNoIChlKSB7XHJcbiAgICAgICAgICAgIGNsZWFyVXNlckRhdGEoKTtcclxuICAgICAgICAgIH1cclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIC8vIElmIG5vIHByb2ZpbGUgZGF0YSBpcyBsb2FkZWQsIGNoZWNrIHRoZSBiYWNrZW5kXHJcbiAgICAgICAgaWYgKCFpc1Byb2ZpbGVDb21wbGV0ZSAmJiB1c2VyRW1haWwpIHtcclxuICAgICAgICAgIGNoZWNrVXNlclByb2ZpbGVCeUVtYWlsKHVzZXJFbWFpbCk7XHJcbiAgICAgICAgfVxyXG4gICAgICB9XHJcbiAgICB9XHJcbiAgfSwgW2Rpc2FibGVBdXRoLCB0ZXN0VXNlcm5hbWUsIHRlc3RFbWFpbCwgaXNMb2FkZWQsIGlzU2lnbmVkSW4sIHVzZXJdKTtcclxuXHJcbiAgLy8gLy8gTW9uaXRvciBDbGVyayBhdXRoZW50aWNhdGlvbiBzdGF0ZVxyXG4gIC8vIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgLy8gICBpZiAoaXNMb2FkZWQpIHtcclxuICAvLyAgICAgaWYgKCFpc1NpZ25lZEluKSB7XHJcbiAgLy8gICAgICAgLy8gVXNlciBsb2dnZWQgb3V0LCBjbGVhciBkYXRhXHJcbiAgLy8gICAgICAgY2xlYXJVc2VyRGF0YSgpO1xyXG4gIC8vICAgICB9IGVsc2UgaWYgKHVzZXIpIHtcclxuICAvLyAgICAgICAvLyBHZXQgdXNlcidzIGVtYWlsIGZyb20gQ2xlcmtcclxuICAvLyAgICAgICBjb25zdCB1c2VyRW1haWwgPSB1c2VyLnByaW1hcnlFbWFpbEFkZHJlc3M/LmVtYWlsQWRkcmVzcyB8fCBcIlwiO1xyXG5cclxuICAvLyAgICAgICAvLyBVc2VyIGlzIGxvZ2dlZCBpbiwgYXR0ZW1wdCB0byBsb2FkIHByb2ZpbGUgZnJvbSBsb2NhbFN0b3JhZ2UgZmlyc3RcclxuICAvLyAgICAgICBjb25zdCBzYXZlZFVzZXIgPSBsb2NhbFN0b3JhZ2UuZ2V0SXRlbShcInVzZXJQcm9maWxlXCIpO1xyXG4gIC8vICAgICAgIGlmIChzYXZlZFVzZXIpIHtcclxuICAvLyAgICAgICAgIHRyeSB7XHJcbiAgLy8gICAgICAgICAgIGNvbnN0IHVzZXJEYXRhID0gSlNPTi5wYXJzZShzYXZlZFVzZXIpO1xyXG4gIC8vICAgICAgICAgICAvLyBWZXJpZnkgdGhlIHNhdmVkIGVtYWlsIG1hdGNoZXMgdGhlIGN1cnJlbnQgQ2xlcmsgdXNlcidzIGVtYWlsXHJcbiAgLy8gICAgICAgICAgIGlmICh1c2VyRGF0YS5lbWFpbCA9PT0gdXNlckVtYWlsKSB7XHJcbiAgLy8gICAgICAgICAgICAgc2V0RGJVc2VySWQodXNlckRhdGEuaWQpO1xyXG4gIC8vICAgICAgICAgICAgIHNldFVzZXJuYW1lKHVzZXJEYXRhLnVzZXJuYW1lKTtcclxuICAvLyAgICAgICAgICAgICBzZXRFbWFpbCh1c2VyRGF0YS5lbWFpbCk7XHJcbiAgLy8gICAgICAgICAgICAgc2V0SXNQcm9maWxlQ29tcGxldGUodHJ1ZSk7XHJcbiAgLy8gICAgICAgICAgIH0gZWxzZSB7XHJcbiAgLy8gICAgICAgICAgICAgLy8gU3RvcmVkIGRhdGEgaXMgZm9yIGEgZGlmZmVyZW50IHVzZXIsIGNsZWFyIGl0XHJcbiAgLy8gICAgICAgICAgICAgY2xlYXJVc2VyRGF0YSgpO1xyXG4gIC8vICAgICAgICAgICB9XHJcbiAgLy8gICAgICAgICB9IGNhdGNoIChlKSB7XHJcbiAgLy8gICAgICAgICAgIGNsZWFyVXNlckRhdGEoKTtcclxuICAvLyAgICAgICAgIH1cclxuICAvLyAgICAgICB9XHJcblxyXG4gIC8vICAgICAgIC8vIElmIG5vIHByb2ZpbGUgZGF0YSBpcyBsb2FkZWQsIGNoZWNrIHRoZSBiYWNrZW5kXHJcbiAgLy8gICAgICAgaWYgKCFpc1Byb2ZpbGVDb21wbGV0ZSAmJiB1c2VyRW1haWwpIHtcclxuICAvLyAgICAgICAgIGNoZWNrVXNlclByb2ZpbGVCeUVtYWlsKHVzZXJFbWFpbCk7XHJcbiAgLy8gICAgICAgfVxyXG4gIC8vICAgICB9XHJcbiAgLy8gICB9XHJcbiAgLy8gfSwgW2lzTG9hZGVkLCBpc1NpZ25lZEluLCB1c2VyXSk7XHJcblxyXG4gIC8vIENoZWNrIGlmIHVzZXIgZXhpc3RzIGluIGJhY2tlbmQgYnkgZW1haWxcclxuICBjb25zdCBjaGVja1VzZXJQcm9maWxlQnlFbWFpbCA9IChlbWFpbDogc3RyaW5nKSA9PiB7XHJcbiAgICBjb25zb2xlLmxvZyhcIkNoZWNraW5nIHByb2ZpbGUgZm9yIGVtYWlsOlwiLCBlbWFpbCk7XHJcblxyXG4gICAgYXhpb3NcclxuICAgICAgLmdldChgaHR0cDovL2xvY2FsaG9zdDo4MDgwL2FwaS91c2Vycy9lbWFpbC8ke2VtYWlsfWApXHJcbiAgICAgIC50aGVuKChyZXNwb25zZSkgPT4ge1xyXG4gICAgICAgIGNvbnNvbGUubG9nKFwiQmFja2VuZCByZXNwb25zZTpcIiwgcmVzcG9uc2UuZGF0YSk7XHJcblxyXG4gICAgICAgIGlmIChyZXNwb25zZS5kYXRhICYmIHJlc3BvbnNlLmRhdGEudXNlcklkKSB7XHJcbiAgICAgICAgICAvLyBDSEFOR0U6IGlkIC0+IHVzZXJJZFxyXG4gICAgICAgICAgLy8gVXNlciBleGlzdHMsIHN0b3JlIHRoZWlyIGRldGFpbHNcclxuICAgICAgICAgIGNvbnN0IHVzZXJEYXRhID0ge1xyXG4gICAgICAgICAgICBpZDogcmVzcG9uc2UuZGF0YS51c2VySWQsIC8vIENIQU5HRTogbWFwIHVzZXJJZCB0byBpZFxyXG4gICAgICAgICAgICB1c2VybmFtZTogcmVzcG9uc2UuZGF0YS51c2VyTmFtZSwgLy8gQ0hBTkdFOiBtYXAgdXNlck5hbWUgdG8gdXNlcm5hbWVcclxuICAgICAgICAgICAgZW1haWw6IHJlc3BvbnNlLmRhdGEuZW1haWwsXHJcbiAgICAgICAgICB9O1xyXG5cclxuICAgICAgICAgIGNvbnNvbGUubG9nKFwiU2V0dGluZyB1c2VyIGRhdGE6XCIsIHVzZXJEYXRhKTtcclxuXHJcbiAgICAgICAgICBzZXREYlVzZXJJZCh1c2VyRGF0YS5pZCk7XHJcbiAgICAgICAgICBzZXRVc2VybmFtZSh1c2VyRGF0YS51c2VybmFtZSk7XHJcbiAgICAgICAgICBzZXRFbWFpbCh1c2VyRGF0YS5lbWFpbCk7XHJcbiAgICAgICAgICBzZXRJc1Byb2ZpbGVDb21wbGV0ZSh0cnVlKTtcclxuXHJcbiAgICAgICAgICAvLyBTYXZlIHRvIGxvY2FsU3RvcmFnZSBmb3IgZnV0dXJlIHNlc3Npb25zXHJcbiAgICAgICAgICBsb2NhbFN0b3JhZ2Uuc2V0SXRlbShcInVzZXJQcm9maWxlXCIsIEpTT04uc3RyaW5naWZ5KHVzZXJEYXRhKSk7XHJcbiAgICAgICAgfVxyXG4gICAgICB9KVxyXG4gICAgICAuY2F0Y2goKGVycm9yKSA9PiB7XHJcbiAgICAgICAgY29uc29sZS5lcnJvcihcIkVycm9yIGNoZWNraW5nIHVzZXIgcHJvZmlsZTpcIiwgZXJyb3IpO1xyXG4gICAgICAgIHNldElzUHJvZmlsZUNvbXBsZXRlKGZhbHNlKTtcclxuICAgICAgfSk7XHJcbiAgfTtcclxuXHJcbiAgY29uc3Qgc2V0VXNlckRhdGEgPSAoZGF0YToge1xyXG4gICAgaWQ6IG51bWJlcjtcclxuICAgIHVzZXJuYW1lOiBzdHJpbmc7XHJcbiAgICBlbWFpbDogc3RyaW5nO1xyXG4gIH0pID0+IHtcclxuICAgIHNldERiVXNlcklkKGRhdGEuaWQpO1xyXG4gICAgc2V0VXNlcm5hbWUoZGF0YS51c2VybmFtZSk7XHJcbiAgICBzZXRFbWFpbChkYXRhLmVtYWlsKTtcclxuICAgIHNldElzUHJvZmlsZUNvbXBsZXRlKHRydWUpO1xyXG5cclxuICAgIC8vIFBlcnNpc3QgdG8gbG9jYWxTdG9yYWdlXHJcbiAgICBsb2NhbFN0b3JhZ2Uuc2V0SXRlbShcInVzZXJQcm9maWxlXCIsIEpTT04uc3RyaW5naWZ5KGRhdGEpKTtcclxuICB9O1xyXG5cclxuICByZXR1cm4gKFxyXG4gICAgPFVzZXJDb250ZXh0LlByb3ZpZGVyXHJcbiAgICAgIHZhbHVlPXt7XHJcbiAgICAgICAgZGJVc2VySWQsXHJcbiAgICAgICAgdXNlcm5hbWUsXHJcbiAgICAgICAgZW1haWwsXHJcbiAgICAgICAgaXNQcm9maWxlQ29tcGxldGUsXHJcbiAgICAgICAgc2V0VXNlckRhdGEsXHJcbiAgICAgICAgY2xlYXJVc2VyRGF0YSxcclxuICAgICAgfX1cclxuICAgID5cclxuICAgICAge2NoaWxkcmVufVxyXG4gICAgPC9Vc2VyQ29udGV4dC5Qcm92aWRlcj5cclxuICApO1xyXG59O1xyXG5cclxuZXhwb3J0IGNvbnN0IHVzZVVzZXJDb250ZXh0ID0gKCkgPT4ge1xyXG4gIGNvbnN0IGNvbnRleHQgPSB1c2VDb250ZXh0KFVzZXJDb250ZXh0KTtcclxuICBpZiAoY29udGV4dCA9PT0gdW5kZWZpbmVkKSB7XHJcbiAgICB0aHJvdyBuZXcgRXJyb3IoXCJ1c2VVc2VyQ29udGV4dCBtdXN0IGJlIHVzZWQgd2l0aGluIGEgVXNlclByb3ZpZGVyXCIpO1xyXG4gIH1cclxuICByZXR1cm4gY29udGV4dDtcclxufTtcclxuIl0sImZpbGUiOiJDOi9Vc2Vycy9zX21hci9jczMyL1NuYWNrU3RhY2svY2xpZW50L3NyYy9jb250ZXh0cy9Vc2VyQ29udGV4dC50c3gifQ==