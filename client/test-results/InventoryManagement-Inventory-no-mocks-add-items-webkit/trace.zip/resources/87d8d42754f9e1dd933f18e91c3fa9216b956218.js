import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/InventoryManagement.tsx");import { Fragment, jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/s_mar/cs32/SnackStack/client/src/pages/InventoryManagement.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import { Box, Button, TextField } from "/node_modules/.vite/deps/@mui_material.js?v=4d3a3d4b";
import __vite__cjsImport4_react from "/node_modules/.vite/deps/react.js?v=4d3a3d4b"; const useState = __vite__cjsImport4_react["useState"]; const useEffect = __vite__cjsImport4_react["useEffect"];
import axios from "/node_modules/.vite/deps/axios.js?v=4d3a3d4b";
import { useNavigate } from "/node_modules/.vite/deps/react-router-dom.js?v=4d3a3d4b";
import { useUserContext } from "/src/contexts/UserContext.tsx";
import "/src/styles/InventoryManagement.css";
const API_BASE_URL = "http://localhost:8080/api";
function InventoryManagement() {
  _s();
  const [inputValue, setInputValue] = useState("");
  const [ingredients, setIngredients] = useState(/* @__PURE__ */ new Set());
  const [clickedItems, setClickedItems] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState(null);
  const navigate = useNavigate();
  const {
    username,
    isProfileComplete
  } = useUserContext();
  useEffect(() => {
    if (username && isProfileComplete) {
      fetchIngredients();
    }
  }, [username, isProfileComplete]);
  const fetchIngredients = async () => {
    setIsLoading(true);
    setError(null);
    try {
      const response = await axios.get(`${API_BASE_URL}/users/${username}/inventory`);
      const ingredientList = response.data;
      setIngredients(new Set(ingredientList));
    } catch (error2) {
      if (axios.isAxiosError(error2)) {
        const errorMsg = error2.response?.data?.message || error2.message;
        setError(`Failed to fetch ingredients: ${errorMsg}`);
        console.error("Axios error:", error2.response?.data || error2.message);
      } else {
        setError("An unexpected error occurred while fetching ingredients");
        console.error("Unexpected error:", error2);
      }
    } finally {
      setIsLoading(false);
    }
  };
  const handleInputChange = (e) => {
    setInputValue(e.target.value);
  };
  const handleConfirmClick = async () => {
    if (!username || !isProfileComplete) {
      setError("No user available");
      return;
    }
    const lowerCaseItem = inputValue.toLowerCase();
    if (inputValue.trim() !== "" && ![...ingredients].some((ingredient) => ingredient.toLowerCase() === lowerCaseItem)) {
      try {
        await axios.post(`${API_BASE_URL}/users/${username}/inventory`, {
          ingredientName: inputValue
        });
        setIngredients((prev) => new Set(prev.add(inputValue)));
        setInputValue("");
        setError(null);
      } catch (err) {
        if (axios.isAxiosError(error)) {
          const errorMsg = error.response?.data?.message || error.message;
          setError(`Failed to add ingredient: ${errorMsg}`);
          console.error("Axios error:", error.response?.data || error.message);
        } else {
          setError("An unexpected error occurred while adding ingredient");
          console.error("Unexpected error:", error);
        }
      }
    }
  };
  const handleItemClick = (item) => {
    if (clickedItems.includes(item)) {
      setClickedItems((prevItems) => prevItems.filter((otherItem) => otherItem !== item));
    } else {
      setClickedItems((prev) => [...prev, item]);
    }
  };
  const handleDeleteItems = async () => {
    if (!username || !isProfileComplete) {
      setError("No user available");
      return;
    }
    if (clickedItems.length === 0) {
      return;
    }
    setError(null);
    try {
      const deleteRequests = clickedItems.map((item) => axios.delete(`${API_BASE_URL}/users/${username}/inventory/${encodeURIComponent(item)}`));
      await Promise.all(deleteRequests);
      setIngredients((prev) => new Set([...prev].filter((item) => !clickedItems.includes(item))));
      setClickedItems([]);
    } catch (err) {
      if (axios.isAxiosError(error)) {
        const errorMsg = error.response?.data?.message || error.message;
        setError(`Failed to delete ingredient(s): ${errorMsg}`);
        console.error("Axios error:", error.response?.data || error.message);
      } else {
        setError("An unexpected error occurred while deleting ingredient(s)");
        console.error("Unexpected error:", error);
      }
    }
  };
  const handleDoneClick = () => {
    navigate("/");
  };
  if (!isProfileComplete) {
    return /* @__PURE__ */ jsxDEV("div", { children: /* @__PURE__ */ jsxDEV("h1", { className: "title", children: "Loading User Profile..." }, void 0, false, {
      fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/pages/InventoryManagement.tsx",
      lineNumber: 120,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/pages/InventoryManagement.tsx",
      lineNumber: 119,
      columnNumber: 12
    }, this);
  }
  return /* @__PURE__ */ jsxDEV("div", { children: [
    /* @__PURE__ */ jsxDEV("h1", { className: "title", children: "Inventory Management" }, void 0, false, {
      fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/pages/InventoryManagement.tsx",
      lineNumber: 124,
      columnNumber: 7
    }, this),
    error && /* @__PURE__ */ jsxDEV(Box, { sx: {
      margin: 2,
      padding: 2,
      backgroundColor: "#ffebee",
      color: "#c62828",
      borderRadius: 1
    }, children: error }, void 0, false, {
      fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/pages/InventoryManagement.tsx",
      lineNumber: 127,
      columnNumber: 17
    }, this),
    isLoading ? /* @__PURE__ */ jsxDEV(Box, { sx: {
      margin: 4,
      textAlign: "center"
    }, children: "Loading your ingredients..." }, void 0, false, {
      fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/pages/InventoryManagement.tsx",
      lineNumber: 138,
      columnNumber: 20
    }, this) : /* @__PURE__ */ jsxDEV(Fragment, { children: [
      /* @__PURE__ */ jsxDEV(Box, { sx: {
        margin: 2,
        display: "flex",
        justifyContent: "center"
      }, children: [
        /* @__PURE__ */ jsxDEV(TextField, { "aria-label": "add-ingredient", label: "add ingredient", variant: "outlined", value: inputValue, onChange: handleInputChange, sx: {
          marginRight: 2
        } }, void 0, false, {
          fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/pages/InventoryManagement.tsx",
          lineNumber: 150,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV(Button, { "aria-label": "add-btn", variant: "contained", color: "primary", onClick: handleConfirmClick, sx: {
          margin: 1,
          padding: 1
        }, children: "Add" }, void 0, false, {
          fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/pages/InventoryManagement.tsx",
          lineNumber: 153,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/pages/InventoryManagement.tsx",
        lineNumber: 145,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV(Box, { sx: {
        margin: 6,
        display: "flex",
        justifyContent: "center",
        flexWrap: "wrap"
      }, children: [...ingredients].map((item, index) => /* @__PURE__ */ jsxDEV(Button, { variant: "outlined", sx: {
        margin: 1,
        boxShadow: clickedItems.includes(item) ? "0px 8px 16px rgba(0, 0, 0, 0.3)" : "0px 4px 8px rgba(0, 0, 0, 0.1)",
        backgroundColor: clickedItems.includes(item) ? "#4CAF50" : "transparent",
        // default background color
        color: clickedItems.includes(item) ? "white" : "black",
        // default color for text
        transform: clickedItems.includes(item) ? "scale(0.95)" : "none",
        // default scale effect
        textTransform: "none"
      }, onClick: () => handleItemClick(item), children: item }, index, false, {
        fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/pages/InventoryManagement.tsx",
        lineNumber: 168,
        columnNumber: 52
      }, this)) }, void 0, false, {
        fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/pages/InventoryManagement.tsx",
        lineNumber: 162,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV(Box, { sx: {
        marginTop: 10,
        display: "flex",
        justifyContent: "space-around"
      }, children: [
        /* @__PURE__ */ jsxDEV(Box, { sx: {
          marginTop: 2
        }, children: /* @__PURE__ */ jsxDEV(Button, { "aria-label": "delete-btn", variant: "contained", color: "primary", onClick: handleDeleteItems, disabled: clickedItems.length === 0, children: "DELETE" }, void 0, false, {
          fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/pages/InventoryManagement.tsx",
          lineNumber: 195,
          columnNumber: 15
        }, this) }, void 0, false, {
          fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/pages/InventoryManagement.tsx",
          lineNumber: 192,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV(Box, { sx: {
          marginTop: 2
        }, children: /* @__PURE__ */ jsxDEV(Button, { "aria-label": "done-btn", variant: "contained", color: "secondary", onClick: handleDoneClick, children: "Done" }, void 0, false, {
          fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/pages/InventoryManagement.tsx",
          lineNumber: 204,
          columnNumber: 15
        }, this) }, void 0, false, {
          fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/pages/InventoryManagement.tsx",
          lineNumber: 201,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/pages/InventoryManagement.tsx",
        lineNumber: 186,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/pages/InventoryManagement.tsx",
      lineNumber: 143,
      columnNumber: 18
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/pages/InventoryManagement.tsx",
    lineNumber: 123,
    columnNumber: 10
  }, this);
}
_s(InventoryManagement, "g15JihNdrdl/KNrGOHVqzlIOGMk=", false, function() {
  return [useNavigate, useUserContext];
});
_c = InventoryManagement;
export default InventoryManagement;
var _c;
$RefreshReg$(_c, "InventoryManagement");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/s_mar/cs32/SnackStack/client/src/pages/InventoryManagement.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBc0pRLFNBOEJBLFVBOUJBOzs7Ozs7Ozs7Ozs7Ozs7O0FBdEpSLFNBQVNBLEtBQUtDLFFBQVFDLGlCQUFpQjtBQUN2QyxTQUFTQyxVQUFVQyxpQkFBaUI7QUFDcEMsT0FBT0MsV0FBVztBQUNsQixTQUFTQyxtQkFBbUI7QUFDNUIsU0FBU0Msc0JBQXNCO0FBQy9CLE9BQU87QUFFUCxNQUFNQyxlQUFlO0FBRXJCLFNBQVNDLHNCQUFzQjtBQUFBQyxLQUFBO0FBQzdCLFFBQU0sQ0FBQ0MsWUFBWUMsYUFBYSxJQUFJVCxTQUFTLEVBQUU7QUFDL0MsUUFBTSxDQUFDVSxhQUFhQyxjQUFjLElBQUlYLFNBQXNCLG9CQUFJWSxJQUFJLENBQUM7QUFDckUsUUFBTSxDQUFDQyxjQUFjQyxlQUFlLElBQUlkLFNBQW1CLEVBQUU7QUFDN0QsUUFBTSxDQUFDZSxXQUFXQyxZQUFZLElBQUloQixTQUFTLElBQUk7QUFDL0MsUUFBTSxDQUFDaUIsT0FBT0MsUUFBUSxJQUFJbEIsU0FBd0IsSUFBSTtBQUN0RCxRQUFNbUIsV0FBV2hCLFlBQVk7QUFDN0IsUUFBTTtBQUFBLElBQUVpQjtBQUFBQSxJQUFVQztBQUFBQSxFQUFrQixJQUFJakIsZUFBZTtBQUV2REgsWUFBVSxNQUFNO0FBQ2QsUUFBSW1CLFlBQVlDLG1CQUFtQjtBQUNqQ0MsdUJBQWlCO0FBQUEsSUFDbkI7QUFBQSxFQUNGLEdBQUcsQ0FBQ0YsVUFBVUMsaUJBQWlCLENBQUM7QUFFaEMsUUFBTUMsbUJBQW1CLFlBQVk7QUFDbkNOLGlCQUFhLElBQUk7QUFDakJFLGFBQVMsSUFBSTtBQUViLFFBQUk7QUFDRixZQUFNSyxXQUFXLE1BQU1yQixNQUFNc0IsSUFDM0IsR0FBR25CLFlBQVksVUFBVWUsUUFBUSxZQUNuQztBQUVBLFlBQU1LLGlCQUEyQkYsU0FBU0c7QUFDMUNmLHFCQUFlLElBQUlDLElBQUlhLGNBQWMsQ0FBQztBQUFBLElBQ3hDLFNBQVNSLFFBQU87QUFFZCxVQUFJZixNQUFNeUIsYUFBYVYsTUFBSyxHQUFHO0FBQzdCLGNBQU1XLFdBQVdYLE9BQU1NLFVBQVVHLE1BQU1HLFdBQVdaLE9BQU1ZO0FBQ3hEWCxpQkFBUyxnQ0FBZ0NVLFFBQVEsRUFBRTtBQUNuREUsZ0JBQVFiLE1BQU0sZ0JBQWdCQSxPQUFNTSxVQUFVRyxRQUFRVCxPQUFNWSxPQUFPO0FBQUEsTUFDckUsT0FBTztBQUNMWCxpQkFBUyx5REFBeUQ7QUFDbEVZLGdCQUFRYixNQUFNLHFCQUFxQkEsTUFBSztBQUFBLE1BQzFDO0FBQUEsSUFDRixVQUFDO0FBQ0NELG1CQUFhLEtBQUs7QUFBQSxJQUNwQjtBQUFBLEVBQ0Y7QUFFQSxRQUFNZSxvQkFBb0JBLENBQUNDLE1BQTJDO0FBQ3BFdkIsa0JBQWN1QixFQUFFQyxPQUFPQyxLQUFLO0FBQUEsRUFDOUI7QUFFQSxRQUFNQyxxQkFBcUIsWUFBWTtBQUNyQyxRQUFJLENBQUNmLFlBQVksQ0FBQ0MsbUJBQW1CO0FBQ25DSCxlQUFTLG1CQUFtQjtBQUM1QjtBQUFBLElBQ0Y7QUFFQSxVQUFNa0IsZ0JBQWdCNUIsV0FBVzZCLFlBQVk7QUFFN0MsUUFDRTdCLFdBQVc4QixLQUFLLE1BQU0sTUFDdEIsQ0FBQyxDQUFDLEdBQUc1QixXQUFXLEVBQUU2QixLQUNmQyxnQkFBZUEsV0FBV0gsWUFBWSxNQUFNRCxhQUMvQyxHQUNBO0FBQ0EsVUFBSTtBQUNGLGNBQU1sQyxNQUFNdUMsS0FBSyxHQUFHcEMsWUFBWSxVQUFVZSxRQUFRLGNBQWM7QUFBQSxVQUM5RHNCLGdCQUFnQmxDO0FBQUFBLFFBQ2xCLENBQUM7QUFHREcsdUJBQWdCZ0MsVUFBUyxJQUFJL0IsSUFBSStCLEtBQUtDLElBQUlwQyxVQUFVLENBQUMsQ0FBQztBQUN0REMsc0JBQWMsRUFBRTtBQUNoQlMsaUJBQVMsSUFBSTtBQUFBLE1BQ2YsU0FBUzJCLEtBQUs7QUFDWixZQUFJM0MsTUFBTXlCLGFBQWFWLEtBQUssR0FBRztBQUM3QixnQkFBTVcsV0FBV1gsTUFBTU0sVUFBVUcsTUFBTUcsV0FBV1osTUFBTVk7QUFDeERYLG1CQUFTLDZCQUE2QlUsUUFBUSxFQUFFO0FBQ2hERSxrQkFBUWIsTUFBTSxnQkFBZ0JBLE1BQU1NLFVBQVVHLFFBQVFULE1BQU1ZLE9BQU87QUFBQSxRQUNyRSxPQUFPO0FBQ0xYLG1CQUFTLHNEQUFzRDtBQUMvRFksa0JBQVFiLE1BQU0scUJBQXFCQSxLQUFLO0FBQUEsUUFDMUM7QUFBQSxNQUNGO0FBQUEsSUFDRjtBQUFBLEVBQ0Y7QUFFQSxRQUFNNkIsa0JBQWtCQSxDQUFDQyxTQUFpQjtBQUN4QyxRQUFJbEMsYUFBYW1DLFNBQVNELElBQUksR0FBRztBQUMvQmpDLHNCQUFpQm1DLGVBQ2ZBLFVBQVVDLE9BQVFDLGVBQWNBLGNBQWNKLElBQUksQ0FDcEQ7QUFBQSxJQUNGLE9BQU87QUFDTGpDLHNCQUFpQjZCLFVBQVMsQ0FBQyxHQUFHQSxNQUFNSSxJQUFJLENBQUM7QUFBQSxJQUMzQztBQUFBLEVBQ0Y7QUFFQSxRQUFNSyxvQkFBb0IsWUFBWTtBQUNwQyxRQUFJLENBQUNoQyxZQUFZLENBQUNDLG1CQUFtQjtBQUNuQ0gsZUFBUyxtQkFBbUI7QUFDNUI7QUFBQSxJQUNGO0FBRUEsUUFBSUwsYUFBYXdDLFdBQVcsR0FBRztBQUM3QjtBQUFBLElBQ0Y7QUFFQW5DLGFBQVMsSUFBSTtBQUViLFFBQUk7QUFFRixZQUFNb0MsaUJBQWlCekMsYUFBYTBDLElBQUtSLFVBQ3ZDN0MsTUFBTXNELE9BQ0osR0FBR25ELFlBQVksVUFBVWUsUUFBUSxjQUFjcUMsbUJBQzdDVixJQUNGLENBQUMsRUFDSCxDQUNGO0FBR0EsWUFBTVcsUUFBUUMsSUFBSUwsY0FBYztBQUdoQzNDLHFCQUNHZ0MsVUFDQyxJQUFJL0IsSUFBSSxDQUFDLEdBQUcrQixJQUFJLEVBQUVPLE9BQVFILFVBQVMsQ0FBQ2xDLGFBQWFtQyxTQUFTRCxJQUFJLENBQUMsQ0FBQyxDQUNwRTtBQUNBakMsc0JBQWdCLEVBQUU7QUFBQSxJQUNwQixTQUFTK0IsS0FBSztBQUNaLFVBQUkzQyxNQUFNeUIsYUFBYVYsS0FBSyxHQUFHO0FBQzdCLGNBQU1XLFdBQVdYLE1BQU1NLFVBQVVHLE1BQU1HLFdBQVdaLE1BQU1ZO0FBQ3hEWCxpQkFBUyxtQ0FBbUNVLFFBQVEsRUFBRTtBQUN0REUsZ0JBQVFiLE1BQU0sZ0JBQWdCQSxNQUFNTSxVQUFVRyxRQUFRVCxNQUFNWSxPQUFPO0FBQUEsTUFDckUsT0FBTztBQUNMWCxpQkFBUywyREFBMkQ7QUFDcEVZLGdCQUFRYixNQUFNLHFCQUFxQkEsS0FBSztBQUFBLE1BQzFDO0FBQUEsSUFDRjtBQUFBLEVBQ0Y7QUFFQSxRQUFNMkMsa0JBQWtCQSxNQUFNO0FBQzVCekMsYUFBUyxHQUFHO0FBQUEsRUFDZDtBQUVBLE1BQUksQ0FBQ0UsbUJBQW1CO0FBQ3RCLFdBQ0UsdUJBQUMsU0FDQyxpQ0FBQyxRQUFHLFdBQVUsU0FBUSx1Q0FBdEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUE2QyxLQUQvQztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBRUE7QUFBQSxFQUVKO0FBRUEsU0FDRSx1QkFBQyxTQUNDO0FBQUEsMkJBQUMsUUFBRyxXQUFVLFNBQVEsb0NBQXRCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBMEM7QUFBQSxJQUd6Q0osU0FDQyx1QkFBQyxPQUNDLElBQUk7QUFBQSxNQUNGNEMsUUFBUTtBQUFBLE1BQ1JDLFNBQVM7QUFBQSxNQUNUQyxpQkFBaUI7QUFBQSxNQUNqQkMsT0FBTztBQUFBLE1BQ1BDLGNBQWM7QUFBQSxJQUNoQixHQUVDaEQsbUJBVEg7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQVVBO0FBQUEsSUFJREYsWUFDQyx1QkFBQyxPQUFJLElBQUk7QUFBQSxNQUFFOEMsUUFBUTtBQUFBLE1BQUdLLFdBQVc7QUFBQSxJQUFTLEdBQUcsMkNBQTdDO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FFQSxJQUVBLG1DQUVFO0FBQUEsNkJBQUMsT0FDQyxJQUFJO0FBQUEsUUFDRkwsUUFBUTtBQUFBLFFBQ1JNLFNBQVM7QUFBQSxRQUNUQyxnQkFBZ0I7QUFBQSxNQUNsQixHQUVBO0FBQUEsK0JBQUMsYUFDQyxjQUFXLGtCQUNYLE9BQU0sa0JBQ04sU0FBUSxZQUNSLE9BQU81RCxZQUNQLFVBQVV1QixtQkFDVixJQUFJO0FBQUEsVUFBRXNDLGFBQWE7QUFBQSxRQUFFLEtBTnZCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFNeUI7QUFBQSxRQUV6Qix1QkFBQyxVQUNDLGNBQVcsV0FDWCxTQUFRLGFBQ1IsT0FBTSxXQUNOLFNBQVNsQyxvQkFDVCxJQUFJO0FBQUEsVUFDRjBCLFFBQVE7QUFBQSxVQUNSQyxTQUFTO0FBQUEsUUFDWCxHQUNELG1CQVREO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFXQTtBQUFBLFdBMUJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUEyQkE7QUFBQSxNQUdBLHVCQUFDLE9BQ0MsSUFBSTtBQUFBLFFBQ0ZELFFBQVE7QUFBQSxRQUNSTSxTQUFTO0FBQUEsUUFDVEMsZ0JBQWdCO0FBQUEsUUFDaEJFLFVBQVU7QUFBQSxNQUNaLEdBRUMsV0FBQyxHQUFHNUQsV0FBVyxFQUFFNkMsSUFBSSxDQUFDUixNQUFNd0IsVUFDM0IsdUJBQUMsVUFFQyxTQUFRLFlBQ1IsSUFBSTtBQUFBLFFBQ0ZWLFFBQVE7QUFBQSxRQUNSVyxXQUFXM0QsYUFBYW1DLFNBQVNELElBQUksSUFDakMsb0NBQ0E7QUFBQSxRQUNKZ0IsaUJBQWlCbEQsYUFBYW1DLFNBQVNELElBQUksSUFDdkMsWUFDQTtBQUFBO0FBQUEsUUFDSmlCLE9BQU9uRCxhQUFhbUMsU0FBU0QsSUFBSSxJQUM3QixVQUNBO0FBQUE7QUFBQSxRQUNKMEIsV0FBVzVELGFBQWFtQyxTQUFTRCxJQUFJLElBQ2pDLGdCQUNBO0FBQUE7QUFBQSxRQUNKMkIsZUFBZTtBQUFBLE1BQ2pCLEdBQ0EsU0FBUyxNQUFNNUIsZ0JBQWdCQyxJQUFJLEdBRWxDQSxrQkFwQkl3QixPQURQO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFzQkEsQ0FDRCxLQWhDSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBaUNBO0FBQUEsTUFFQSx1QkFBQyxPQUNDLElBQUk7QUFBQSxRQUNGSSxXQUFXO0FBQUEsUUFDWFIsU0FBUztBQUFBLFFBQ1RDLGdCQUFnQjtBQUFBLE1BQ2xCLEdBR0E7QUFBQSwrQkFBQyxPQUFJLElBQUk7QUFBQSxVQUFFTyxXQUFXO0FBQUEsUUFBRSxHQUN0QixpQ0FBQyxVQUNDLGNBQVcsY0FDWCxTQUFRLGFBQ1IsT0FBTSxXQUNOLFNBQVN2QixtQkFDVCxVQUFVdkMsYUFBYXdDLFdBQVcsR0FDbkMsc0JBTkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVFBLEtBVEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVVBO0FBQUEsUUFHQSx1QkFBQyxPQUFJLElBQUk7QUFBQSxVQUFFc0IsV0FBVztBQUFBLFFBQUUsR0FDdEIsaUNBQUMsVUFDQyxjQUFXLFlBQ1gsU0FBUSxhQUNSLE9BQU0sYUFDTixTQUFTZixpQkFDVixvQkFMRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBT0EsS0FSRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBU0E7QUFBQSxXQTlCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBK0JBO0FBQUEsU0FsR0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQW1HQTtBQUFBLE9BM0hKO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0E2SEE7QUFFSjtBQUFDckQsR0FsUlFELHFCQUFtQjtBQUFBLFVBTVRILGFBQ3VCQyxjQUFjO0FBQUE7QUFBQXdFLEtBUC9DdEU7QUFvUlQsZUFBZUE7QUFBb0IsSUFBQXNFO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJCb3giLCJCdXR0b24iLCJUZXh0RmllbGQiLCJ1c2VTdGF0ZSIsInVzZUVmZmVjdCIsImF4aW9zIiwidXNlTmF2aWdhdGUiLCJ1c2VVc2VyQ29udGV4dCIsIkFQSV9CQVNFX1VSTCIsIkludmVudG9yeU1hbmFnZW1lbnQiLCJfcyIsImlucHV0VmFsdWUiLCJzZXRJbnB1dFZhbHVlIiwiaW5ncmVkaWVudHMiLCJzZXRJbmdyZWRpZW50cyIsIlNldCIsImNsaWNrZWRJdGVtcyIsInNldENsaWNrZWRJdGVtcyIsImlzTG9hZGluZyIsInNldElzTG9hZGluZyIsImVycm9yIiwic2V0RXJyb3IiLCJuYXZpZ2F0ZSIsInVzZXJuYW1lIiwiaXNQcm9maWxlQ29tcGxldGUiLCJmZXRjaEluZ3JlZGllbnRzIiwicmVzcG9uc2UiLCJnZXQiLCJpbmdyZWRpZW50TGlzdCIsImRhdGEiLCJpc0F4aW9zRXJyb3IiLCJlcnJvck1zZyIsIm1lc3NhZ2UiLCJjb25zb2xlIiwiaGFuZGxlSW5wdXRDaGFuZ2UiLCJlIiwidGFyZ2V0IiwidmFsdWUiLCJoYW5kbGVDb25maXJtQ2xpY2siLCJsb3dlckNhc2VJdGVtIiwidG9Mb3dlckNhc2UiLCJ0cmltIiwic29tZSIsImluZ3JlZGllbnQiLCJwb3N0IiwiaW5ncmVkaWVudE5hbWUiLCJwcmV2IiwiYWRkIiwiZXJyIiwiaGFuZGxlSXRlbUNsaWNrIiwiaXRlbSIsImluY2x1ZGVzIiwicHJldkl0ZW1zIiwiZmlsdGVyIiwib3RoZXJJdGVtIiwiaGFuZGxlRGVsZXRlSXRlbXMiLCJsZW5ndGgiLCJkZWxldGVSZXF1ZXN0cyIsIm1hcCIsImRlbGV0ZSIsImVuY29kZVVSSUNvbXBvbmVudCIsIlByb21pc2UiLCJhbGwiLCJoYW5kbGVEb25lQ2xpY2siLCJtYXJnaW4iLCJwYWRkaW5nIiwiYmFja2dyb3VuZENvbG9yIiwiY29sb3IiLCJib3JkZXJSYWRpdXMiLCJ0ZXh0QWxpZ24iLCJkaXNwbGF5IiwianVzdGlmeUNvbnRlbnQiLCJtYXJnaW5SaWdodCIsImZsZXhXcmFwIiwiaW5kZXgiLCJib3hTaGFkb3ciLCJ0cmFuc2Zvcm0iLCJ0ZXh0VHJhbnNmb3JtIiwibWFyZ2luVG9wIiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJJbnZlbnRvcnlNYW5hZ2VtZW50LnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBCb3gsIEJ1dHRvbiwgVGV4dEZpZWxkIH0gZnJvbSBcIkBtdWkvbWF0ZXJpYWxcIjtcclxuaW1wb3J0IHsgdXNlU3RhdGUsIHVzZUVmZmVjdCB9IGZyb20gXCJyZWFjdFwiO1xyXG5pbXBvcnQgYXhpb3MgZnJvbSBcImF4aW9zXCI7XHJcbmltcG9ydCB7IHVzZU5hdmlnYXRlIH0gZnJvbSBcInJlYWN0LXJvdXRlci1kb21cIjtcclxuaW1wb3J0IHsgdXNlVXNlckNvbnRleHQgfSBmcm9tIFwiLi4vY29udGV4dHMvVXNlckNvbnRleHRcIjtcclxuaW1wb3J0IFwiLi4vc3R5bGVzL0ludmVudG9yeU1hbmFnZW1lbnQuY3NzXCI7XHJcblxyXG5jb25zdCBBUElfQkFTRV9VUkwgPSBcImh0dHA6Ly9sb2NhbGhvc3Q6ODA4MC9hcGlcIjtcclxuXHJcbmZ1bmN0aW9uIEludmVudG9yeU1hbmFnZW1lbnQoKSB7XHJcbiAgY29uc3QgW2lucHV0VmFsdWUsIHNldElucHV0VmFsdWVdID0gdXNlU3RhdGUoXCJcIik7XHJcbiAgY29uc3QgW2luZ3JlZGllbnRzLCBzZXRJbmdyZWRpZW50c10gPSB1c2VTdGF0ZTxTZXQ8c3RyaW5nPj4obmV3IFNldCgpKTtcclxuICBjb25zdCBbY2xpY2tlZEl0ZW1zLCBzZXRDbGlja2VkSXRlbXNdID0gdXNlU3RhdGU8c3RyaW5nW10+KFtdKTtcclxuICBjb25zdCBbaXNMb2FkaW5nLCBzZXRJc0xvYWRpbmddID0gdXNlU3RhdGUodHJ1ZSk7XHJcbiAgY29uc3QgW2Vycm9yLCBzZXRFcnJvcl0gPSB1c2VTdGF0ZTxzdHJpbmcgfCBudWxsPihudWxsKTtcclxuICBjb25zdCBuYXZpZ2F0ZSA9IHVzZU5hdmlnYXRlKCk7XHJcbiAgY29uc3QgeyB1c2VybmFtZSwgaXNQcm9maWxlQ29tcGxldGUgfSA9IHVzZVVzZXJDb250ZXh0KCk7XHJcblxyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBpZiAodXNlcm5hbWUgJiYgaXNQcm9maWxlQ29tcGxldGUpIHtcclxuICAgICAgZmV0Y2hJbmdyZWRpZW50cygpO1xyXG4gICAgfVxyXG4gIH0sIFt1c2VybmFtZSwgaXNQcm9maWxlQ29tcGxldGVdKTtcclxuXHJcbiAgY29uc3QgZmV0Y2hJbmdyZWRpZW50cyA9IGFzeW5jICgpID0+IHtcclxuICAgIHNldElzTG9hZGluZyh0cnVlKTtcclxuICAgIHNldEVycm9yKG51bGwpO1xyXG5cclxuICAgIHRyeSB7XHJcbiAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgYXhpb3MuZ2V0KFxyXG4gICAgICAgIGAke0FQSV9CQVNFX1VSTH0vdXNlcnMvJHt1c2VybmFtZX0vaW52ZW50b3J5YFxyXG4gICAgICApO1xyXG5cclxuICAgICAgY29uc3QgaW5ncmVkaWVudExpc3Q6IHN0cmluZ1tdID0gcmVzcG9uc2UuZGF0YTtcclxuICAgICAgc2V0SW5ncmVkaWVudHMobmV3IFNldChpbmdyZWRpZW50TGlzdCkpO1xyXG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgLy8gQXhpb3MgZXJyb3IgaGFuZGxpbmdcclxuICAgICAgaWYgKGF4aW9zLmlzQXhpb3NFcnJvcihlcnJvcikpIHtcclxuICAgICAgICBjb25zdCBlcnJvck1zZyA9IGVycm9yLnJlc3BvbnNlPy5kYXRhPy5tZXNzYWdlIHx8IGVycm9yLm1lc3NhZ2U7XHJcbiAgICAgICAgc2V0RXJyb3IoYEZhaWxlZCB0byBmZXRjaCBpbmdyZWRpZW50czogJHtlcnJvck1zZ31gKTtcclxuICAgICAgICBjb25zb2xlLmVycm9yKFwiQXhpb3MgZXJyb3I6XCIsIGVycm9yLnJlc3BvbnNlPy5kYXRhIHx8IGVycm9yLm1lc3NhZ2UpO1xyXG4gICAgICB9IGVsc2Uge1xyXG4gICAgICAgIHNldEVycm9yKFwiQW4gdW5leHBlY3RlZCBlcnJvciBvY2N1cnJlZCB3aGlsZSBmZXRjaGluZyBpbmdyZWRpZW50c1wiKTtcclxuICAgICAgICBjb25zb2xlLmVycm9yKFwiVW5leHBlY3RlZCBlcnJvcjpcIiwgZXJyb3IpO1xyXG4gICAgICB9XHJcbiAgICB9IGZpbmFsbHkge1xyXG4gICAgICBzZXRJc0xvYWRpbmcoZmFsc2UpO1xyXG4gICAgfVxyXG4gIH07XHJcblxyXG4gIGNvbnN0IGhhbmRsZUlucHV0Q2hhbmdlID0gKGU6IFJlYWN0LkNoYW5nZUV2ZW50PEhUTUxJbnB1dEVsZW1lbnQ+KSA9PiB7XHJcbiAgICBzZXRJbnB1dFZhbHVlKGUudGFyZ2V0LnZhbHVlKTtcclxuICB9O1xyXG5cclxuICBjb25zdCBoYW5kbGVDb25maXJtQ2xpY2sgPSBhc3luYyAoKSA9PiB7XHJcbiAgICBpZiAoIXVzZXJuYW1lIHx8ICFpc1Byb2ZpbGVDb21wbGV0ZSkge1xyXG4gICAgICBzZXRFcnJvcihcIk5vIHVzZXIgYXZhaWxhYmxlXCIpO1xyXG4gICAgICByZXR1cm47XHJcbiAgICB9XHJcblxyXG4gICAgY29uc3QgbG93ZXJDYXNlSXRlbSA9IGlucHV0VmFsdWUudG9Mb3dlckNhc2UoKTtcclxuXHJcbiAgICBpZiAoXHJcbiAgICAgIGlucHV0VmFsdWUudHJpbSgpICE9PSBcIlwiICYmXHJcbiAgICAgICFbLi4uaW5ncmVkaWVudHNdLnNvbWUoXHJcbiAgICAgICAgKGluZ3JlZGllbnQpID0+IGluZ3JlZGllbnQudG9Mb3dlckNhc2UoKSA9PT0gbG93ZXJDYXNlSXRlbVxyXG4gICAgICApXHJcbiAgICApIHtcclxuICAgICAgdHJ5IHtcclxuICAgICAgICBhd2FpdCBheGlvcy5wb3N0KGAke0FQSV9CQVNFX1VSTH0vdXNlcnMvJHt1c2VybmFtZX0vaW52ZW50b3J5YCwge1xyXG4gICAgICAgICAgaW5ncmVkaWVudE5hbWU6IGlucHV0VmFsdWUsXHJcbiAgICAgICAgfSk7XHJcblxyXG4gICAgICAgIC8vIHVwZGF0ZSBmcm9udC1lbmRcclxuICAgICAgICBzZXRJbmdyZWRpZW50cygocHJldikgPT4gbmV3IFNldChwcmV2LmFkZChpbnB1dFZhbHVlKSkpO1xyXG4gICAgICAgIHNldElucHV0VmFsdWUoXCJcIik7XHJcbiAgICAgICAgc2V0RXJyb3IobnVsbCk7XHJcbiAgICAgIH0gY2F0Y2ggKGVycikge1xyXG4gICAgICAgIGlmIChheGlvcy5pc0F4aW9zRXJyb3IoZXJyb3IpKSB7XHJcbiAgICAgICAgICBjb25zdCBlcnJvck1zZyA9IGVycm9yLnJlc3BvbnNlPy5kYXRhPy5tZXNzYWdlIHx8IGVycm9yLm1lc3NhZ2U7XHJcbiAgICAgICAgICBzZXRFcnJvcihgRmFpbGVkIHRvIGFkZCBpbmdyZWRpZW50OiAke2Vycm9yTXNnfWApO1xyXG4gICAgICAgICAgY29uc29sZS5lcnJvcihcIkF4aW9zIGVycm9yOlwiLCBlcnJvci5yZXNwb25zZT8uZGF0YSB8fCBlcnJvci5tZXNzYWdlKTtcclxuICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgc2V0RXJyb3IoXCJBbiB1bmV4cGVjdGVkIGVycm9yIG9jY3VycmVkIHdoaWxlIGFkZGluZyBpbmdyZWRpZW50XCIpO1xyXG4gICAgICAgICAgY29uc29sZS5lcnJvcihcIlVuZXhwZWN0ZWQgZXJyb3I6XCIsIGVycm9yKTtcclxuICAgICAgICB9XHJcbiAgICAgIH1cclxuICAgIH1cclxuICB9O1xyXG5cclxuICBjb25zdCBoYW5kbGVJdGVtQ2xpY2sgPSAoaXRlbTogc3RyaW5nKSA9PiB7XHJcbiAgICBpZiAoY2xpY2tlZEl0ZW1zLmluY2x1ZGVzKGl0ZW0pKSB7XHJcbiAgICAgIHNldENsaWNrZWRJdGVtcygocHJldkl0ZW1zKSA9PlxyXG4gICAgICAgIHByZXZJdGVtcy5maWx0ZXIoKG90aGVySXRlbSkgPT4gb3RoZXJJdGVtICE9PSBpdGVtKVxyXG4gICAgICApO1xyXG4gICAgfSBlbHNlIHtcclxuICAgICAgc2V0Q2xpY2tlZEl0ZW1zKChwcmV2KSA9PiBbLi4ucHJldiwgaXRlbV0pO1xyXG4gICAgfVxyXG4gIH07XHJcblxyXG4gIGNvbnN0IGhhbmRsZURlbGV0ZUl0ZW1zID0gYXN5bmMgKCkgPT4ge1xyXG4gICAgaWYgKCF1c2VybmFtZSB8fCAhaXNQcm9maWxlQ29tcGxldGUpIHtcclxuICAgICAgc2V0RXJyb3IoXCJObyB1c2VyIGF2YWlsYWJsZVwiKTtcclxuICAgICAgcmV0dXJuO1xyXG4gICAgfVxyXG5cclxuICAgIGlmIChjbGlja2VkSXRlbXMubGVuZ3RoID09PSAwKSB7XHJcbiAgICAgIHJldHVybjtcclxuICAgIH1cclxuXHJcbiAgICBzZXRFcnJvcihudWxsKTtcclxuXHJcbiAgICB0cnkge1xyXG4gICAgICAvLyBDcmVhdGUgYW4gYXJyYXkgb2YgZGVsZXRlIHJlcXVlc3RzXHJcbiAgICAgIGNvbnN0IGRlbGV0ZVJlcXVlc3RzID0gY2xpY2tlZEl0ZW1zLm1hcCgoaXRlbSkgPT5cclxuICAgICAgICBheGlvcy5kZWxldGUoXHJcbiAgICAgICAgICBgJHtBUElfQkFTRV9VUkx9L3VzZXJzLyR7dXNlcm5hbWV9L2ludmVudG9yeS8ke2VuY29kZVVSSUNvbXBvbmVudChcclxuICAgICAgICAgICAgaXRlbVxyXG4gICAgICAgICAgKX1gXHJcbiAgICAgICAgKVxyXG4gICAgICApO1xyXG5cclxuICAgICAgLy8gRXhlY3V0ZSBhbGwgcmVxdWVzdHMgaW4gcGFyYWxsZWxcclxuICAgICAgYXdhaXQgUHJvbWlzZS5hbGwoZGVsZXRlUmVxdWVzdHMpO1xyXG5cclxuICAgICAgLy8gdXBkYXRlIGZyb250LWVuZCBzdGF0ZVxyXG4gICAgICBzZXRJbmdyZWRpZW50cyhcclxuICAgICAgICAocHJldikgPT5cclxuICAgICAgICAgIG5ldyBTZXQoWy4uLnByZXZdLmZpbHRlcigoaXRlbSkgPT4gIWNsaWNrZWRJdGVtcy5pbmNsdWRlcyhpdGVtKSkpXHJcbiAgICAgICk7XHJcbiAgICAgIHNldENsaWNrZWRJdGVtcyhbXSk7XHJcbiAgICB9IGNhdGNoIChlcnIpIHtcclxuICAgICAgaWYgKGF4aW9zLmlzQXhpb3NFcnJvcihlcnJvcikpIHtcclxuICAgICAgICBjb25zdCBlcnJvck1zZyA9IGVycm9yLnJlc3BvbnNlPy5kYXRhPy5tZXNzYWdlIHx8IGVycm9yLm1lc3NhZ2U7XHJcbiAgICAgICAgc2V0RXJyb3IoYEZhaWxlZCB0byBkZWxldGUgaW5ncmVkaWVudChzKTogJHtlcnJvck1zZ31gKTtcclxuICAgICAgICBjb25zb2xlLmVycm9yKFwiQXhpb3MgZXJyb3I6XCIsIGVycm9yLnJlc3BvbnNlPy5kYXRhIHx8IGVycm9yLm1lc3NhZ2UpO1xyXG4gICAgICB9IGVsc2Uge1xyXG4gICAgICAgIHNldEVycm9yKFwiQW4gdW5leHBlY3RlZCBlcnJvciBvY2N1cnJlZCB3aGlsZSBkZWxldGluZyBpbmdyZWRpZW50KHMpXCIpO1xyXG4gICAgICAgIGNvbnNvbGUuZXJyb3IoXCJVbmV4cGVjdGVkIGVycm9yOlwiLCBlcnJvcik7XHJcbiAgICAgIH1cclxuICAgIH1cclxuICB9O1xyXG5cclxuICBjb25zdCBoYW5kbGVEb25lQ2xpY2sgPSAoKSA9PiB7XHJcbiAgICBuYXZpZ2F0ZShcIi9cIik7XHJcbiAgfTtcclxuXHJcbiAgaWYgKCFpc1Byb2ZpbGVDb21wbGV0ZSkge1xyXG4gICAgcmV0dXJuIChcclxuICAgICAgPGRpdj5cclxuICAgICAgICA8aDEgY2xhc3NOYW1lPVwidGl0bGVcIj5Mb2FkaW5nIFVzZXIgUHJvZmlsZS4uLjwvaDE+XHJcbiAgICAgIDwvZGl2PlxyXG4gICAgKTtcclxuICB9XHJcblxyXG4gIHJldHVybiAoXHJcbiAgICA8ZGl2PlxyXG4gICAgICA8aDEgY2xhc3NOYW1lPVwidGl0bGVcIj5JbnZlbnRvcnkgTWFuYWdlbWVudDwvaDE+XHJcblxyXG4gICAgICB7LyogRGlzcGxheSBlcnJvciBtZXNzYWdlIGlmIHRoZXJlIGlzIG9uZSAqL31cclxuICAgICAge2Vycm9yICYmIChcclxuICAgICAgICA8Qm94XHJcbiAgICAgICAgICBzeD17e1xyXG4gICAgICAgICAgICBtYXJnaW46IDIsXHJcbiAgICAgICAgICAgIHBhZGRpbmc6IDIsXHJcbiAgICAgICAgICAgIGJhY2tncm91bmRDb2xvcjogXCIjZmZlYmVlXCIsXHJcbiAgICAgICAgICAgIGNvbG9yOiBcIiNjNjI4MjhcIixcclxuICAgICAgICAgICAgYm9yZGVyUmFkaXVzOiAxLFxyXG4gICAgICAgICAgfX1cclxuICAgICAgICA+XHJcbiAgICAgICAgICB7ZXJyb3J9XHJcbiAgICAgICAgPC9Cb3g+XHJcbiAgICAgICl9XHJcblxyXG4gICAgICB7LyogTG9hZGluZyBpbmRpY2F0b3IgKi99XHJcbiAgICAgIHtpc0xvYWRpbmcgPyAoXHJcbiAgICAgICAgPEJveCBzeD17eyBtYXJnaW46IDQsIHRleHRBbGlnbjogXCJjZW50ZXJcIiB9fT5cclxuICAgICAgICAgIExvYWRpbmcgeW91ciBpbmdyZWRpZW50cy4uLlxyXG4gICAgICAgIDwvQm94PlxyXG4gICAgICApIDogKFxyXG4gICAgICAgIDw+XHJcbiAgICAgICAgICB7LyogaW5wdXQgYm94IGZvciBhZGRpbmcgaW5ncmVkaWVudCAqL31cclxuICAgICAgICAgIDxCb3hcclxuICAgICAgICAgICAgc3g9e3tcclxuICAgICAgICAgICAgICBtYXJnaW46IDIsXHJcbiAgICAgICAgICAgICAgZGlzcGxheTogXCJmbGV4XCIsXHJcbiAgICAgICAgICAgICAganVzdGlmeUNvbnRlbnQ6IFwiY2VudGVyXCIsXHJcbiAgICAgICAgICAgIH19XHJcbiAgICAgICAgICA+XHJcbiAgICAgICAgICAgIDxUZXh0RmllbGRcclxuICAgICAgICAgICAgICBhcmlhLWxhYmVsPVwiYWRkLWluZ3JlZGllbnRcIlxyXG4gICAgICAgICAgICAgIGxhYmVsPVwiYWRkIGluZ3JlZGllbnRcIlxyXG4gICAgICAgICAgICAgIHZhcmlhbnQ9XCJvdXRsaW5lZFwiXHJcbiAgICAgICAgICAgICAgdmFsdWU9e2lucHV0VmFsdWV9XHJcbiAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZUlucHV0Q2hhbmdlfVxyXG4gICAgICAgICAgICAgIHN4PXt7IG1hcmdpblJpZ2h0OiAyIH19XHJcbiAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgIDxCdXR0b25cclxuICAgICAgICAgICAgICBhcmlhLWxhYmVsPVwiYWRkLWJ0blwiXHJcbiAgICAgICAgICAgICAgdmFyaWFudD1cImNvbnRhaW5lZFwiXHJcbiAgICAgICAgICAgICAgY29sb3I9XCJwcmltYXJ5XCJcclxuICAgICAgICAgICAgICBvbkNsaWNrPXtoYW5kbGVDb25maXJtQ2xpY2t9XHJcbiAgICAgICAgICAgICAgc3g9e3tcclxuICAgICAgICAgICAgICAgIG1hcmdpbjogMSxcclxuICAgICAgICAgICAgICAgIHBhZGRpbmc6IDEsXHJcbiAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgIEFkZFxyXG4gICAgICAgICAgICA8L0J1dHRvbj5cclxuICAgICAgICAgIDwvQm94PlxyXG5cclxuICAgICAgICAgIHsvKiBzaG93IGluZ3JlZGllbnRzICovfVxyXG4gICAgICAgICAgPEJveFxyXG4gICAgICAgICAgICBzeD17e1xyXG4gICAgICAgICAgICAgIG1hcmdpbjogNixcclxuICAgICAgICAgICAgICBkaXNwbGF5OiBcImZsZXhcIixcclxuICAgICAgICAgICAgICBqdXN0aWZ5Q29udGVudDogXCJjZW50ZXJcIixcclxuICAgICAgICAgICAgICBmbGV4V3JhcDogXCJ3cmFwXCIsXHJcbiAgICAgICAgICAgIH19XHJcbiAgICAgICAgICA+XHJcbiAgICAgICAgICAgIHtbLi4uaW5ncmVkaWVudHNdLm1hcCgoaXRlbSwgaW5kZXgpID0+IChcclxuICAgICAgICAgICAgICA8QnV0dG9uXHJcbiAgICAgICAgICAgICAgICBrZXk9e2luZGV4fVxyXG4gICAgICAgICAgICAgICAgdmFyaWFudD1cIm91dGxpbmVkXCJcclxuICAgICAgICAgICAgICAgIHN4PXt7XHJcbiAgICAgICAgICAgICAgICAgIG1hcmdpbjogMSxcclxuICAgICAgICAgICAgICAgICAgYm94U2hhZG93OiBjbGlja2VkSXRlbXMuaW5jbHVkZXMoaXRlbSlcclxuICAgICAgICAgICAgICAgICAgICA/IFwiMHB4IDhweCAxNnB4IHJnYmEoMCwgMCwgMCwgMC4zKVwiXHJcbiAgICAgICAgICAgICAgICAgICAgOiBcIjBweCA0cHggOHB4IHJnYmEoMCwgMCwgMCwgMC4xKVwiLFxyXG4gICAgICAgICAgICAgICAgICBiYWNrZ3JvdW5kQ29sb3I6IGNsaWNrZWRJdGVtcy5pbmNsdWRlcyhpdGVtKVxyXG4gICAgICAgICAgICAgICAgICAgID8gXCIjNENBRjUwXCIgLy8gYmFja2dyb3VuZCBjb2xvciBmb3IgdGhlIGNsaWNrZWQgaXRlbVxyXG4gICAgICAgICAgICAgICAgICAgIDogXCJ0cmFuc3BhcmVudFwiLCAvLyBkZWZhdWx0IGJhY2tncm91bmQgY29sb3JcclxuICAgICAgICAgICAgICAgICAgY29sb3I6IGNsaWNrZWRJdGVtcy5pbmNsdWRlcyhpdGVtKVxyXG4gICAgICAgICAgICAgICAgICAgID8gXCJ3aGl0ZVwiIC8vIGNvbG9yIGZvciBjbGlja2VkIHRleHRcclxuICAgICAgICAgICAgICAgICAgICA6IFwiYmxhY2tcIiwgLy8gZGVmYXVsdCBjb2xvciBmb3IgdGV4dFxyXG4gICAgICAgICAgICAgICAgICB0cmFuc2Zvcm06IGNsaWNrZWRJdGVtcy5pbmNsdWRlcyhpdGVtKVxyXG4gICAgICAgICAgICAgICAgICAgID8gXCJzY2FsZSgwLjk1KVwiIC8vIHNjYWxlIGVmZmVjdCBhZnRlciBjbGlja2VkXHJcbiAgICAgICAgICAgICAgICAgICAgOiBcIm5vbmVcIiwgLy8gZGVmYXVsdCBzY2FsZSBlZmZlY3RcclxuICAgICAgICAgICAgICAgICAgdGV4dFRyYW5zZm9ybTogXCJub25lXCIsXHJcbiAgICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gaGFuZGxlSXRlbUNsaWNrKGl0ZW0pfVxyXG4gICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgIHtpdGVtfVxyXG4gICAgICAgICAgICAgIDwvQnV0dG9uPlxyXG4gICAgICAgICAgICApKX1cclxuICAgICAgICAgIDwvQm94PlxyXG5cclxuICAgICAgICAgIDxCb3hcclxuICAgICAgICAgICAgc3g9e3tcclxuICAgICAgICAgICAgICBtYXJnaW5Ub3A6IDEwLFxyXG4gICAgICAgICAgICAgIGRpc3BsYXk6IFwiZmxleFwiLFxyXG4gICAgICAgICAgICAgIGp1c3RpZnlDb250ZW50OiBcInNwYWNlLWFyb3VuZFwiLFxyXG4gICAgICAgICAgICB9fVxyXG4gICAgICAgICAgPlxyXG4gICAgICAgICAgICB7LyogRGVsZXRlIGJ1dHRvbiBmb3IgY2xpY2tlZCBpdGVtcyAqL31cclxuICAgICAgICAgICAgPEJveCBzeD17eyBtYXJnaW5Ub3A6IDIgfX0+XHJcbiAgICAgICAgICAgICAgPEJ1dHRvblxyXG4gICAgICAgICAgICAgICAgYXJpYS1sYWJlbD1cImRlbGV0ZS1idG5cIlxyXG4gICAgICAgICAgICAgICAgdmFyaWFudD1cImNvbnRhaW5lZFwiXHJcbiAgICAgICAgICAgICAgICBjb2xvcj1cInByaW1hcnlcIlxyXG4gICAgICAgICAgICAgICAgb25DbGljaz17aGFuZGxlRGVsZXRlSXRlbXN9XHJcbiAgICAgICAgICAgICAgICBkaXNhYmxlZD17Y2xpY2tlZEl0ZW1zLmxlbmd0aCA9PT0gMH1cclxuICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICBERUxFVEVcclxuICAgICAgICAgICAgICA8L0J1dHRvbj5cclxuICAgICAgICAgICAgPC9Cb3g+XHJcblxyXG4gICAgICAgICAgICB7LyogRG9uZSBidXR0b24gd2lsbCBicmluZyB1c2VycyBiYWNrIHRvIHRoZSBob21lIHBhZ2UgKi99XHJcbiAgICAgICAgICAgIDxCb3ggc3g9e3sgbWFyZ2luVG9wOiAyIH19PlxyXG4gICAgICAgICAgICAgIDxCdXR0b25cclxuICAgICAgICAgICAgICAgIGFyaWEtbGFiZWw9XCJkb25lLWJ0blwiXHJcbiAgICAgICAgICAgICAgICB2YXJpYW50PVwiY29udGFpbmVkXCJcclxuICAgICAgICAgICAgICAgIGNvbG9yPVwic2Vjb25kYXJ5XCJcclxuICAgICAgICAgICAgICAgIG9uQ2xpY2s9e2hhbmRsZURvbmVDbGlja31cclxuICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICBEb25lXHJcbiAgICAgICAgICAgICAgPC9CdXR0b24+XHJcbiAgICAgICAgICAgIDwvQm94PlxyXG4gICAgICAgICAgPC9Cb3g+XHJcbiAgICAgICAgPC8+XHJcbiAgICAgICl9XHJcbiAgICA8L2Rpdj5cclxuICApO1xyXG59XHJcblxyXG5leHBvcnQgZGVmYXVsdCBJbnZlbnRvcnlNYW5hZ2VtZW50O1xyXG4iXSwiZmlsZSI6IkM6L1VzZXJzL3NfbWFyL2NzMzIvU25hY2tTdGFjay9jbGllbnQvc3JjL3BhZ2VzL0ludmVudG9yeU1hbmFnZW1lbnQudHN4In0=