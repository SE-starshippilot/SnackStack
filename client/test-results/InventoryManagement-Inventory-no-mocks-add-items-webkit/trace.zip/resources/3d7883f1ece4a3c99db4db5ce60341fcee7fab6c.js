"use client";
import "/node_modules/.vite/deps/chunk-C6WWHQR7.js?v=4d3a3d4b";
import "/node_modules/.vite/deps/chunk-JQS66VEU.js?v=4d3a3d4b";
import {
  createSvgIcon
} from "/node_modules/.vite/deps/chunk-MLPXR4TV.js?v=4d3a3d4b";
import "/node_modules/.vite/deps/chunk-JFUJMKGI.js?v=4d3a3d4b";
import "/node_modules/.vite/deps/chunk-NTONOVYZ.js?v=4d3a3d4b";
import "/node_modules/.vite/deps/chunk-ZZNIRIXO.js?v=4d3a3d4b";
import "/node_modules/.vite/deps/chunk-TSMFREGN.js?v=4d3a3d4b";
import "/node_modules/.vite/deps/chunk-64FVIM6J.js?v=4d3a3d4b";
import {
  require_jsx_runtime
} from "/node_modules/.vite/deps/chunk-TOXUORXJ.js?v=4d3a3d4b";
import "/node_modules/.vite/deps/chunk-K5YNGTCN.js?v=4d3a3d4b";
import {
  __toESM
} from "/node_modules/.vite/deps/chunk-ZC22LKFR.js?v=4d3a3d4b";

// node_modules/@mui/icons-material/esm/History.js
var import_jsx_runtime = __toESM(require_jsx_runtime());
var History_default = createSvgIcon((0, import_jsx_runtime.jsx)("path", {
  d: "M13 3c-4.97 0-9 4.03-9 9H1l3.89 3.89.07.14L9 12H6c0-3.87 3.13-7 7-7s7 3.13 7 7-3.13 7-7 7c-1.93 0-3.68-.79-4.94-2.06l-1.42 1.42C8.27 19.99 10.51 21 13 21c4.97 0 9-4.03 9-9s-4.03-9-9-9m-1 5v5l4.28 2.54.72-1.21-3.5-2.08V8z"
}), "History");
export {
  History_default as default
};
//# sourceMappingURL=@mui_icons-material_History.js.map
