import.meta.env = {"VITE_CLERK_PUBLISHABLE_KEY":"pk_test_YW1wbGUtZmVycmV0LTIzLmNsZXJrLmFjY291bnRzLmRldiQ","VITE_DISABLE_AUTH":"false","BASE_URL":"/","MODE":"development","DEV":true,"PROD":false,"SSR":false};import { jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import __vite__cjsImport1_react from "/node_modules/.vite/deps/react.js?v=b14ee716"; const React = __vite__cjsImport1_react.__esModule ? __vite__cjsImport1_react.default : __vite__cjsImport1_react;
import __vite__cjsImport2_reactDom_client from "/node_modules/.vite/deps/react-dom_client.js?v=b14ee716"; const ReactDOM = __vite__cjsImport2_reactDom_client.__esModule ? __vite__cjsImport2_reactDom_client.default : __vite__cjsImport2_reactDom_client;
import App from "/src/components/App.tsx";
import "/src/styles/index.css";
import { ClerkProvider } from "/node_modules/.vite/deps/@clerk_clerk-react.js?v=b14ee716";
const PUBLISHABLE_KEY = import.meta.env.VITE_CLERK_PUBLISHABLE_KEY;
if (!PUBLISHABLE_KEY) {
  throw new Error("Missing Publishable Key");
}
ReactDOM.createRoot(document.getElementById("root")).render(/* @__PURE__ */ jsxDEV(React.StrictMode, { children: /* @__PURE__ */ jsxDEV(ClerkProvider, { publishableKey: PUBLISHABLE_KEY, afterSignInUrl: "/complete-profile", afterSignOutUrl: "/", children: /* @__PURE__ */ jsxDEV(App, {}, void 0, false, {
  fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/main.tsx",
  lineNumber: 14,
  columnNumber: 7
}, this) }, void 0, false, {
  fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/main.tsx",
  lineNumber: 13,
  columnNumber: 5
}, this) }, void 0, false, {
  fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/main.tsx",
  lineNumber: 12,
  columnNumber: 62
}, this));

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBdUJNO0FBdkJOLE9BQU9BLFdBQVc7QUFDbEIsT0FBT0MsY0FBYztBQUNyQixPQUFPQyxTQUFTO0FBQ2hCLE9BQU87QUFDUCxTQUFTQyxxQkFBcUI7QUFJOUIsTUFBTUMsa0JBQWtCQyxZQUFZQyxJQUFJQztBQUd4QyxJQUFJLENBQUNILGlCQUFpQjtBQUNwQixRQUFNLElBQUlJLE1BQU0seUJBQXlCO0FBQzNDO0FBR0FQLFNBQVNRLFdBQVdDLFNBQVNDLGVBQWUsTUFBTSxDQUFFLEVBQUVDLE9BQ3BELHVCQUFDLE1BQU0sWUFBTixFQUNDLGlDQUFDLGlCQUNDLGdCQUFnQlIsaUJBQ2hCLGdCQUFlLHFCQUNmLGlCQUFnQixLQUVoQixpQ0FBQyxTQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsT0FBSSxLQUxOO0FBQUE7QUFBQTtBQUFBO0FBQUEsT0FNQSxLQVBGO0FBQUE7QUFBQTtBQUFBO0FBQUEsT0FRQSxDQUNGIiwibmFtZXMiOlsiUmVhY3QiLCJSZWFjdERPTSIsIkFwcCIsIkNsZXJrUHJvdmlkZXIiLCJQVUJMSVNIQUJMRV9LRVkiLCJpbXBvcnQiLCJlbnYiLCJWSVRFX0NMRVJLX1BVQkxJU0hBQkxFX0tFWSIsIkVycm9yIiwiY3JlYXRlUm9vdCIsImRvY3VtZW50IiwiZ2V0RWxlbWVudEJ5SWQiLCJyZW5kZXIiXSwic291cmNlcyI6WyJtYWluLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3QgZnJvbSBcInJlYWN0XCI7XHJcbmltcG9ydCBSZWFjdERPTSBmcm9tIFwicmVhY3QtZG9tL2NsaWVudFwiO1xyXG5pbXBvcnQgQXBwIGZyb20gXCIuL2NvbXBvbmVudHMvQXBwXCI7XHJcbmltcG9ydCBcIi4vc3R5bGVzL2luZGV4LmNzc1wiO1xyXG5pbXBvcnQgeyBDbGVya1Byb3ZpZGVyIH0gZnJvbSBcIkBjbGVyay9jbGVyay1yZWFjdFwiO1xyXG5cclxuXHJcbi8vIEltcG9ydCB5b3VyIHB1Ymxpc2hhYmxlIGtleVxyXG5jb25zdCBQVUJMSVNIQUJMRV9LRVkgPSBpbXBvcnQubWV0YS5lbnYuVklURV9DTEVSS19QVUJMSVNIQUJMRV9LRVlcclxuXHJcblxyXG5pZiAoIVBVQkxJU0hBQkxFX0tFWSkge1xyXG4gIHRocm93IG5ldyBFcnJvcignTWlzc2luZyBQdWJsaXNoYWJsZSBLZXknKVxyXG59XHJcblxyXG5cclxuUmVhY3RET00uY3JlYXRlUm9vdChkb2N1bWVudC5nZXRFbGVtZW50QnlJZChcInJvb3RcIikhKS5yZW5kZXIoXHJcbiAgPFJlYWN0LlN0cmljdE1vZGU+XHJcbiAgICA8Q2xlcmtQcm92aWRlclxyXG4gICAgICBwdWJsaXNoYWJsZUtleT17UFVCTElTSEFCTEVfS0VZfVxyXG4gICAgICBhZnRlclNpZ25JblVybD1cIi9jb21wbGV0ZS1wcm9maWxlXCJcclxuICAgICAgYWZ0ZXJTaWduT3V0VXJsPVwiL1wiXHJcbiAgICA+XHJcbiAgICAgIDxBcHAgLz5cclxuICAgIDwvQ2xlcmtQcm92aWRlcj5cclxuICA8L1JlYWN0LlN0cmljdE1vZGU+XHJcbik7XHJcbiJdLCJmaWxlIjoiQzovVXNlcnMvc19tYXIvY3MzMi9TbmFja1N0YWNrL2NsaWVudC9zcmMvbWFpbi50c3gifQ==