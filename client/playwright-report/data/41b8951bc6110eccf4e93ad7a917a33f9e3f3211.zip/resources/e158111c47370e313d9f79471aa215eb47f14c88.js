import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/Profile.tsx");import { jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/s_mar/cs32/SnackStack/client/src/components/Profile.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import { useUser, RedirectToSignIn } from "/node_modules/.vite/deps/@clerk_clerk-react.js?v=b14ee716";
import __vite__cjsImport4_react from "/node_modules/.vite/deps/react.js?v=b14ee716"; const useState = __vite__cjsImport4_react["useState"]; const useEffect = __vite__cjsImport4_react["useEffect"];
import { useNavigate } from "/node_modules/.vite/deps/react-router-dom.js?v=b14ee716";
export default function Profile() {
  _s();
  const {
    user,
    isLoaded
  } = useUser();
  const [firstName, setFirstName] = useState("");
  const [lastName, setLastName] = useState("");
  const navigate = useNavigate();
  useEffect(() => {
    if (isLoaded && user) {
      setFirstName(user.firstName || "");
      setLastName(user.lastName || "");
    }
  }, [isLoaded, user]);
  if (!isLoaded)
    return null;
  if (!user)
    return /* @__PURE__ */ jsxDEV(RedirectToSignIn, {}, void 0, false, {
      fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/components/Profile.tsx",
      lineNumber: 22,
      columnNumber: 21
    }, this);
  const onSave = async (e) => {
    e.preventDefault();
    await user.update({
      firstName,
      lastName
    });
    navigate("/", {
      replace: true
    });
  };
  return /* @__PURE__ */ jsxDEV("div", { className: "profile-container", children: [
    /* @__PURE__ */ jsxDEV("h2", { children: "Complete Your Profile" }, void 0, false, {
      fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/components/Profile.tsx",
      lineNumber: 34,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("form", { onSubmit: onSave, className: "profile-form", children: [
      /* @__PURE__ */ jsxDEV("label", { children: [
        "First Name",
        /* @__PURE__ */ jsxDEV("input", { type: "text", value: firstName, onChange: (e) => setFirstName(e.target.value), required: true }, void 0, false, {
          fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/components/Profile.tsx",
          lineNumber: 38,
          columnNumber: 9
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/components/Profile.tsx",
        lineNumber: 36,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("label", { children: [
        "Last Name",
        /* @__PURE__ */ jsxDEV("input", { type: "text", value: lastName, onChange: (e) => setLastName(e.target.value), required: true }, void 0, false, {
          fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/components/Profile.tsx",
          lineNumber: 43,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/components/Profile.tsx",
        lineNumber: 41,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("button", { type: "submit", children: "Save & Continue" }, void 0, false, {
        fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/components/Profile.tsx",
        lineNumber: 46,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/components/Profile.tsx",
      lineNumber: 35,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/components/Profile.tsx",
    lineNumber: 33,
    columnNumber: 10
  }, this);
}
_s(Profile, "tq41sC/isbyY0bYUVJC80vzYW7E=", false, function() {
  return [useUser, useNavigate];
});
_c = Profile;
var _c;
$RefreshReg$(_c, "Profile");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/s_mar/cs32/SnackStack/client/src/components/Profile.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBb0JvQjs7Ozs7Ozs7Ozs7Ozs7OztBQW5CcEIsU0FBU0EsU0FBU0Msd0JBQXdCO0FBQzFDLFNBQVNDLFVBQVVDLGlCQUFpQjtBQUNwQyxTQUFTQyxtQkFBbUI7QUFFNUIsd0JBQXdCQyxVQUFVO0FBQUFDLEtBQUE7QUFDaEMsUUFBTTtBQUFBLElBQUVDO0FBQUFBLElBQU1DO0FBQUFBLEVBQVMsSUFBSVIsUUFBUTtBQUNuQyxRQUFNLENBQUNTLFdBQVdDLFlBQVksSUFBSVIsU0FBUyxFQUFFO0FBQzdDLFFBQU0sQ0FBQ1MsVUFBV0MsV0FBVyxJQUFLVixTQUFTLEVBQUU7QUFDN0MsUUFBTVcsV0FBV1QsWUFBWTtBQUc3QkQsWUFBVSxNQUFNO0FBQ2QsUUFBSUssWUFBWUQsTUFBTTtBQUNwQkcsbUJBQWFILEtBQUtFLGFBQWEsRUFBRTtBQUNqQ0csa0JBQVlMLEtBQUtJLFlBQWMsRUFBRTtBQUFBLElBQ25DO0FBQUEsRUFDRixHQUFHLENBQUNILFVBQVVELElBQUksQ0FBQztBQUVuQixNQUFJLENBQUNDO0FBQVUsV0FBTztBQUN0QixNQUFJLENBQUNEO0FBQU0sV0FBTyx1QkFBQyxzQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQWlCO0FBRW5DLFFBQU1PLFNBQVMsT0FBT0MsTUFBdUI7QUFDM0NBLE1BQUVDLGVBQWU7QUFDakIsVUFBTVQsS0FBS1UsT0FBTztBQUFBLE1BQUVSO0FBQUFBLE1BQVdFO0FBQUFBLElBQVMsQ0FBQztBQUN6Q0UsYUFBUyxLQUFLO0FBQUEsTUFBRUssU0FBUztBQUFBLElBQUssQ0FBQztBQUFBLEVBQ2pDO0FBRUEsU0FDRSx1QkFBQyxTQUFJLFdBQVUscUJBQ2I7QUFBQSwyQkFBQyxRQUFHLHFDQUFKO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBeUI7QUFBQSxJQUN6Qix1QkFBQyxVQUFLLFVBQVVKLFFBQVEsV0FBVSxnQkFDaEM7QUFBQSw2QkFBQyxXQUFNO0FBQUE7QUFBQSxRQUVQLHVCQUFDLFdBQ0csTUFBSyxRQUNMLE9BQU9MLFdBQ1AsVUFBVU0sT0FBS0wsYUFBYUssRUFBRUksT0FBT0MsS0FBSyxHQUMxQyxVQUFRLFFBSlo7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUlZO0FBQUEsV0FOWjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBUUE7QUFBQSxNQUVBLHVCQUFDLFdBQU07QUFBQTtBQUFBLFFBRUwsdUJBQUMsV0FDQyxNQUFLLFFBQ0wsT0FBT1QsVUFDUCxVQUFVSSxPQUFLSCxZQUFZRyxFQUFFSSxPQUFPQyxLQUFLLEdBQ3pDLFVBQVEsUUFKVjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBSVU7QUFBQSxXQU5aO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFRQTtBQUFBLE1BRUEsdUJBQUMsWUFBTyxNQUFLLFVBQVMsK0JBQXRCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBeUM7QUFBQSxTQXJCM0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQXNCQTtBQUFBLE9BeEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0F5QkE7QUFFSjtBQUFDZCxHQW5EdUJELFNBQU87QUFBQSxVQUNGTCxTQUdWSSxXQUFXO0FBQUE7QUFBQWlCLEtBSk5oQjtBQUFPLElBQUFnQjtBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsidXNlVXNlciIsIlJlZGlyZWN0VG9TaWduSW4iLCJ1c2VTdGF0ZSIsInVzZUVmZmVjdCIsInVzZU5hdmlnYXRlIiwiUHJvZmlsZSIsIl9zIiwidXNlciIsImlzTG9hZGVkIiwiZmlyc3ROYW1lIiwic2V0Rmlyc3ROYW1lIiwibGFzdE5hbWUiLCJzZXRMYXN0TmFtZSIsIm5hdmlnYXRlIiwib25TYXZlIiwiZSIsInByZXZlbnREZWZhdWx0IiwidXBkYXRlIiwicmVwbGFjZSIsInRhcmdldCIsInZhbHVlIiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJQcm9maWxlLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyIvLyBjb21wb25lbnRzL1Byb2ZpbGUudHN4XHJcbmltcG9ydCB7IHVzZVVzZXIsIFJlZGlyZWN0VG9TaWduSW4gfSBmcm9tIFwiQGNsZXJrL2NsZXJrLXJlYWN0XCI7XHJcbmltcG9ydCB7IHVzZVN0YXRlLCB1c2VFZmZlY3QgfSBmcm9tIFwicmVhY3RcIjtcclxuaW1wb3J0IHsgdXNlTmF2aWdhdGUgfSBmcm9tIFwicmVhY3Qtcm91dGVyLWRvbVwiO1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gUHJvZmlsZSgpIHtcclxuICBjb25zdCB7IHVzZXIsIGlzTG9hZGVkIH0gPSB1c2VVc2VyKCk7XHJcbiAgY29uc3QgW2ZpcnN0TmFtZSwgc2V0Rmlyc3ROYW1lXSA9IHVzZVN0YXRlKFwiXCIpO1xyXG4gIGNvbnN0IFtsYXN0TmFtZSwgIHNldExhc3ROYW1lXSAgPSB1c2VTdGF0ZShcIlwiKTtcclxuICBjb25zdCBuYXZpZ2F0ZSA9IHVzZU5hdmlnYXRlKCk7XHJcblxyXG4gIFxyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBpZiAoaXNMb2FkZWQgJiYgdXNlcikge1xyXG4gICAgICBzZXRGaXJzdE5hbWUodXNlci5maXJzdE5hbWUgfHwgXCJcIik7XHJcbiAgICAgIHNldExhc3ROYW1lKHVzZXIubGFzdE5hbWUgICB8fCBcIlwiKTtcclxuICAgIH1cclxuICB9LCBbaXNMb2FkZWQsIHVzZXJdKTtcclxuXHJcbiAgaWYgKCFpc0xvYWRlZCkgcmV0dXJuIG51bGw7XHJcbiAgaWYgKCF1c2VyKSByZXR1cm4gPFJlZGlyZWN0VG9TaWduSW4gLz47XHJcblxyXG4gIGNvbnN0IG9uU2F2ZSA9IGFzeW5jIChlOiBSZWFjdC5Gb3JtRXZlbnQpID0+IHtcclxuICAgIGUucHJldmVudERlZmF1bHQoKTtcclxuICAgIGF3YWl0IHVzZXIudXBkYXRlKHsgZmlyc3ROYW1lLCBsYXN0TmFtZSB9KTtcclxuICAgIG5hdmlnYXRlKFwiL1wiLCB7IHJlcGxhY2U6IHRydWUgfSk7XHJcbiAgfTtcclxuXHJcbiAgcmV0dXJuIChcclxuICAgIDxkaXYgY2xhc3NOYW1lPVwicHJvZmlsZS1jb250YWluZXJcIj5cclxuICAgICAgPGgyPkNvbXBsZXRlIFlvdXIgUHJvZmlsZTwvaDI+XHJcbiAgICAgIDxmb3JtIG9uU3VibWl0PXtvblNhdmV9IGNsYXNzTmFtZT1cInByb2ZpbGUtZm9ybVwiPlxyXG4gICAgICAgIDxsYWJlbD5cclxuICAgICAgICAgIEZpcnN0IE5hbWVcclxuICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgdHlwZT1cInRleHRcIlxyXG4gICAgICAgICAgICB2YWx1ZT17Zmlyc3ROYW1lfVxyXG4gICAgICAgICAgICBvbkNoYW5nZT17ZSA9PiBzZXRGaXJzdE5hbWUoZS50YXJnZXQudmFsdWUpfVxyXG4gICAgICAgICAgICByZXF1aXJlZFxyXG4gICAgICAgICAgLz5cclxuICAgICAgICA8L2xhYmVsPlxyXG5cclxuICAgICAgICA8bGFiZWw+XHJcbiAgICAgICAgTGFzdCBOYW1lXHJcbiAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgdHlwZT1cInRleHRcIlxyXG4gICAgICAgICAgICB2YWx1ZT17bGFzdE5hbWV9XHJcbiAgICAgICAgICAgIG9uQ2hhbmdlPXtlID0+IHNldExhc3ROYW1lKGUudGFyZ2V0LnZhbHVlKX1cclxuICAgICAgICAgICAgcmVxdWlyZWRcclxuICAgICAgICAgIC8+XHJcbiAgICAgICAgPC9sYWJlbD5cclxuXHJcbiAgICAgICAgPGJ1dHRvbiB0eXBlPVwic3VibWl0XCI+U2F2ZSAmYW1wOyBDb250aW51ZTwvYnV0dG9uPlxyXG4gICAgICA8L2Zvcm0+XHJcbiAgICA8L2Rpdj5cclxuICApO1xyXG59Il0sImZpbGUiOiJDOi9Vc2Vycy9zX21hci9jczMyL1NuYWNrU3RhY2svY2xpZW50L3NyYy9jb21wb25lbnRzL1Byb2ZpbGUudHN4In0=