import {
  require_react
} from "/node_modules/.vite/deps/chunk-K5YNGTCN.js?v=b14ee716";
import "/node_modules/.vite/deps/chunk-ZC22LKFR.js?v=b14ee716";
export default require_react();
//# sourceMappingURL=react.js.map
