import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/App.tsx");import.meta.env = {"VITE_CLERK_PUBLISHABLE_KEY":"pk_test_YW1wbGUtZmVycmV0LTIzLmNsZXJrLmFjY291bnRzLmRldiQ","VITE_DISABLE_AUTH":"false","BASE_URL":"/","MODE":"development","DEV":true,"PROD":false,"SSR":false};import { jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/s_mar/cs32/SnackStack/client/src/components/App.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import "/src/styles/App.css";
import InventoryManagement from "/src/pages/InventoryManagement.tsx";
import { Route, BrowserRouter as Router, Routes } from "/node_modules/.vite/deps/react-router-dom.js?v=b14ee716";
import Home from "/src/components/Home.tsx";
import { Navbar } from "/src/components/Navbar.tsx";
import { Footer } from "/src/components/Footer.tsx";
import RecipeGeneration from "/src/pages/RecipeGeneration.tsx";
import Profile from "/src/components/Profile.tsx";
import { SignedIn, SignedOut, SignInButton, SignOutButton, UserButton } from "/node_modules/.vite/deps/@clerk_clerk-react.js?v=b14ee716";
const disableAuth = import.meta.env.VITE_DISABLE_AUTH === "true";
function App() {
  return /* @__PURE__ */ jsxDEV(Router, { children: /* @__PURE__ */ jsxDEV("div", { className: "container", children: [
    /* @__PURE__ */ jsxDEV("header", { className: "header", children: [
      /* @__PURE__ */ jsxDEV(Navbar, {}, void 0, false, {
        fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/components/App.tsx",
        lineNumber: 15,
        columnNumber: 9
      }, this),
      !disableAuth && /* @__PURE__ */ jsxDEV("div", { className: "auth-controls", children: [
        /* @__PURE__ */ jsxDEV(SignedOut, { children: /* @__PURE__ */ jsxDEV(SignInButton, { mode: "modal", children: /* @__PURE__ */ jsxDEV("button", { className: "auth-button", children: "Sign In" }, void 0, false, {
          fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/components/App.tsx",
          lineNumber: 20,
          columnNumber: 15
        }, this) }, void 0, false, {
          fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/components/App.tsx",
          lineNumber: 19,
          columnNumber: 9
        }, this) }, void 0, false, {
          fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/components/App.tsx",
          lineNumber: 18,
          columnNumber: 9
        }, this),
        /* @__PURE__ */ jsxDEV(SignedIn, { children: [
          /* @__PURE__ */ jsxDEV(UserButton, {}, void 0, false, {
            fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/components/App.tsx",
            lineNumber: 25,
            columnNumber: 13
          }, this),
          " ",
          /* @__PURE__ */ jsxDEV(SignOutButton, { children: /* @__PURE__ */ jsxDEV("button", { className: "auth-button", children: "Sign Out" }, void 0, false, {
            fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/components/App.tsx",
            lineNumber: 27,
            columnNumber: 17
          }, this) }, void 0, false, {
            fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/components/App.tsx",
            lineNumber: 26,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/components/App.tsx",
          lineNumber: 24,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/components/App.tsx",
        lineNumber: 17,
        columnNumber: 24
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/components/App.tsx",
      lineNumber: 14,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "main-content", children: /* @__PURE__ */ jsxDEV(Routes, { children: [
      !disableAuth && /* @__PURE__ */ jsxDEV(Route, { path: "/complete-profile", element: /* @__PURE__ */ jsxDEV(Profile, {}, void 0, false, {
        fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/components/App.tsx",
        lineNumber: 35,
        columnNumber: 71
      }, this) }, void 0, false, {
        fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/components/App.tsx",
        lineNumber: 35,
        columnNumber: 30
      }, this),
      /* @__PURE__ */ jsxDEV(Route, { path: "/", element: /* @__PURE__ */ jsxDEV(Home, {}, void 0, false, {
        fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/components/App.tsx",
        lineNumber: 36,
        columnNumber: 38
      }, this) }, void 0, false, {
        fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/components/App.tsx",
        lineNumber: 36,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV(Route, { path: "/inventory", element: disableAuth ? /* @__PURE__ */ jsxDEV(InventoryManagement, {}, void 0, false, {
        fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/components/App.tsx",
        lineNumber: 37,
        columnNumber: 61
      }, this) : /* @__PURE__ */ jsxDEV(SignedIn, { children: /* @__PURE__ */ jsxDEV(InventoryManagement, {}, void 0, false, {
        fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/components/App.tsx",
        lineNumber: 38,
        columnNumber: 5
      }, this) }, void 0, false, {
        fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/components/App.tsx",
        lineNumber: 37,
        columnNumber: 87
      }, this) }, void 0, false, {
        fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/components/App.tsx",
        lineNumber: 37,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV(Route, { path: "/cook", element: disableAuth ? /* @__PURE__ */ jsxDEV(RecipeGeneration, {}, void 0, false, {
        fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/components/App.tsx",
        lineNumber: 41,
        columnNumber: 56
      }, this) : /* @__PURE__ */ jsxDEV(SignedIn, { children: /* @__PURE__ */ jsxDEV(RecipeGeneration, {}, void 0, false, {
        fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/components/App.tsx",
        lineNumber: 42,
        columnNumber: 7
      }, this) }, void 0, false, {
        fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/components/App.tsx",
        lineNumber: 41,
        columnNumber: 79
      }, this) }, void 0, false, {
        fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/components/App.tsx",
        lineNumber: 41,
        columnNumber: 13
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/components/App.tsx",
      lineNumber: 34,
      columnNumber: 11
    }, this) }, void 0, false, {
      fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/components/App.tsx",
      lineNumber: 33,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV(Footer, {}, void 0, false, {
      fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/components/App.tsx",
      lineNumber: 47,
      columnNumber: 9
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/components/App.tsx",
    lineNumber: 13,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/components/App.tsx",
    lineNumber: 12,
    columnNumber: 10
  }, this);
}
_c = App;
export default App;
var _c;
$RefreshReg$(_c, "App");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/s_mar/cs32/SnackStack/client/src/components/App.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBeUJRO0FBekJSLE9BQU8sb0JBQW1CO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUMxQixPQUFPQSx5QkFBeUI7QUFDaEMsU0FBU0MsT0FBT0MsaUJBQWlCQyxRQUFRQyxjQUFjO0FBQ3ZELE9BQU9DLFVBQVU7QUFDakIsU0FBU0MsY0FBYztBQUN2QixTQUFTQyxjQUFjO0FBQ3ZCLE9BQU9DLHNCQUFzQjtBQUM3QixPQUFPQyxhQUFhO0FBR3BCLFNBQ0VDLFVBQ0FDLFdBQ0FDLGNBQ0FDLGVBQ0FDLGtCQUNLO0FBRVAsTUFBTUMsY0FBY0MsWUFBWUMsSUFBSUMsc0JBQXNCO0FBRTFELFNBQVNDLE1BQU07QUFDYixTQUNFLHVCQUFDLFVBQ0MsaUNBQUMsU0FBSSxXQUFVLGFBQ2Y7QUFBQSwyQkFBQyxZQUFPLFdBQVUsVUFDaEI7QUFBQSw2QkFBQyxZQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBTztBQUFBLE1BRVIsQ0FBQ0osZUFDQSx1QkFBQyxTQUFJLFdBQVUsaUJBQ2Y7QUFBQSwrQkFBQyxhQUNELGlDQUFDLGdCQUFhLE1BQUssU0FDYixpQ0FBQyxZQUFPLFdBQVUsZUFBYyx1QkFBaEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUF1QyxLQUQ3QztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRU0sS0FITjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBSUk7QUFBQSxRQUVBLHVCQUFDLFlBQ0Q7QUFBQSxpQ0FBQyxnQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFXO0FBQUEsVUFBSTtBQUFBLFVBQ2YsdUJBQUMsaUJBQ0csaUNBQUMsWUFBTyxXQUFVLGVBQWMsd0JBQWhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQXdDLEtBRDVDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUU7QUFBQSxhQUpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFLQTtBQUFBLFdBWko7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQWFFO0FBQUEsU0FqQko7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQW1CRTtBQUFBLElBRUEsdUJBQUMsU0FBSSxXQUFVLGdCQUNiLGlDQUFDLFVBQ0U7QUFBQSxPQUFDQSxlQUNGLHVCQUFDLFNBQU0sTUFBSyxxQkFBb0IsU0FBUyx1QkFBQyxhQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBUSxLQUFqRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXFEO0FBQUEsTUFFckQsdUJBQUMsU0FBTSxNQUFLLEtBQUksU0FBUyx1QkFBQyxVQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBSyxLQUE5QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQWtDO0FBQUEsTUFDbEMsdUJBQUMsU0FBTSxNQUFLLGNBQWEsU0FDdkJBLGNBQ0EsdUJBQUMseUJBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFvQixJQUVoQyx1QkFBQyxZQUNDLGlDQUFDLHlCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBb0IsS0FEdEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBLEtBTlU7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQU1HO0FBQUEsTUFFSCx1QkFBQyxTQUFNLE1BQUssU0FBUSxTQUNsQkEsY0FBZSx1QkFBQyxzQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQWlCLElBRTFDLHVCQUFDLFlBQ0MsaUNBQUMsc0JBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFpQixLQURuQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRUEsS0FMUTtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBTVI7QUFBQSxTQW5CTTtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBb0JBLEtBckJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FzQkE7QUFBQSxJQUVBLHVCQUFDLFlBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFPO0FBQUEsT0E5Q1Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQStDQSxLQWhERjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBaURBO0FBRUo7QUFBQ0ssS0FyRFFEO0FBdURULGVBQWVBO0FBQUksSUFBQUM7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbIkludmVudG9yeU1hbmFnZW1lbnQiLCJSb3V0ZSIsIkJyb3dzZXJSb3V0ZXIiLCJSb3V0ZXIiLCJSb3V0ZXMiLCJIb21lIiwiTmF2YmFyIiwiRm9vdGVyIiwiUmVjaXBlR2VuZXJhdGlvbiIsIlByb2ZpbGUiLCJTaWduZWRJbiIsIlNpZ25lZE91dCIsIlNpZ25JbkJ1dHRvbiIsIlNpZ25PdXRCdXR0b24iLCJVc2VyQnV0dG9uIiwiZGlzYWJsZUF1dGgiLCJpbXBvcnQiLCJlbnYiLCJWSVRFX0RJU0FCTEVfQVVUSCIsIkFwcCIsIl9jIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiQXBwLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgXCIuLi9zdHlsZXMvQXBwLmNzc1wiO1xyXG5pbXBvcnQgSW52ZW50b3J5TWFuYWdlbWVudCBmcm9tIFwiLi4vcGFnZXMvSW52ZW50b3J5TWFuYWdlbWVudFwiO1xyXG5pbXBvcnQgeyBSb3V0ZSwgQnJvd3NlclJvdXRlciBhcyBSb3V0ZXIsIFJvdXRlcyB9IGZyb20gXCJyZWFjdC1yb3V0ZXItZG9tXCI7XHJcbmltcG9ydCBIb21lIGZyb20gXCIuL0hvbWVcIjtcclxuaW1wb3J0IHsgTmF2YmFyIH0gZnJvbSBcIi4vTmF2YmFyXCI7XHJcbmltcG9ydCB7IEZvb3RlciB9IGZyb20gXCIuL0Zvb3RlclwiO1xyXG5pbXBvcnQgUmVjaXBlR2VuZXJhdGlvbiBmcm9tIFwiLi4vcGFnZXMvUmVjaXBlR2VuZXJhdGlvblwiO1xyXG5pbXBvcnQgUHJvZmlsZSBmcm9tIFwiLi4vY29tcG9uZW50cy9Qcm9maWxlXCI7IFxyXG5cclxuXHJcbmltcG9ydCB7XHJcbiAgU2lnbmVkSW4sXHJcbiAgU2lnbmVkT3V0LFxyXG4gIFNpZ25JbkJ1dHRvbixcclxuICBTaWduT3V0QnV0dG9uLFxyXG4gIFVzZXJCdXR0b24sXHJcbn0gZnJvbSBcIkBjbGVyay9jbGVyay1yZWFjdFwiO1xyXG5cclxuY29uc3QgZGlzYWJsZUF1dGggPSBpbXBvcnQubWV0YS5lbnYuVklURV9ESVNBQkxFX0FVVEggPT09IFwidHJ1ZVwiO1xyXG5cclxuZnVuY3Rpb24gQXBwKCkge1xyXG4gIHJldHVybiAoXHJcbiAgICA8Um91dGVyPlxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImNvbnRhaW5lclwiPlxyXG4gICAgICA8aGVhZGVyIGNsYXNzTmFtZT1cImhlYWRlclwiPlxyXG4gICAgICAgIDxOYXZiYXIgLz5cclxuXHJcbiAgICAgIHshZGlzYWJsZUF1dGggJiYgKFxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYXV0aC1jb250cm9sc1wiPlxyXG4gICAgICAgIDxTaWduZWRPdXQ+XHJcbiAgICAgICAgPFNpZ25JbkJ1dHRvbiBtb2RlPVwibW9kYWxcIj5cclxuICAgICAgICAgICAgICA8YnV0dG9uIGNsYXNzTmFtZT1cImF1dGgtYnV0dG9uXCI+U2lnbiBJbjwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgIDwvU2lnbkluQnV0dG9uPlxyXG4gICAgICAgICAgICA8L1NpZ25lZE91dD5cclxuXHJcbiAgICAgICAgICAgIDxTaWduZWRJbj5cclxuICAgICAgICAgICAgPFVzZXJCdXR0b24gLz57XCIgXCJ9XHJcbiAgICAgICAgICAgIDxTaWduT3V0QnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgPGJ1dHRvbiBjbGFzc05hbWU9XCJhdXRoLWJ1dHRvblwiPlNpZ24gT3V0PC9idXR0b24+XHJcbiAgICAgICAgICAgICAgPC9TaWduT3V0QnV0dG9uPlxyXG4gICAgICAgICAgICA8L1NpZ25lZEluPlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICl9XHJcbiAgICAgICAgPC9oZWFkZXI+XHJcblxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWFpbi1jb250ZW50XCI+XHJcbiAgICAgICAgICA8Um91dGVzPlxyXG4gICAgICAgICAgICB7IWRpc2FibGVBdXRoICYmIChcclxuICAgICAgICAgICAgPFJvdXRlIHBhdGg9XCIvY29tcGxldGUtcHJvZmlsZVwiIGVsZW1lbnQ9ezxQcm9maWxlIC8+fSAvPlxyXG4gICAgICAgICAgICApfVxyXG4gICAgICAgICAgICA8Um91dGUgcGF0aD1cIi9cIiBlbGVtZW50PXs8SG9tZSAvPn0gLz5cclxuICAgICAgICAgICAgPFJvdXRlIHBhdGg9XCIvaW52ZW50b3J5XCIgZWxlbWVudD17XHJcbiAgICAgICAgICAgICAgZGlzYWJsZUF1dGggPyAoXHJcbiAgICAgICAgICAgICAgPEludmVudG9yeU1hbmFnZW1lbnQgLz5cclxuICApIDogKFxyXG4gIDxTaWduZWRJbj5cclxuICAgIDxJbnZlbnRvcnlNYW5hZ2VtZW50IC8+XHJcbiAgPC9TaWduZWRJbj4pfSAvPlxyXG5cclxuICAgICAgICAgICAgPFJvdXRlIHBhdGg9XCIvY29va1wiIGVsZW1lbnQ9e1xyXG4gICAgICAgICAgICAgIGRpc2FibGVBdXRoID8gKDxSZWNpcGVHZW5lcmF0aW9uIC8+XHJcbiAgKSA6IChcclxuICAgIDxTaWduZWRJbj5cclxuICAgICAgPFJlY2lwZUdlbmVyYXRpb24gLz5cclxuICAgIDwvU2lnbmVkSW4+XHJcbiAgKX0gLz5cclxuICAgICAgICAgIDwvUm91dGVzPlxyXG4gICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICA8Rm9vdGVyIC8+XHJcbiAgICAgIDwvZGl2PlxyXG4gICAgPC9Sb3V0ZXI+XHJcbiAgKTtcclxufVxyXG5cclxuZXhwb3J0IGRlZmF1bHQgQXBwO1xyXG4iXSwiZmlsZSI6IkM6L1VzZXJzL3NfbWFyL2NzMzIvU25hY2tTdGFjay9jbGllbnQvc3JjL2NvbXBvbmVudHMvQXBwLnRzeCJ9