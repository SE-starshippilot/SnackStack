import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/RecipeGeneration.tsx");import { jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/s_mar/cs32/SnackStack/client/src/pages/RecipeGeneration.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import { Box, Button, Chip, CircularProgress, Container, Slider, TextField, Typography } from "/node_modules/.vite/deps/@mui_material.js?v=b14ee716";
import { styled } from "/node_modules/.vite/deps/@mui_material_styles.js?v=b14ee716";
import __vite__cjsImport5_react from "/node_modules/.vite/deps/react.js?v=b14ee716"; const useState = __vite__cjsImport5_react["useState"];
import "/src/styles/RecipeGeneration.css";
const mealTypes = [{
  id: "main",
  label: "Main"
}, {
  id: "appetizer",
  label: "Appetizer"
}, {
  id: "dessert",
  label: "Dessert"
}, {
  id: "breakfast",
  label: "Breakfast"
}, {
  id: "snack",
  label: "Snack"
}];
const defaultPreferences = ["American", "Italian", "Chinese", "Mexican", "Japanese", "Indian", "Middle Eastern", "Thai"];
const defaultAllergies = ["Gluten", "Dairy", "Nuts", "Eggs", "Soy", "Shellfish"];
const PrettoSlider = styled(Slider)({
  color: "#52af77",
  height: 8,
  maxWidth: 300,
  "& .MuiSlider-track": {
    border: "none"
  },
  "& .MuiSlider-thumb": {
    height: 24,
    width: 24,
    backgroundColor: "#fff",
    border: "2px solid currentColor",
    "&:focus, &:hover, &.Mui-active, &.Mui-focusVisible": {
      boxShadow: "inherit"
    },
    "&::before": {
      display: "none"
    }
  },
  "& .MuiSlider-valueLabel": {
    lineHeight: 1.2,
    fontSize: 12,
    background: "unset",
    padding: 0,
    width: 32,
    height: 32,
    borderRadius: "50% 50% 50% 0",
    backgroundColor: "#52af77",
    transformOrigin: "bottom left",
    transform: "translate(50%, -100%) rotate(-45deg) scale(0)",
    "&::before": {
      display: "none"
    },
    "&.MuiSlider-valueLabelOpen": {
      transform: "translate(50%, -100%) rotate(-45deg) scale(1)"
    },
    "& > *": {
      transform: "rotate(45deg)"
    }
  }
});
_c = PrettoSlider;
function RecipeGeneration() {
  _s();
  const [isLoading, setIsLoading] = useState(false);
  const [formData, setFormData] = useState({
    servings: 1,
    mealType: "",
    notes: ""
  });
  const [errors, setErrors] = useState({
    servings: false,
    mealType: false
  });
  const [preferences, setPreferences] = useState([]);
  const [preferenceOptions, setPreferenceOptions] = useState([...defaultPreferences]);
  const [customPreferences, setCustomPreferences] = useState([]);
  const [preferenceInput, setPreferenceInput] = useState("");
  const [allergies, setAllergies] = useState([]);
  const [allergyOptions, setAllergyOptions] = useState([...defaultAllergies]);
  const [customAllergies, setCustomAllergies] = useState([]);
  const [allergyInput, setAllergyInput] = useState("");
  const handleChipToggle = (value, list, setList) => {
    setList((prev) => prev.includes(value) ? prev.filter((v) => v !== value) : [...prev, value]);
  };
  const handleAddChip = (value, options, setOptions, custom, setCustom, selected, setSelected, setInput) => {
    const trimmed = value.trim();
    if (trimmed && !options.includes(trimmed) && !custom.includes(trimmed)) {
      setOptions((prev) => [...prev, trimmed]);
      setCustom((prev) => [...prev, trimmed]);
      setSelected((prev) => [...prev, trimmed]);
      setInput("");
    }
  };
  const handleDeleteCustom = (item, setOptions, setSelected, setCustom) => {
    setOptions((prev) => prev.filter((v) => v !== item));
    setSelected((prev) => prev.filter((v) => v !== item));
    setCustom((prev) => prev.filter((v) => v !== item));
  };
  const handleSubmit = (e) => {
    e.preventDefault();
    const newErrors = {
      servings: formData.servings < 1,
      mealType: !formData.mealType
    };
    setErrors(newErrors);
    if (newErrors.servings || newErrors.mealType)
      return;
    setIsLoading(true);
    setTimeout(() => setIsLoading(false), 3e3);
  };
  return /* @__PURE__ */ jsxDEV(Container, { maxWidth: "md", sx: {
    width: "900px",
    px: {
      xs: 2,
      sm: 3,
      md: 4
    }
  }, children: /* @__PURE__ */ jsxDEV(Box, { width: "100%", children: [
    /* @__PURE__ */ jsxDEV(Typography, { variant: "h5", fontWeight: 600, textAlign: "center", gutterBottom: true, children: "Generate Your Perfect Recipe" }, void 0, false, {
      fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/pages/RecipeGeneration.tsx",
      lineNumber: 123,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV(Typography, { variant: "body2", textAlign: "center", color: "text.secondary", mb: 2, children: "Based on your preferences, dietary needs, and available ingredients." }, void 0, false, {
      fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/pages/RecipeGeneration.tsx",
      lineNumber: 126,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV("form", { onSubmit: handleSubmit, className: "form-container", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "form-section", children: [
        /* @__PURE__ */ jsxDEV(Typography, { variant: "subtitle1", fontWeight: 600, children: [
          "How many servings? ",
          /* @__PURE__ */ jsxDEV("span", { className: "required", children: "*" }, void 0, false, {
            fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/pages/RecipeGeneration.tsx",
            lineNumber: 133,
            columnNumber: 34
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/pages/RecipeGeneration.tsx",
          lineNumber: 132,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV(Box, { display: "flex", alignItems: "center", gap: 2, children: [
          /* @__PURE__ */ jsxDEV(PrettoSlider, { value: formData.servings, onChange: (_, val) => setFormData((prev) => ({
            ...prev,
            servings: val
          })), valueLabelDisplay: "auto", defaultValue: 1, min: 0, max: 10, color: errors.servings ? "error" : "success" }, void 0, false, {
            fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/pages/RecipeGeneration.tsx",
            lineNumber: 136,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV(Typography, { "data-testid": "serving-value", children: formData.servings }, void 0, false, {
            fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/pages/RecipeGeneration.tsx",
            lineNumber: 140,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/pages/RecipeGeneration.tsx",
          lineNumber: 135,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/pages/RecipeGeneration.tsx",
        lineNumber: 131,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "form-section", children: [
        /* @__PURE__ */ jsxDEV(Typography, { variant: "subtitle1", fontWeight: 600, children: [
          "What kind of meal? ",
          /* @__PURE__ */ jsxDEV("span", { className: "required", children: "*" }, void 0, false, {
            fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/pages/RecipeGeneration.tsx",
            lineNumber: 148,
            columnNumber: 34
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/pages/RecipeGeneration.tsx",
          lineNumber: 147,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV(Box, { display: "flex", gap: 1, flexWrap: "wrap", children: mealTypes.map((type) => /* @__PURE__ */ jsxDEV(Chip, { className: "custom-chip", label: type.label, variant: formData.mealType === type.id ? "filled" : "outlined", color: formData.mealType === type.id ? "success" : "default", onClick: () => setFormData((prev) => ({
          ...prev,
          mealType: type.id
        })) }, type.id, false, {
          fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/pages/RecipeGeneration.tsx",
          lineNumber: 151,
          columnNumber: 38
        }, this)) }, void 0, false, {
          fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/pages/RecipeGeneration.tsx",
          lineNumber: 150,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/pages/RecipeGeneration.tsx",
        lineNumber: 146,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "form-section", children: [
        /* @__PURE__ */ jsxDEV(Typography, { variant: "subtitle1", fontWeight: 600, children: "Preferences" }, void 0, false, {
          fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/pages/RecipeGeneration.tsx",
          lineNumber: 159,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV(Box, { className: "chip-row", children: preferenceOptions.map((pref) => /* @__PURE__ */ jsxDEV(Chip, { className: "custom-chip", label: pref, variant: preferences.includes(pref) ? "filled" : "outlined", color: preferences.includes(pref) ? "success" : void 0, onClick: () => handleChipToggle(pref, preferences, setPreferences), onDelete: customPreferences.includes(pref) ? () => handleDeleteCustom(pref, setPreferenceOptions, setCustomPreferences, setPreferences) : void 0 }, pref, false, {
          fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/pages/RecipeGeneration.tsx",
          lineNumber: 163,
          columnNumber: 46
        }, this)) }, void 0, false, {
          fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/pages/RecipeGeneration.tsx",
          lineNumber: 162,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV(Box, { display: "flex", gap: 1, sx: {
          height: 40,
          alignItems: "center"
        }, children: [
          /* @__PURE__ */ jsxDEV(TextField, { label: "Add Preference", size: "small", value: preferenceInput, color: "success", focused: true, onChange: (e) => setPreferenceInput(e.target.value) }, void 0, false, {
            fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/pages/RecipeGeneration.tsx",
            lineNumber: 169,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV(Button, { variant: "outlined", color: "success", "aria-label": "add-preference", onClick: () => handleAddChip(preferenceInput, preferenceOptions, setPreferenceOptions, customPreferences, setCustomPreferences, preferences, setPreferences, setPreferenceInput), children: "Add" }, void 0, false, {
            fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/pages/RecipeGeneration.tsx",
            lineNumber: 170,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/pages/RecipeGeneration.tsx",
          lineNumber: 165,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/pages/RecipeGeneration.tsx",
        lineNumber: 158,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "form-section", children: [
        /* @__PURE__ */ jsxDEV(Typography, { variant: "subtitle1", fontWeight: 600, children: "Allergies" }, void 0, false, {
          fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/pages/RecipeGeneration.tsx",
          lineNumber: 177,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV(Box, { className: "chip-row", children: allergyOptions.map((allergy) => /* @__PURE__ */ jsxDEV(Chip, { className: "custom-chip", label: allergy, variant: allergies.includes(allergy) ? "filled" : "outlined", color: allergies.includes(allergy) ? "success" : void 0, onClick: () => handleChipToggle(allergy, allergies, setAllergies), onDelete: customAllergies.includes(allergy) ? () => handleDeleteCustom(allergy, setAllergyOptions, setCustomAllergies, setAllergies) : void 0 }, allergy, false, {
          fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/pages/RecipeGeneration.tsx",
          lineNumber: 181,
          columnNumber: 46
        }, this)) }, void 0, false, {
          fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/pages/RecipeGeneration.tsx",
          lineNumber: 180,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV(Box, { display: "flex", gap: 1, mt: 1, children: [
          /* @__PURE__ */ jsxDEV(TextField, { label: "Add Allergy", size: "small", focused: true, color: "success", value: allergyInput, onChange: (e) => setAllergyInput(e.target.value) }, void 0, false, {
            fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/pages/RecipeGeneration.tsx",
            lineNumber: 184,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV(Button, { variant: "outlined", color: "success", "aria-label": "add-allergy", onClick: () => handleAddChip(allergyInput, allergyOptions, setAllergyOptions, customAllergies, setCustomAllergies, allergies, setAllergies, setAllergyInput), children: "Add" }, void 0, false, {
            fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/pages/RecipeGeneration.tsx",
            lineNumber: 185,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/pages/RecipeGeneration.tsx",
          lineNumber: 183,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/pages/RecipeGeneration.tsx",
        lineNumber: 176,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "form-section", children: [
        /* @__PURE__ */ jsxDEV(Typography, { variant: "subtitle1", fontWeight: 600, children: "Notes (Optional)" }, void 0, false, {
          fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/pages/RecipeGeneration.tsx",
          lineNumber: 192,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV(TextField, { multiline: true, rows: 3, placeholder: "Any specific preferences or instructions?", fullWidth: true, color: "success", value: formData.notes, onChange: (e) => setFormData({
          ...formData,
          notes: e.target.value
        }) }, void 0, false, {
          fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/pages/RecipeGeneration.tsx",
          lineNumber: 195,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/pages/RecipeGeneration.tsx",
        lineNumber: 191,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV(Box, { textAlign: "center", mt: 4, children: /* @__PURE__ */ jsxDEV(Button, { type: "submit", variant: "contained", color: "success", sx: {
        px: 4,
        py: 1.5,
        fontWeight: 500
      }, disabled: isLoading, children: isLoading ? /* @__PURE__ */ jsxDEV(CircularProgress, { size: 24, sx: {
        color: "#fff"
      } }, void 0, false, {
        fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/pages/RecipeGeneration.tsx",
        lineNumber: 207,
        columnNumber: 28
      }, this) : "Generate Recipe" }, void 0, false, {
        fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/pages/RecipeGeneration.tsx",
        lineNumber: 202,
        columnNumber: 13
      }, this) }, void 0, false, {
        fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/pages/RecipeGeneration.tsx",
        lineNumber: 201,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/pages/RecipeGeneration.tsx",
      lineNumber: 130,
      columnNumber: 9
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/pages/RecipeGeneration.tsx",
    lineNumber: 122,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/pages/RecipeGeneration.tsx",
    lineNumber: 114,
    columnNumber: 10
  }, this);
}
_s(RecipeGeneration, "yeL9ZAoCKGXB4zjeBrJtehCIeCI=");
_c2 = RecipeGeneration;
export default RecipeGeneration;
var _c, _c2;
$RefreshReg$(_c, "PrettoSlider");
$RefreshReg$(_c2, "RecipeGeneration");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/s_mar/cs32/SnackStack/client/src/pages/RecipeGeneration.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBK0pROzs7Ozs7Ozs7Ozs7Ozs7O0FBL0pSLFNBQ0VBLEtBQ0FDLFFBQ0FDLE1BQ0FDLGtCQUNBQyxXQUNBQyxRQUNBQyxXQUNBQyxrQkFDSztBQUNQLFNBQVNDLGNBQWM7QUFDdkIsU0FBZ0JDLGdCQUFnQjtBQUNoQyxPQUFPO0FBRVAsTUFBTUMsWUFBWSxDQUNoQjtBQUFBLEVBQUVDLElBQUk7QUFBQSxFQUFRQyxPQUFPO0FBQU8sR0FDNUI7QUFBQSxFQUFFRCxJQUFJO0FBQUEsRUFBYUMsT0FBTztBQUFZLEdBQ3RDO0FBQUEsRUFBRUQsSUFBSTtBQUFBLEVBQVdDLE9BQU87QUFBVSxHQUNsQztBQUFBLEVBQUVELElBQUk7QUFBQSxFQUFhQyxPQUFPO0FBQVksR0FDdEM7QUFBQSxFQUFFRCxJQUFJO0FBQUEsRUFBU0MsT0FBTztBQUFRLENBQUM7QUFHakMsTUFBTUMscUJBQXFCLENBQ3pCLFlBQ0EsV0FDQSxXQUNBLFdBQ0EsWUFDQSxVQUNBLGtCQUNBLE1BQU07QUFHUixNQUFNQyxtQkFBbUIsQ0FDdkIsVUFDQSxTQUNBLFFBQ0EsUUFDQSxPQUNBLFdBQVc7QUFHYixNQUFNQyxlQUFlUCxPQUFPSCxNQUFNLEVBQUU7QUFBQSxFQUNsQ1csT0FBTztBQUFBLEVBQ1BDLFFBQVE7QUFBQSxFQUNSQyxVQUFVO0FBQUEsRUFDVixzQkFBc0I7QUFBQSxJQUFFQyxRQUFRO0FBQUEsRUFBTztBQUFBLEVBQ3ZDLHNCQUFzQjtBQUFBLElBQ3BCRixRQUFRO0FBQUEsSUFDUkcsT0FBTztBQUFBLElBQ1BDLGlCQUFpQjtBQUFBLElBQ2pCRixRQUFRO0FBQUEsSUFDUixzREFBc0Q7QUFBQSxNQUNwREcsV0FBVztBQUFBLElBQ2I7QUFBQSxJQUNBLGFBQWE7QUFBQSxNQUFFQyxTQUFTO0FBQUEsSUFBTztBQUFBLEVBQ2pDO0FBQUEsRUFDQSwyQkFBMkI7QUFBQSxJQUN6QkMsWUFBWTtBQUFBLElBQ1pDLFVBQVU7QUFBQSxJQUNWQyxZQUFZO0FBQUEsSUFDWkMsU0FBUztBQUFBLElBQ1RQLE9BQU87QUFBQSxJQUNQSCxRQUFRO0FBQUEsSUFDUlcsY0FBYztBQUFBLElBQ2RQLGlCQUFpQjtBQUFBLElBQ2pCUSxpQkFBaUI7QUFBQSxJQUNqQkMsV0FBVztBQUFBLElBQ1gsYUFBYTtBQUFBLE1BQUVQLFNBQVM7QUFBQSxJQUFPO0FBQUEsSUFDL0IsOEJBQThCO0FBQUEsTUFDNUJPLFdBQVc7QUFBQSxJQUNiO0FBQUEsSUFDQSxTQUFTO0FBQUEsTUFDUEEsV0FBVztBQUFBLElBQ2I7QUFBQSxFQUNGO0FBQ0YsQ0FBQztBQUFFQyxLQWxDR2hCO0FBb0NOLFNBQVNpQixtQkFBbUI7QUFBQUMsS0FBQTtBQUMxQixRQUFNLENBQUNDLFdBQVdDLFlBQVksSUFBSTFCLFNBQVMsS0FBSztBQUNoRCxRQUFNLENBQUMyQixVQUFVQyxXQUFXLElBQUk1QixTQUFTO0FBQUEsSUFDdkM2QixVQUFVO0FBQUEsSUFDVkMsVUFBVTtBQUFBLElBQ1ZDLE9BQU87QUFBQSxFQUNULENBQUM7QUFDRCxRQUFNLENBQUNDLFFBQVFDLFNBQVMsSUFBSWpDLFNBQVM7QUFBQSxJQUFFNkIsVUFBVTtBQUFBLElBQU9DLFVBQVU7QUFBQSxFQUFNLENBQUM7QUFFekUsUUFBTSxDQUFDSSxhQUFhQyxjQUFjLElBQUluQyxTQUFtQixFQUFFO0FBQzNELFFBQU0sQ0FBQ29DLG1CQUFtQkMsb0JBQW9CLElBQUlyQyxTQUFtQixDQUNuRSxHQUFHSSxrQkFBa0IsQ0FDdEI7QUFDRCxRQUFNLENBQUNrQyxtQkFBbUJDLG9CQUFvQixJQUFJdkMsU0FBbUIsRUFBRTtBQUN2RSxRQUFNLENBQUN3QyxpQkFBaUJDLGtCQUFrQixJQUFJekMsU0FBaUIsRUFBRTtBQUVqRSxRQUFNLENBQUMwQyxXQUFXQyxZQUFZLElBQUkzQyxTQUFtQixFQUFFO0FBQ3ZELFFBQU0sQ0FBQzRDLGdCQUFnQkMsaUJBQWlCLElBQUk3QyxTQUFtQixDQUM3RCxHQUFHSyxnQkFBZ0IsQ0FDcEI7QUFDRCxRQUFNLENBQUN5QyxpQkFBaUJDLGtCQUFrQixJQUFJL0MsU0FBbUIsRUFBRTtBQUNuRSxRQUFNLENBQUNnRCxjQUFjQyxlQUFlLElBQUlqRCxTQUFpQixFQUFFO0FBRTNELFFBQU1rRCxtQkFBbUJBLENBQ3ZCQyxPQUNBQyxNQUNBQyxZQUNHO0FBQ0hBLFlBQVNDLFVBQ1BBLEtBQUtDLFNBQVNKLEtBQUssSUFBSUcsS0FBS0UsT0FBUUMsT0FBTUEsTUFBTU4sS0FBSyxJQUFJLENBQUMsR0FBR0csTUFBTUgsS0FBSyxDQUMxRTtBQUFBLEVBQ0Y7QUFFQSxRQUFNTyxnQkFBZ0JBLENBQ3BCUCxPQUNBUSxTQUNBQyxZQUNBQyxRQUNBQyxXQUNBQyxVQUNBQyxhQUNBQyxhQUNHO0FBQ0gsVUFBTUMsVUFBVWYsTUFBTWdCLEtBQUs7QUFDM0IsUUFBSUQsV0FBVyxDQUFDUCxRQUFRSixTQUFTVyxPQUFPLEtBQUssQ0FBQ0wsT0FBT04sU0FBU1csT0FBTyxHQUFHO0FBQ3RFTixpQkFBWU4sVUFBUyxDQUFDLEdBQUdBLE1BQU1ZLE9BQU8sQ0FBQztBQUN2Q0osZ0JBQVdSLFVBQVMsQ0FBQyxHQUFHQSxNQUFNWSxPQUFPLENBQUM7QUFDdENGLGtCQUFhVixVQUFTLENBQUMsR0FBR0EsTUFBTVksT0FBTyxDQUFDO0FBQ3hDRCxlQUFTLEVBQUU7QUFBQSxJQUNiO0FBQUEsRUFDRjtBQUVBLFFBQU1HLHFCQUFxQkEsQ0FDekJDLE1BQ0FULFlBQ0FJLGFBQ0FGLGNBQ0c7QUFDSEYsZUFBWU4sVUFBU0EsS0FBS0UsT0FBUUMsT0FBTUEsTUFBTVksSUFBSSxDQUFDO0FBQ25ETCxnQkFBYVYsVUFBU0EsS0FBS0UsT0FBUUMsT0FBTUEsTUFBTVksSUFBSSxDQUFDO0FBQ3BEUCxjQUFXUixVQUFTQSxLQUFLRSxPQUFRQyxPQUFNQSxNQUFNWSxJQUFJLENBQUM7QUFBQSxFQUNwRDtBQUVBLFFBQU1DLGVBQWVBLENBQUNDLE1BQXVCO0FBQzNDQSxNQUFFQyxlQUFlO0FBQ2pCLFVBQU1DLFlBQVk7QUFBQSxNQUNoQjVDLFVBQVVGLFNBQVNFLFdBQVc7QUFBQSxNQUM5QkMsVUFBVSxDQUFDSCxTQUFTRztBQUFBQSxJQUN0QjtBQUNBRyxjQUFVd0MsU0FBUztBQUNuQixRQUFJQSxVQUFVNUMsWUFBWTRDLFVBQVUzQztBQUFVO0FBQzlDSixpQkFBYSxJQUFJO0FBQ2pCZ0QsZUFBVyxNQUFNaEQsYUFBYSxLQUFLLEdBQUcsR0FBSTtBQUFBLEVBQzVDO0FBRUEsU0FDRSx1QkFBQyxhQUNDLFVBQVMsTUFDVCxJQUFJO0FBQUEsSUFBRWYsT0FBTztBQUFBLElBQVNnRSxJQUFJO0FBQUEsTUFBRUMsSUFBSTtBQUFBLE1BQUdDLElBQUk7QUFBQSxNQUFHQyxJQUFJO0FBQUEsSUFBRTtBQUFBLEVBQUUsR0FFbEQsaUNBQUMsT0FBSSxPQUFNLFFBQ1Q7QUFBQSwyQkFBQyxjQUNDLFNBQVEsTUFDUixZQUFZLEtBQ1osV0FBVSxVQUNWLGNBQVksTUFDYiw0Q0FMRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBT0E7QUFBQSxJQUNBLHVCQUFDLGNBQ0MsU0FBUSxTQUNSLFdBQVUsVUFDVixPQUFNLGtCQUNOLElBQUksR0FDTCxvRkFMRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBT0E7QUFBQSxJQUVBLHVCQUFDLFVBQUssVUFBVVIsY0FBYyxXQUFVLGtCQUN0QztBQUFBLDZCQUFDLFNBQUksV0FBVSxnQkFDYjtBQUFBLCtCQUFDLGNBQVcsU0FBUSxhQUFZLFlBQVksS0FBSztBQUFBO0FBQUEsVUFDNUIsdUJBQUMsVUFBSyxXQUFVLFlBQVcsaUJBQTNCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQTRCO0FBQUEsYUFEakQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsUUFDQSx1QkFBQyxPQUFJLFNBQVEsUUFBTyxZQUFXLFVBQVMsS0FBSyxHQUMzQztBQUFBLGlDQUFDLGdCQUNDLE9BQU8zQyxTQUFTRSxVQUNoQixVQUFVLENBQUNrRCxHQUFHQyxRQUNacEQsWUFBYTBCLFdBQVU7QUFBQSxZQUFFLEdBQUdBO0FBQUFBLFlBQU16QixVQUFVbUQ7QUFBQUEsVUFBYyxFQUFFLEdBRTlELG1CQUFrQixRQUNsQixjQUFjLEdBQ2QsS0FBSyxHQUNMLEtBQUssSUFDTCxPQUFPaEQsT0FBT0gsV0FBVyxVQUFVLGFBVHJDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBUytDO0FBQUEsVUFFL0MsdUJBQUMsY0FBVyxlQUFZLGlCQUNyQkYsbUJBQVNFLFlBRFo7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFFQTtBQUFBLGFBZEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQWVBO0FBQUEsV0FuQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQW9CQTtBQUFBLE1BRUEsdUJBQUMsU0FBSSxXQUFVLGdCQUNiO0FBQUEsK0JBQUMsY0FBVyxTQUFRLGFBQVksWUFBWSxLQUFLO0FBQUE7QUFBQSxVQUM1Qix1QkFBQyxVQUFLLFdBQVUsWUFBVyxpQkFBM0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBNEI7QUFBQSxhQURqRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQSxRQUNBLHVCQUFDLE9BQUksU0FBUSxRQUFPLEtBQUssR0FBRyxVQUFTLFFBQ2xDNUIsb0JBQVVnRixJQUFLQyxVQUNkLHVCQUFDLFFBQ0MsV0FBVSxlQUVWLE9BQU9BLEtBQUsvRSxPQUNaLFNBQ0V3QixTQUFTRyxhQUFhb0QsS0FBS2hGLEtBQUssV0FBVyxZQUU3QyxPQUFPeUIsU0FBU0csYUFBYW9ELEtBQUtoRixLQUFLLFlBQVksV0FDbkQsU0FBUyxNQUNQMEIsWUFBYTBCLFdBQVU7QUFBQSxVQUFFLEdBQUdBO0FBQUFBLFVBQU14QixVQUFVb0QsS0FBS2hGO0FBQUFBLFFBQUcsRUFBRSxLQVBuRGdGLEtBQUtoRixJQUZaO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFVRyxDQUVKLEtBZEg7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQWVBO0FBQUEsV0FuQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQW9CQTtBQUFBLE1BRUEsdUJBQUMsU0FBSSxXQUFVLGdCQUNiO0FBQUEsK0JBQUMsY0FBVyxTQUFRLGFBQVksWUFBWSxLQUFLLDJCQUFqRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQSxRQUNBLHVCQUFDLE9BQUksV0FBVSxZQUNaa0MsNEJBQWtCNkMsSUFBS0UsVUFDdEIsdUJBQUMsUUFDQyxXQUFVLGVBRVYsT0FBT0EsTUFDUCxTQUFTakQsWUFBWXFCLFNBQVM0QixJQUFJLElBQUksV0FBVyxZQUNqRCxPQUFPakQsWUFBWXFCLFNBQVM0QixJQUFJLElBQUksWUFBWUMsUUFDaEQsU0FBUyxNQUNQbEMsaUJBQWlCaUMsTUFBTWpELGFBQWFDLGNBQWMsR0FFcEQsVUFDRUcsa0JBQWtCaUIsU0FBUzRCLElBQUksSUFDM0IsTUFDRWYsbUJBQ0VlLE1BQ0E5QyxzQkFDQUUsc0JBQ0FKLGNBQ0YsSUFDRmlELFVBaEJERCxNQUZQO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFtQkcsQ0FFSixLQXZCSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBd0JBO0FBQUEsUUFDQSx1QkFBQyxPQUNDLFNBQVEsUUFDUixLQUFLLEdBQ0wsSUFBSTtBQUFBLFVBQUUzRSxRQUFRO0FBQUEsVUFBSTZFLFlBQVk7QUFBQSxRQUFTLEdBRXZDO0FBQUEsaUNBQUMsYUFDQyxPQUFNLGtCQUNOLE1BQUssU0FDTCxPQUFPN0MsaUJBQ1AsT0FBTSxXQUNOLFNBQU8sTUFDUCxVQUFXK0IsT0FBTTlCLG1CQUFtQjhCLEVBQUVlLE9BQU9uQyxLQUFLLEtBTnBEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBTXNEO0FBQUEsVUFFdEQsdUJBQUMsVUFDQyxTQUFRLFlBQ1IsT0FBTSxXQUNOLGNBQVcsa0JBQ1gsU0FBUyxNQUNQTyxjQUNFbEIsaUJBQ0FKLG1CQUNBQyxzQkFDQUMsbUJBQ0FDLHNCQUNBTCxhQUNBQyxnQkFDQU0sa0JBQ0YsR0FFSCxtQkFoQkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFrQkE7QUFBQSxhQS9CRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBZ0NBO0FBQUEsV0E3REY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQThEQTtBQUFBLE1BRUEsdUJBQUMsU0FBSSxXQUFVLGdCQUNiO0FBQUEsK0JBQUMsY0FBVyxTQUFRLGFBQVksWUFBWSxLQUFLLHlCQUFqRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQSxRQUNBLHVCQUFDLE9BQUksV0FBVSxZQUNaRyx5QkFBZXFDLElBQUtNLGFBQ25CLHVCQUFDLFFBQ0MsV0FBVSxlQUVWLE9BQU9BLFNBQ1AsU0FBUzdDLFVBQVVhLFNBQVNnQyxPQUFPLElBQUksV0FBVyxZQUNsRCxPQUFPN0MsVUFBVWEsU0FBU2dDLE9BQU8sSUFBSSxZQUFZSCxRQUNqRCxTQUFTLE1BQ1BsQyxpQkFBaUJxQyxTQUFTN0MsV0FBV0MsWUFBWSxHQUVuRCxVQUNFRyxnQkFBZ0JTLFNBQVNnQyxPQUFPLElBQzVCLE1BQ0VuQixtQkFDRW1CLFNBQ0ExQyxtQkFDQUUsb0JBQ0FKLFlBQ0YsSUFDRnlDLFVBaEJERyxTQUZQO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFtQkcsQ0FFSixLQXZCSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBd0JBO0FBQUEsUUFDQSx1QkFBQyxPQUFJLFNBQVEsUUFBTyxLQUFLLEdBQUcsSUFBSSxHQUM5QjtBQUFBLGlDQUFDLGFBQ0MsT0FBTSxlQUNOLE1BQUssU0FDTCxTQUFPLE1BQ1AsT0FBTSxXQUNOLE9BQU92QyxjQUNQLFVBQVd1QixPQUFNdEIsZ0JBQWdCc0IsRUFBRWUsT0FBT25DLEtBQUssS0FOakQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFNbUQ7QUFBQSxVQUVuRCx1QkFBQyxVQUNDLFNBQVEsWUFDUixPQUFNLFdBQ04sY0FBVyxlQUNYLFNBQVMsTUFDUE8sY0FDRVYsY0FDQUosZ0JBQ0FDLG1CQUNBQyxpQkFDQUMsb0JBQ0FMLFdBQ0FDLGNBQ0FNLGVBQ0YsR0FFSCxtQkFoQkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFrQkE7QUFBQSxhQTNCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBNEJBO0FBQUEsV0F6REY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQTBEQTtBQUFBLE1BRUEsdUJBQUMsU0FBSSxXQUFVLGdCQUNiO0FBQUEsK0JBQUMsY0FBVyxTQUFRLGFBQVksWUFBWSxLQUFLLGdDQUFqRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQSxRQUNBLHVCQUFDLGFBQ0MsV0FBUyxNQUNULE1BQU0sR0FDTixhQUFZLDZDQUNaLFdBQVMsTUFDVCxPQUFNLFdBQ04sT0FBT3RCLFNBQVNJLE9BQ2hCLFVBQVd3QyxPQUNUM0MsWUFBWTtBQUFBLFVBQUUsR0FBR0Q7QUFBQUEsVUFBVUksT0FBT3dDLEVBQUVlLE9BQU9uQztBQUFBQSxRQUFNLENBQUMsS0FSdEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVNHO0FBQUEsV0FiTDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBZUE7QUFBQSxNQUVBLHVCQUFDLE9BQUksV0FBVSxVQUFTLElBQUksR0FDMUIsaUNBQUMsVUFDQyxNQUFLLFVBQ0wsU0FBUSxhQUNSLE9BQU0sV0FDTixJQUFJO0FBQUEsUUFBRXdCLElBQUk7QUFBQSxRQUFHYSxJQUFJO0FBQUEsUUFBS0MsWUFBWTtBQUFBLE1BQUksR0FDdEMsVUFBVWhFLFdBRVRBLHNCQUNDLHVCQUFDLG9CQUFpQixNQUFNLElBQUksSUFBSTtBQUFBLFFBQUVsQixPQUFPO0FBQUEsTUFBTyxLQUFoRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQWtELElBRWxELHFCQVZKO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFZQSxLQWJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFjQTtBQUFBLFNBeE1GO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0F5TUE7QUFBQSxPQTNORjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBNE5BLEtBaE9GO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FpT0E7QUFFSjtBQUFDaUIsR0EvU1FELGtCQUFnQjtBQUFBbUUsTUFBaEJuRTtBQWlUVCxlQUFlQTtBQUFpQixJQUFBRCxJQUFBb0U7QUFBQUMsYUFBQXJFLElBQUE7QUFBQXFFLGFBQUFELEtBQUEiLCJuYW1lcyI6WyJCb3giLCJCdXR0b24iLCJDaGlwIiwiQ2lyY3VsYXJQcm9ncmVzcyIsIkNvbnRhaW5lciIsIlNsaWRlciIsIlRleHRGaWVsZCIsIlR5cG9ncmFwaHkiLCJzdHlsZWQiLCJ1c2VTdGF0ZSIsIm1lYWxUeXBlcyIsImlkIiwibGFiZWwiLCJkZWZhdWx0UHJlZmVyZW5jZXMiLCJkZWZhdWx0QWxsZXJnaWVzIiwiUHJldHRvU2xpZGVyIiwiY29sb3IiLCJoZWlnaHQiLCJtYXhXaWR0aCIsImJvcmRlciIsIndpZHRoIiwiYmFja2dyb3VuZENvbG9yIiwiYm94U2hhZG93IiwiZGlzcGxheSIsImxpbmVIZWlnaHQiLCJmb250U2l6ZSIsImJhY2tncm91bmQiLCJwYWRkaW5nIiwiYm9yZGVyUmFkaXVzIiwidHJhbnNmb3JtT3JpZ2luIiwidHJhbnNmb3JtIiwiX2MiLCJSZWNpcGVHZW5lcmF0aW9uIiwiX3MiLCJpc0xvYWRpbmciLCJzZXRJc0xvYWRpbmciLCJmb3JtRGF0YSIsInNldEZvcm1EYXRhIiwic2VydmluZ3MiLCJtZWFsVHlwZSIsIm5vdGVzIiwiZXJyb3JzIiwic2V0RXJyb3JzIiwicHJlZmVyZW5jZXMiLCJzZXRQcmVmZXJlbmNlcyIsInByZWZlcmVuY2VPcHRpb25zIiwic2V0UHJlZmVyZW5jZU9wdGlvbnMiLCJjdXN0b21QcmVmZXJlbmNlcyIsInNldEN1c3RvbVByZWZlcmVuY2VzIiwicHJlZmVyZW5jZUlucHV0Iiwic2V0UHJlZmVyZW5jZUlucHV0IiwiYWxsZXJnaWVzIiwic2V0QWxsZXJnaWVzIiwiYWxsZXJneU9wdGlvbnMiLCJzZXRBbGxlcmd5T3B0aW9ucyIsImN1c3RvbUFsbGVyZ2llcyIsInNldEN1c3RvbUFsbGVyZ2llcyIsImFsbGVyZ3lJbnB1dCIsInNldEFsbGVyZ3lJbnB1dCIsImhhbmRsZUNoaXBUb2dnbGUiLCJ2YWx1ZSIsImxpc3QiLCJzZXRMaXN0IiwicHJldiIsImluY2x1ZGVzIiwiZmlsdGVyIiwidiIsImhhbmRsZUFkZENoaXAiLCJvcHRpb25zIiwic2V0T3B0aW9ucyIsImN1c3RvbSIsInNldEN1c3RvbSIsInNlbGVjdGVkIiwic2V0U2VsZWN0ZWQiLCJzZXRJbnB1dCIsInRyaW1tZWQiLCJ0cmltIiwiaGFuZGxlRGVsZXRlQ3VzdG9tIiwiaXRlbSIsImhhbmRsZVN1Ym1pdCIsImUiLCJwcmV2ZW50RGVmYXVsdCIsIm5ld0Vycm9ycyIsInNldFRpbWVvdXQiLCJweCIsInhzIiwic20iLCJtZCIsIl8iLCJ2YWwiLCJtYXAiLCJ0eXBlIiwicHJlZiIsInVuZGVmaW5lZCIsImFsaWduSXRlbXMiLCJ0YXJnZXQiLCJhbGxlcmd5IiwicHkiLCJmb250V2VpZ2h0IiwiX2MyIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiUmVjaXBlR2VuZXJhdGlvbi50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHtcclxuICBCb3gsXHJcbiAgQnV0dG9uLFxyXG4gIENoaXAsXHJcbiAgQ2lyY3VsYXJQcm9ncmVzcyxcclxuICBDb250YWluZXIsXHJcbiAgU2xpZGVyLFxyXG4gIFRleHRGaWVsZCxcclxuICBUeXBvZ3JhcGh5LFxyXG59IGZyb20gXCJAbXVpL21hdGVyaWFsXCI7XHJcbmltcG9ydCB7IHN0eWxlZCB9IGZyb20gXCJAbXVpL21hdGVyaWFsL3N0eWxlc1wiO1xyXG5pbXBvcnQgUmVhY3QsIHsgdXNlU3RhdGUgfSBmcm9tIFwicmVhY3RcIjtcclxuaW1wb3J0IFwiLi4vc3R5bGVzL3JlY2lwZUdlbmVyYXRpb24uY3NzXCI7XHJcblxyXG5jb25zdCBtZWFsVHlwZXMgPSBbXHJcbiAgeyBpZDogXCJtYWluXCIsIGxhYmVsOiBcIk1haW5cIiB9LFxyXG4gIHsgaWQ6IFwiYXBwZXRpemVyXCIsIGxhYmVsOiBcIkFwcGV0aXplclwiIH0sXHJcbiAgeyBpZDogXCJkZXNzZXJ0XCIsIGxhYmVsOiBcIkRlc3NlcnRcIiB9LFxyXG4gIHsgaWQ6IFwiYnJlYWtmYXN0XCIsIGxhYmVsOiBcIkJyZWFrZmFzdFwiIH0sXHJcbiAgeyBpZDogXCJzbmFja1wiLCBsYWJlbDogXCJTbmFja1wiIH0sXHJcbl07XHJcblxyXG5jb25zdCBkZWZhdWx0UHJlZmVyZW5jZXMgPSBbXHJcbiAgXCJBbWVyaWNhblwiLFxyXG4gIFwiSXRhbGlhblwiLFxyXG4gIFwiQ2hpbmVzZVwiLFxyXG4gIFwiTWV4aWNhblwiLFxyXG4gIFwiSmFwYW5lc2VcIixcclxuICBcIkluZGlhblwiLFxyXG4gIFwiTWlkZGxlIEVhc3Rlcm5cIixcclxuICBcIlRoYWlcIixcclxuXTtcclxuXHJcbmNvbnN0IGRlZmF1bHRBbGxlcmdpZXMgPSBbXHJcbiAgXCJHbHV0ZW5cIixcclxuICBcIkRhaXJ5XCIsXHJcbiAgXCJOdXRzXCIsXHJcbiAgXCJFZ2dzXCIsXHJcbiAgXCJTb3lcIixcclxuICBcIlNoZWxsZmlzaFwiLFxyXG5dO1xyXG5cclxuY29uc3QgUHJldHRvU2xpZGVyID0gc3R5bGVkKFNsaWRlcikoe1xyXG4gIGNvbG9yOiBcIiM1MmFmNzdcIixcclxuICBoZWlnaHQ6IDgsXHJcbiAgbWF4V2lkdGg6IDMwMCxcclxuICBcIiYgLk11aVNsaWRlci10cmFja1wiOiB7IGJvcmRlcjogXCJub25lXCIgfSxcclxuICBcIiYgLk11aVNsaWRlci10aHVtYlwiOiB7XHJcbiAgICBoZWlnaHQ6IDI0LFxyXG4gICAgd2lkdGg6IDI0LFxyXG4gICAgYmFja2dyb3VuZENvbG9yOiBcIiNmZmZcIixcclxuICAgIGJvcmRlcjogXCIycHggc29saWQgY3VycmVudENvbG9yXCIsXHJcbiAgICBcIiY6Zm9jdXMsICY6aG92ZXIsICYuTXVpLWFjdGl2ZSwgJi5NdWktZm9jdXNWaXNpYmxlXCI6IHtcclxuICAgICAgYm94U2hhZG93OiBcImluaGVyaXRcIixcclxuICAgIH0sXHJcbiAgICBcIiY6OmJlZm9yZVwiOiB7IGRpc3BsYXk6IFwibm9uZVwiIH0sXHJcbiAgfSxcclxuICBcIiYgLk11aVNsaWRlci12YWx1ZUxhYmVsXCI6IHtcclxuICAgIGxpbmVIZWlnaHQ6IDEuMixcclxuICAgIGZvbnRTaXplOiAxMixcclxuICAgIGJhY2tncm91bmQ6IFwidW5zZXRcIixcclxuICAgIHBhZGRpbmc6IDAsXHJcbiAgICB3aWR0aDogMzIsXHJcbiAgICBoZWlnaHQ6IDMyLFxyXG4gICAgYm9yZGVyUmFkaXVzOiBcIjUwJSA1MCUgNTAlIDBcIixcclxuICAgIGJhY2tncm91bmRDb2xvcjogXCIjNTJhZjc3XCIsXHJcbiAgICB0cmFuc2Zvcm1PcmlnaW46IFwiYm90dG9tIGxlZnRcIixcclxuICAgIHRyYW5zZm9ybTogXCJ0cmFuc2xhdGUoNTAlLCAtMTAwJSkgcm90YXRlKC00NWRlZykgc2NhbGUoMClcIixcclxuICAgIFwiJjo6YmVmb3JlXCI6IHsgZGlzcGxheTogXCJub25lXCIgfSxcclxuICAgIFwiJi5NdWlTbGlkZXItdmFsdWVMYWJlbE9wZW5cIjoge1xyXG4gICAgICB0cmFuc2Zvcm06IFwidHJhbnNsYXRlKDUwJSwgLTEwMCUpIHJvdGF0ZSgtNDVkZWcpIHNjYWxlKDEpXCIsXHJcbiAgICB9LFxyXG4gICAgXCImID4gKlwiOiB7XHJcbiAgICAgIHRyYW5zZm9ybTogXCJyb3RhdGUoNDVkZWcpXCIsXHJcbiAgICB9LFxyXG4gIH0sXHJcbn0pO1xyXG5cclxuZnVuY3Rpb24gUmVjaXBlR2VuZXJhdGlvbigpIHtcclxuICBjb25zdCBbaXNMb2FkaW5nLCBzZXRJc0xvYWRpbmddID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gIGNvbnN0IFtmb3JtRGF0YSwgc2V0Rm9ybURhdGFdID0gdXNlU3RhdGUoe1xyXG4gICAgc2VydmluZ3M6IDEsXHJcbiAgICBtZWFsVHlwZTogXCJcIixcclxuICAgIG5vdGVzOiBcIlwiLFxyXG4gIH0pO1xyXG4gIGNvbnN0IFtlcnJvcnMsIHNldEVycm9yc10gPSB1c2VTdGF0ZSh7IHNlcnZpbmdzOiBmYWxzZSwgbWVhbFR5cGU6IGZhbHNlIH0pO1xyXG5cclxuICBjb25zdCBbcHJlZmVyZW5jZXMsIHNldFByZWZlcmVuY2VzXSA9IHVzZVN0YXRlPHN0cmluZ1tdPihbXSk7XHJcbiAgY29uc3QgW3ByZWZlcmVuY2VPcHRpb25zLCBzZXRQcmVmZXJlbmNlT3B0aW9uc10gPSB1c2VTdGF0ZTxzdHJpbmdbXT4oW1xyXG4gICAgLi4uZGVmYXVsdFByZWZlcmVuY2VzLFxyXG4gIF0pO1xyXG4gIGNvbnN0IFtjdXN0b21QcmVmZXJlbmNlcywgc2V0Q3VzdG9tUHJlZmVyZW5jZXNdID0gdXNlU3RhdGU8c3RyaW5nW10+KFtdKTtcclxuICBjb25zdCBbcHJlZmVyZW5jZUlucHV0LCBzZXRQcmVmZXJlbmNlSW5wdXRdID0gdXNlU3RhdGU8c3RyaW5nPihcIlwiKTtcclxuXHJcbiAgY29uc3QgW2FsbGVyZ2llcywgc2V0QWxsZXJnaWVzXSA9IHVzZVN0YXRlPHN0cmluZ1tdPihbXSk7XHJcbiAgY29uc3QgW2FsbGVyZ3lPcHRpb25zLCBzZXRBbGxlcmd5T3B0aW9uc10gPSB1c2VTdGF0ZTxzdHJpbmdbXT4oW1xyXG4gICAgLi4uZGVmYXVsdEFsbGVyZ2llcyxcclxuICBdKTtcclxuICBjb25zdCBbY3VzdG9tQWxsZXJnaWVzLCBzZXRDdXN0b21BbGxlcmdpZXNdID0gdXNlU3RhdGU8c3RyaW5nW10+KFtdKTtcclxuICBjb25zdCBbYWxsZXJneUlucHV0LCBzZXRBbGxlcmd5SW5wdXRdID0gdXNlU3RhdGU8c3RyaW5nPihcIlwiKTtcclxuXHJcbiAgY29uc3QgaGFuZGxlQ2hpcFRvZ2dsZSA9IChcclxuICAgIHZhbHVlOiBzdHJpbmcsXHJcbiAgICBsaXN0OiBzdHJpbmdbXSxcclxuICAgIHNldExpc3Q6IFJlYWN0LkRpc3BhdGNoPFJlYWN0LlNldFN0YXRlQWN0aW9uPHN0cmluZ1tdPj5cclxuICApID0+IHtcclxuICAgIHNldExpc3QoKHByZXYpID0+XHJcbiAgICAgIHByZXYuaW5jbHVkZXModmFsdWUpID8gcHJldi5maWx0ZXIoKHYpID0+IHYgIT09IHZhbHVlKSA6IFsuLi5wcmV2LCB2YWx1ZV1cclxuICAgICk7XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgaGFuZGxlQWRkQ2hpcCA9IChcclxuICAgIHZhbHVlOiBzdHJpbmcsXHJcbiAgICBvcHRpb25zOiBzdHJpbmdbXSxcclxuICAgIHNldE9wdGlvbnM6IFJlYWN0LkRpc3BhdGNoPFJlYWN0LlNldFN0YXRlQWN0aW9uPHN0cmluZ1tdPj4sXHJcbiAgICBjdXN0b206IHN0cmluZ1tdLFxyXG4gICAgc2V0Q3VzdG9tOiBSZWFjdC5EaXNwYXRjaDxSZWFjdC5TZXRTdGF0ZUFjdGlvbjxzdHJpbmdbXT4+LFxyXG4gICAgc2VsZWN0ZWQ6IHN0cmluZ1tdLFxyXG4gICAgc2V0U2VsZWN0ZWQ6IFJlYWN0LkRpc3BhdGNoPFJlYWN0LlNldFN0YXRlQWN0aW9uPHN0cmluZ1tdPj4sXHJcbiAgICBzZXRJbnB1dDogUmVhY3QuRGlzcGF0Y2g8UmVhY3QuU2V0U3RhdGVBY3Rpb248c3RyaW5nPj5cclxuICApID0+IHtcclxuICAgIGNvbnN0IHRyaW1tZWQgPSB2YWx1ZS50cmltKCk7XHJcbiAgICBpZiAodHJpbW1lZCAmJiAhb3B0aW9ucy5pbmNsdWRlcyh0cmltbWVkKSAmJiAhY3VzdG9tLmluY2x1ZGVzKHRyaW1tZWQpKSB7XHJcbiAgICAgIHNldE9wdGlvbnMoKHByZXYpID0+IFsuLi5wcmV2LCB0cmltbWVkXSk7XHJcbiAgICAgIHNldEN1c3RvbSgocHJldikgPT4gWy4uLnByZXYsIHRyaW1tZWRdKTtcclxuICAgICAgc2V0U2VsZWN0ZWQoKHByZXYpID0+IFsuLi5wcmV2LCB0cmltbWVkXSk7XHJcbiAgICAgIHNldElucHV0KFwiXCIpO1xyXG4gICAgfVxyXG4gIH07XHJcblxyXG4gIGNvbnN0IGhhbmRsZURlbGV0ZUN1c3RvbSA9IChcclxuICAgIGl0ZW06IHN0cmluZyxcclxuICAgIHNldE9wdGlvbnM6IFJlYWN0LkRpc3BhdGNoPFJlYWN0LlNldFN0YXRlQWN0aW9uPHN0cmluZ1tdPj4sXHJcbiAgICBzZXRTZWxlY3RlZDogUmVhY3QuRGlzcGF0Y2g8UmVhY3QuU2V0U3RhdGVBY3Rpb248c3RyaW5nW10+PixcclxuICAgIHNldEN1c3RvbTogUmVhY3QuRGlzcGF0Y2g8UmVhY3QuU2V0U3RhdGVBY3Rpb248c3RyaW5nW10+PlxyXG4gICkgPT4ge1xyXG4gICAgc2V0T3B0aW9ucygocHJldikgPT4gcHJldi5maWx0ZXIoKHYpID0+IHYgIT09IGl0ZW0pKTtcclxuICAgIHNldFNlbGVjdGVkKChwcmV2KSA9PiBwcmV2LmZpbHRlcigodikgPT4gdiAhPT0gaXRlbSkpO1xyXG4gICAgc2V0Q3VzdG9tKChwcmV2KSA9PiBwcmV2LmZpbHRlcigodikgPT4gdiAhPT0gaXRlbSkpO1xyXG4gIH07XHJcblxyXG4gIGNvbnN0IGhhbmRsZVN1Ym1pdCA9IChlOiBSZWFjdC5Gb3JtRXZlbnQpID0+IHtcclxuICAgIGUucHJldmVudERlZmF1bHQoKTtcclxuICAgIGNvbnN0IG5ld0Vycm9ycyA9IHtcclxuICAgICAgc2VydmluZ3M6IGZvcm1EYXRhLnNlcnZpbmdzIDwgMSxcclxuICAgICAgbWVhbFR5cGU6ICFmb3JtRGF0YS5tZWFsVHlwZSxcclxuICAgIH07XHJcbiAgICBzZXRFcnJvcnMobmV3RXJyb3JzKTtcclxuICAgIGlmIChuZXdFcnJvcnMuc2VydmluZ3MgfHwgbmV3RXJyb3JzLm1lYWxUeXBlKSByZXR1cm47XHJcbiAgICBzZXRJc0xvYWRpbmcodHJ1ZSk7XHJcbiAgICBzZXRUaW1lb3V0KCgpID0+IHNldElzTG9hZGluZyhmYWxzZSksIDMwMDApO1xyXG4gIH07XHJcblxyXG4gIHJldHVybiAoXHJcbiAgICA8Q29udGFpbmVyXHJcbiAgICAgIG1heFdpZHRoPVwibWRcIlxyXG4gICAgICBzeD17eyB3aWR0aDogXCI5MDBweFwiLCBweDogeyB4czogMiwgc206IDMsIG1kOiA0IH0gfX1cclxuICAgID5cclxuICAgICAgPEJveCB3aWR0aD1cIjEwMCVcIj5cclxuICAgICAgICA8VHlwb2dyYXBoeVxyXG4gICAgICAgICAgdmFyaWFudD1cImg1XCJcclxuICAgICAgICAgIGZvbnRXZWlnaHQ9ezYwMH1cclxuICAgICAgICAgIHRleHRBbGlnbj1cImNlbnRlclwiXHJcbiAgICAgICAgICBndXR0ZXJCb3R0b21cclxuICAgICAgICA+XHJcbiAgICAgICAgICBHZW5lcmF0ZSBZb3VyIFBlcmZlY3QgUmVjaXBlXHJcbiAgICAgICAgPC9UeXBvZ3JhcGh5PlxyXG4gICAgICAgIDxUeXBvZ3JhcGh5XHJcbiAgICAgICAgICB2YXJpYW50PVwiYm9keTJcIlxyXG4gICAgICAgICAgdGV4dEFsaWduPVwiY2VudGVyXCJcclxuICAgICAgICAgIGNvbG9yPVwidGV4dC5zZWNvbmRhcnlcIlxyXG4gICAgICAgICAgbWI9ezJ9XHJcbiAgICAgICAgPlxyXG4gICAgICAgICAgQmFzZWQgb24geW91ciBwcmVmZXJlbmNlcywgZGlldGFyeSBuZWVkcywgYW5kIGF2YWlsYWJsZSBpbmdyZWRpZW50cy5cclxuICAgICAgICA8L1R5cG9ncmFwaHk+XHJcblxyXG4gICAgICAgIDxmb3JtIG9uU3VibWl0PXtoYW5kbGVTdWJtaXR9IGNsYXNzTmFtZT1cImZvcm0tY29udGFpbmVyXCI+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZvcm0tc2VjdGlvblwiPlxyXG4gICAgICAgICAgICA8VHlwb2dyYXBoeSB2YXJpYW50PVwic3VidGl0bGUxXCIgZm9udFdlaWdodD17NjAwfT5cclxuICAgICAgICAgICAgICBIb3cgbWFueSBzZXJ2aW5ncz8gPHNwYW4gY2xhc3NOYW1lPVwicmVxdWlyZWRcIj4qPC9zcGFuPlxyXG4gICAgICAgICAgICA8L1R5cG9ncmFwaHk+XHJcbiAgICAgICAgICAgIDxCb3ggZGlzcGxheT1cImZsZXhcIiBhbGlnbkl0ZW1zPVwiY2VudGVyXCIgZ2FwPXsyfT5cclxuICAgICAgICAgICAgICA8UHJldHRvU2xpZGVyXHJcbiAgICAgICAgICAgICAgICB2YWx1ZT17Zm9ybURhdGEuc2VydmluZ3N9XHJcbiAgICAgICAgICAgICAgICBvbkNoYW5nZT17KF8sIHZhbCkgPT5cclxuICAgICAgICAgICAgICAgICAgc2V0Rm9ybURhdGEoKHByZXYpID0+ICh7IC4uLnByZXYsIHNlcnZpbmdzOiB2YWwgYXMgbnVtYmVyIH0pKVxyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgdmFsdWVMYWJlbERpc3BsYXk9XCJhdXRvXCJcclxuICAgICAgICAgICAgICAgIGRlZmF1bHRWYWx1ZT17MX1cclxuICAgICAgICAgICAgICAgIG1pbj17MH1cclxuICAgICAgICAgICAgICAgIG1heD17MTB9XHJcbiAgICAgICAgICAgICAgICBjb2xvcj17ZXJyb3JzLnNlcnZpbmdzID8gXCJlcnJvclwiIDogXCJzdWNjZXNzXCJ9XHJcbiAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICA8VHlwb2dyYXBoeSBkYXRhLXRlc3RpZD1cInNlcnZpbmctdmFsdWVcIj5cclxuICAgICAgICAgICAgICAgIHtmb3JtRGF0YS5zZXJ2aW5nc31cclxuICAgICAgICAgICAgICA8L1R5cG9ncmFwaHk+XHJcbiAgICAgICAgICAgIDwvQm94PlxyXG4gICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmb3JtLXNlY3Rpb25cIj5cclxuICAgICAgICAgICAgPFR5cG9ncmFwaHkgdmFyaWFudD1cInN1YnRpdGxlMVwiIGZvbnRXZWlnaHQ9ezYwMH0+XHJcbiAgICAgICAgICAgICAgV2hhdCBraW5kIG9mIG1lYWw/IDxzcGFuIGNsYXNzTmFtZT1cInJlcXVpcmVkXCI+Kjwvc3Bhbj5cclxuICAgICAgICAgICAgPC9UeXBvZ3JhcGh5PlxyXG4gICAgICAgICAgICA8Qm94IGRpc3BsYXk9XCJmbGV4XCIgZ2FwPXsxfSBmbGV4V3JhcD1cIndyYXBcIj5cclxuICAgICAgICAgICAgICB7bWVhbFR5cGVzLm1hcCgodHlwZSkgPT4gKFxyXG4gICAgICAgICAgICAgICAgPENoaXBcclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiY3VzdG9tLWNoaXBcIlxyXG4gICAgICAgICAgICAgICAgICBrZXk9e3R5cGUuaWR9XHJcbiAgICAgICAgICAgICAgICAgIGxhYmVsPXt0eXBlLmxhYmVsfVxyXG4gICAgICAgICAgICAgICAgICB2YXJpYW50PXtcclxuICAgICAgICAgICAgICAgICAgICBmb3JtRGF0YS5tZWFsVHlwZSA9PT0gdHlwZS5pZCA/IFwiZmlsbGVkXCIgOiBcIm91dGxpbmVkXCJcclxuICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICBjb2xvcj17Zm9ybURhdGEubWVhbFR5cGUgPT09IHR5cGUuaWQgPyBcInN1Y2Nlc3NcIiA6IFwiZGVmYXVsdFwifVxyXG4gICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PlxyXG4gICAgICAgICAgICAgICAgICAgIHNldEZvcm1EYXRhKChwcmV2KSA9PiAoeyAuLi5wcmV2LCBtZWFsVHlwZTogdHlwZS5pZCB9KSlcclxuICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgPC9Cb3g+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZvcm0tc2VjdGlvblwiPlxyXG4gICAgICAgICAgICA8VHlwb2dyYXBoeSB2YXJpYW50PVwic3VidGl0bGUxXCIgZm9udFdlaWdodD17NjAwfT5cclxuICAgICAgICAgICAgICBQcmVmZXJlbmNlc1xyXG4gICAgICAgICAgICA8L1R5cG9ncmFwaHk+XHJcbiAgICAgICAgICAgIDxCb3ggY2xhc3NOYW1lPVwiY2hpcC1yb3dcIj5cclxuICAgICAgICAgICAgICB7cHJlZmVyZW5jZU9wdGlvbnMubWFwKChwcmVmKSA9PiAoXHJcbiAgICAgICAgICAgICAgICA8Q2hpcFxyXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJjdXN0b20tY2hpcFwiXHJcbiAgICAgICAgICAgICAgICAgIGtleT17cHJlZn1cclxuICAgICAgICAgICAgICAgICAgbGFiZWw9e3ByZWZ9XHJcbiAgICAgICAgICAgICAgICAgIHZhcmlhbnQ9e3ByZWZlcmVuY2VzLmluY2x1ZGVzKHByZWYpID8gXCJmaWxsZWRcIiA6IFwib3V0bGluZWRcIn1cclxuICAgICAgICAgICAgICAgICAgY29sb3I9e3ByZWZlcmVuY2VzLmluY2x1ZGVzKHByZWYpID8gXCJzdWNjZXNzXCIgOiB1bmRlZmluZWR9XHJcbiAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+XHJcbiAgICAgICAgICAgICAgICAgICAgaGFuZGxlQ2hpcFRvZ2dsZShwcmVmLCBwcmVmZXJlbmNlcywgc2V0UHJlZmVyZW5jZXMpXHJcbiAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgb25EZWxldGU9e1xyXG4gICAgICAgICAgICAgICAgICAgIGN1c3RvbVByZWZlcmVuY2VzLmluY2x1ZGVzKHByZWYpXHJcbiAgICAgICAgICAgICAgICAgICAgICA/ICgpID0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgaGFuZGxlRGVsZXRlQ3VzdG9tKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcHJlZixcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNldFByZWZlcmVuY2VPcHRpb25zLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgc2V0Q3VzdG9tUHJlZmVyZW5jZXMsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBzZXRQcmVmZXJlbmNlc1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIClcclxuICAgICAgICAgICAgICAgICAgICAgIDogdW5kZWZpbmVkXHJcbiAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgIDwvQm94PlxyXG4gICAgICAgICAgICA8Qm94XHJcbiAgICAgICAgICAgICAgZGlzcGxheT1cImZsZXhcIlxyXG4gICAgICAgICAgICAgIGdhcD17MX1cclxuICAgICAgICAgICAgICBzeD17eyBoZWlnaHQ6IDQwLCBhbGlnbkl0ZW1zOiBcImNlbnRlclwiIH19XHJcbiAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICA8VGV4dEZpZWxkXHJcbiAgICAgICAgICAgICAgICBsYWJlbD1cIkFkZCBQcmVmZXJlbmNlXCJcclxuICAgICAgICAgICAgICAgIHNpemU9XCJzbWFsbFwiXHJcbiAgICAgICAgICAgICAgICB2YWx1ZT17cHJlZmVyZW5jZUlucHV0fVxyXG4gICAgICAgICAgICAgICAgY29sb3I9XCJzdWNjZXNzXCJcclxuICAgICAgICAgICAgICAgIGZvY3VzZWRcclxuICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0UHJlZmVyZW5jZUlucHV0KGUudGFyZ2V0LnZhbHVlKX1cclxuICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgIDxCdXR0b25cclxuICAgICAgICAgICAgICAgIHZhcmlhbnQ9XCJvdXRsaW5lZFwiXHJcbiAgICAgICAgICAgICAgICBjb2xvcj1cInN1Y2Nlc3NcIlxyXG4gICAgICAgICAgICAgICAgYXJpYS1sYWJlbD1cImFkZC1wcmVmZXJlbmNlXCJcclxuICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+XHJcbiAgICAgICAgICAgICAgICAgIGhhbmRsZUFkZENoaXAoXHJcbiAgICAgICAgICAgICAgICAgICAgcHJlZmVyZW5jZUlucHV0LFxyXG4gICAgICAgICAgICAgICAgICAgIHByZWZlcmVuY2VPcHRpb25zLFxyXG4gICAgICAgICAgICAgICAgICAgIHNldFByZWZlcmVuY2VPcHRpb25zLFxyXG4gICAgICAgICAgICAgICAgICAgIGN1c3RvbVByZWZlcmVuY2VzLFxyXG4gICAgICAgICAgICAgICAgICAgIHNldEN1c3RvbVByZWZlcmVuY2VzLFxyXG4gICAgICAgICAgICAgICAgICAgIHByZWZlcmVuY2VzLFxyXG4gICAgICAgICAgICAgICAgICAgIHNldFByZWZlcmVuY2VzLFxyXG4gICAgICAgICAgICAgICAgICAgIHNldFByZWZlcmVuY2VJbnB1dFxyXG4gICAgICAgICAgICAgICAgICApXHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgQWRkXHJcbiAgICAgICAgICAgICAgPC9CdXR0b24+XHJcbiAgICAgICAgICAgIDwvQm94PlxyXG4gICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmb3JtLXNlY3Rpb25cIj5cclxuICAgICAgICAgICAgPFR5cG9ncmFwaHkgdmFyaWFudD1cInN1YnRpdGxlMVwiIGZvbnRXZWlnaHQ9ezYwMH0+XHJcbiAgICAgICAgICAgICAgQWxsZXJnaWVzXHJcbiAgICAgICAgICAgIDwvVHlwb2dyYXBoeT5cclxuICAgICAgICAgICAgPEJveCBjbGFzc05hbWU9XCJjaGlwLXJvd1wiPlxyXG4gICAgICAgICAgICAgIHthbGxlcmd5T3B0aW9ucy5tYXAoKGFsbGVyZ3kpID0+IChcclxuICAgICAgICAgICAgICAgIDxDaGlwXHJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImN1c3RvbS1jaGlwXCJcclxuICAgICAgICAgICAgICAgICAga2V5PXthbGxlcmd5fVxyXG4gICAgICAgICAgICAgICAgICBsYWJlbD17YWxsZXJneX1cclxuICAgICAgICAgICAgICAgICAgdmFyaWFudD17YWxsZXJnaWVzLmluY2x1ZGVzKGFsbGVyZ3kpID8gXCJmaWxsZWRcIiA6IFwib3V0bGluZWRcIn1cclxuICAgICAgICAgICAgICAgICAgY29sb3I9e2FsbGVyZ2llcy5pbmNsdWRlcyhhbGxlcmd5KSA/IFwic3VjY2Vzc1wiIDogdW5kZWZpbmVkfVxyXG4gICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PlxyXG4gICAgICAgICAgICAgICAgICAgIGhhbmRsZUNoaXBUb2dnbGUoYWxsZXJneSwgYWxsZXJnaWVzLCBzZXRBbGxlcmdpZXMpXHJcbiAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgb25EZWxldGU9e1xyXG4gICAgICAgICAgICAgICAgICAgIGN1c3RvbUFsbGVyZ2llcy5pbmNsdWRlcyhhbGxlcmd5KVxyXG4gICAgICAgICAgICAgICAgICAgICAgPyAoKSA9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGhhbmRsZURlbGV0ZUN1c3RvbShcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGFsbGVyZ3ksXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBzZXRBbGxlcmd5T3B0aW9ucyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNldEN1c3RvbUFsbGVyZ2llcyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNldEFsbGVyZ2llc1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIClcclxuICAgICAgICAgICAgICAgICAgICAgIDogdW5kZWZpbmVkXHJcbiAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgIDwvQm94PlxyXG4gICAgICAgICAgICA8Qm94IGRpc3BsYXk9XCJmbGV4XCIgZ2FwPXsxfSBtdD17MX0+XHJcbiAgICAgICAgICAgICAgPFRleHRGaWVsZFxyXG4gICAgICAgICAgICAgICAgbGFiZWw9XCJBZGQgQWxsZXJneVwiXHJcbiAgICAgICAgICAgICAgICBzaXplPVwic21hbGxcIlxyXG4gICAgICAgICAgICAgICAgZm9jdXNlZFxyXG4gICAgICAgICAgICAgICAgY29sb3I9XCJzdWNjZXNzXCJcclxuICAgICAgICAgICAgICAgIHZhbHVlPXthbGxlcmd5SW5wdXR9XHJcbiAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldEFsbGVyZ3lJbnB1dChlLnRhcmdldC52YWx1ZSl9XHJcbiAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICA8QnV0dG9uXHJcbiAgICAgICAgICAgICAgICB2YXJpYW50PVwib3V0bGluZWRcIlxyXG4gICAgICAgICAgICAgICAgY29sb3I9XCJzdWNjZXNzXCJcclxuICAgICAgICAgICAgICAgIGFyaWEtbGFiZWw9XCJhZGQtYWxsZXJneVwiXHJcbiAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PlxyXG4gICAgICAgICAgICAgICAgICBoYW5kbGVBZGRDaGlwKFxyXG4gICAgICAgICAgICAgICAgICAgIGFsbGVyZ3lJbnB1dCxcclxuICAgICAgICAgICAgICAgICAgICBhbGxlcmd5T3B0aW9ucyxcclxuICAgICAgICAgICAgICAgICAgICBzZXRBbGxlcmd5T3B0aW9ucyxcclxuICAgICAgICAgICAgICAgICAgICBjdXN0b21BbGxlcmdpZXMsXHJcbiAgICAgICAgICAgICAgICAgICAgc2V0Q3VzdG9tQWxsZXJnaWVzLFxyXG4gICAgICAgICAgICAgICAgICAgIGFsbGVyZ2llcyxcclxuICAgICAgICAgICAgICAgICAgICBzZXRBbGxlcmdpZXMsXHJcbiAgICAgICAgICAgICAgICAgICAgc2V0QWxsZXJneUlucHV0XHJcbiAgICAgICAgICAgICAgICAgIClcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICBBZGRcclxuICAgICAgICAgICAgICA8L0J1dHRvbj5cclxuICAgICAgICAgICAgPC9Cb3g+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZvcm0tc2VjdGlvblwiPlxyXG4gICAgICAgICAgICA8VHlwb2dyYXBoeSB2YXJpYW50PVwic3VidGl0bGUxXCIgZm9udFdlaWdodD17NjAwfT5cclxuICAgICAgICAgICAgICBOb3RlcyAoT3B0aW9uYWwpXHJcbiAgICAgICAgICAgIDwvVHlwb2dyYXBoeT5cclxuICAgICAgICAgICAgPFRleHRGaWVsZFxyXG4gICAgICAgICAgICAgIG11bHRpbGluZVxyXG4gICAgICAgICAgICAgIHJvd3M9ezN9XHJcbiAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJBbnkgc3BlY2lmaWMgcHJlZmVyZW5jZXMgb3IgaW5zdHJ1Y3Rpb25zP1wiXHJcbiAgICAgICAgICAgICAgZnVsbFdpZHRoXHJcbiAgICAgICAgICAgICAgY29sb3I9XCJzdWNjZXNzXCJcclxuICAgICAgICAgICAgICB2YWx1ZT17Zm9ybURhdGEubm90ZXN9XHJcbiAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PlxyXG4gICAgICAgICAgICAgICAgc2V0Rm9ybURhdGEoeyAuLi5mb3JtRGF0YSwgbm90ZXM6IGUudGFyZ2V0LnZhbHVlIH0pXHJcbiAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAvPlxyXG4gICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgPEJveCB0ZXh0QWxpZ249XCJjZW50ZXJcIiBtdD17NH0+XHJcbiAgICAgICAgICAgIDxCdXR0b25cclxuICAgICAgICAgICAgICB0eXBlPVwic3VibWl0XCJcclxuICAgICAgICAgICAgICB2YXJpYW50PVwiY29udGFpbmVkXCJcclxuICAgICAgICAgICAgICBjb2xvcj1cInN1Y2Nlc3NcIlxyXG4gICAgICAgICAgICAgIHN4PXt7IHB4OiA0LCBweTogMS41LCBmb250V2VpZ2h0OiA1MDAgfX1cclxuICAgICAgICAgICAgICBkaXNhYmxlZD17aXNMb2FkaW5nfVxyXG4gICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAge2lzTG9hZGluZyA/IChcclxuICAgICAgICAgICAgICAgIDxDaXJjdWxhclByb2dyZXNzIHNpemU9ezI0fSBzeD17eyBjb2xvcjogXCIjZmZmXCIgfX0gLz5cclxuICAgICAgICAgICAgICApIDogKFxyXG4gICAgICAgICAgICAgICAgXCJHZW5lcmF0ZSBSZWNpcGVcIlxyXG4gICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgIDwvQnV0dG9uPlxyXG4gICAgICAgICAgPC9Cb3g+XHJcbiAgICAgICAgPC9mb3JtPlxyXG4gICAgICA8L0JveD5cclxuICAgIDwvQ29udGFpbmVyPlxyXG4gICk7XHJcbn1cclxuXHJcbmV4cG9ydCBkZWZhdWx0IFJlY2lwZUdlbmVyYXRpb247XHJcbiJdLCJmaWxlIjoiQzovVXNlcnMvc19tYXIvY3MzMi9TbmFja1N0YWNrL2NsaWVudC9zcmMvcGFnZXMvUmVjaXBlR2VuZXJhdGlvbi50c3gifQ==