import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/Home.tsx");import { Fragment, jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/s_mar/cs32/SnackStack/client/src/components/Home.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import KitchenOutlinedIcon from "/node_modules/.vite/deps/@mui_icons-material_KitchenOutlined.js?v=b14ee716";
import RestaurantMenuIcon from "/node_modules/.vite/deps/@mui_icons-material_RestaurantMenu.js?v=b14ee716";
import { Card, CardActionArea, CardContent, Typography, Button } from "/node_modules/.vite/deps/@mui_material.js?v=b14ee716";
import { green } from "/node_modules/.vite/deps/@mui_material_colors.js?v=b14ee716";
import { Link } from "/node_modules/.vite/deps/react-router-dom.js?v=b14ee716";
import "/src/styles/Home.css";
function Home() {
  return /* @__PURE__ */ jsxDEV(Fragment, { children: [
    /* @__PURE__ */ jsxDEV("div", { className: "hero-section", children: [
      /* @__PURE__ */ jsxDEV("h1", { className: "main-title", children: "Transform Your Ingredients into Delicious Meals" }, void 0, false, {
        fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/components/Home.tsx",
        lineNumber: 10,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("p", { className: "subtitle", children: "Discover personalized recipes based on what you already have in your kitchen. No more wasted ingredients or last-minute grocery runs." }, void 0, false, {
        fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/components/Home.tsx",
        lineNumber: 13,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/components/Home.tsx",
      lineNumber: 9,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "feature-cards", children: [
      /* @__PURE__ */ jsxDEV(Link, { to: "/cook", className: "feature-card", children: /* @__PURE__ */ jsxDEV(Card, { sx: {
        borderRadius: 3,
        boxShadow: 3
      }, children: /* @__PURE__ */ jsxDEV(CardActionArea, { children: /* @__PURE__ */ jsxDEV(CardContent, { sx: {
        textAlign: "center",
        p: 4
      }, children: [
        /* @__PURE__ */ jsxDEV("div", { className: "icon-container", children: /* @__PURE__ */ jsxDEV(RestaurantMenuIcon, { sx: {
          fontSize: 40,
          color: green[600],
          mb: 2
        } }, void 0, false, {
          fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/components/Home.tsx",
          lineNumber: 31,
          columnNumber: 19
        }, this) }, void 0, false, {
          fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/components/Home.tsx",
          lineNumber: 30,
          columnNumber: 17
        }, this),
        /* @__PURE__ */ jsxDEV(Typography, { variant: "h5", component: "h2", sx: {
          mb: 2,
          color: "#333",
          fontWeight: "bold"
        }, children: "Cook Something Delicious" }, void 0, false, {
          fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/components/Home.tsx",
          lineNumber: 37,
          columnNumber: 17
        }, this),
        /* @__PURE__ */ jsxDEV(Typography, { variant: "body2", color: "text.secondary", sx: {
          mb: 3
        }, children: "Personalized recipe recommendations based on available ingredients, preferences, and dietary needs." }, void 0, false, {
          fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/components/Home.tsx",
          lineNumber: 44,
          columnNumber: 17
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "button-container", children: /* @__PURE__ */ jsxDEV(Button, { variant: "outlined", color: "success", sx: {
          color: green[600]
        }, children: "Find Recipes" }, void 0, false, {
          fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/components/Home.tsx",
          lineNumber: 51,
          columnNumber: 19
        }, this) }, void 0, false, {
          fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/components/Home.tsx",
          lineNumber: 50,
          columnNumber: 17
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/components/Home.tsx",
        lineNumber: 26,
        columnNumber: 15
      }, this) }, void 0, false, {
        fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/components/Home.tsx",
        lineNumber: 25,
        columnNumber: 13
      }, this) }, void 0, false, {
        fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/components/Home.tsx",
        lineNumber: 21,
        columnNumber: 11
      }, this) }, void 0, false, {
        fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/components/Home.tsx",
        lineNumber: 20,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(Link, { to: "/inventory", className: "feature-card", children: /* @__PURE__ */ jsxDEV(Card, { sx: {
        borderRadius: 3,
        boxShadow: 3
      }, children: /* @__PURE__ */ jsxDEV(CardActionArea, { children: /* @__PURE__ */ jsxDEV(CardContent, { sx: {
        textAlign: "center",
        p: 4
      }, children: [
        /* @__PURE__ */ jsxDEV("div", { className: "icon-container", children: /* @__PURE__ */ jsxDEV(KitchenOutlinedIcon, { sx: {
          fontSize: 40,
          color: green[600],
          mb: 2
        } }, void 0, false, {
          fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/components/Home.tsx",
          lineNumber: 73,
          columnNumber: 19
        }, this) }, void 0, false, {
          fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/components/Home.tsx",
          lineNumber: 72,
          columnNumber: 17
        }, this),
        /* @__PURE__ */ jsxDEV(Typography, { variant: "h5", component: "h2", sx: {
          mb: 2,
          color: "#333",
          fontWeight: "bold"
        }, children: "Manage Your Inventory" }, void 0, false, {
          fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/components/Home.tsx",
          lineNumber: 79,
          columnNumber: 17
        }, this),
        /* @__PURE__ */ jsxDEV(Typography, { variant: "body2", color: "text.secondary", sx: {
          mb: 3
        }, children: "Keep track of your ingredients by adding them manually or scanning receipts and food photos." }, void 0, false, {
          fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/components/Home.tsx",
          lineNumber: 86,
          columnNumber: 17
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "button-container", children: /* @__PURE__ */ jsxDEV(Button, { variant: "outlined", color: "success", sx: {
          color: green[600]
        }, children: "Update Inventory" }, void 0, false, {
          fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/components/Home.tsx",
          lineNumber: 93,
          columnNumber: 19
        }, this) }, void 0, false, {
          fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/components/Home.tsx",
          lineNumber: 92,
          columnNumber: 17
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/components/Home.tsx",
        lineNumber: 68,
        columnNumber: 15
      }, this) }, void 0, false, {
        fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/components/Home.tsx",
        lineNumber: 67,
        columnNumber: 13
      }, this) }, void 0, false, {
        fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/components/Home.tsx",
        lineNumber: 63,
        columnNumber: 11
      }, this) }, void 0, false, {
        fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/components/Home.tsx",
        lineNumber: 62,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/components/Home.tsx",
      lineNumber: 19,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/s_mar/cs32/SnackStack/client/src/components/Home.tsx",
    lineNumber: 8,
    columnNumber: 10
  }, this);
}
_c = Home;
export default Home;
var _c;
$RefreshReg$(_c, "Home");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/s_mar/cs32/SnackStack/client/src/components/Home.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBZUksbUJBRUksY0FGSjtBQWZKLE9BQU9BLG9CQUFtQjtBQUFNO0FBQUE7QUFBcUM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQ3JFLE9BQU9DLHdCQUF3QjtBQUMvQixTQUNFQyxNQUNBQyxnQkFDQUMsYUFDQUMsWUFDQUMsY0FDSztBQUNQLFNBQVNDLGFBQWE7QUFDdEIsU0FBU0MsWUFBWTtBQUNyQixPQUFPO0FBRVAsU0FBU0MsT0FBTztBQUNkLFNBQ0UsbUNBQ0U7QUFBQSwyQkFBQyxTQUFJLFdBQVUsZ0JBQ2I7QUFBQSw2QkFBQyxRQUFHLFdBQVUsY0FBYSwrREFBM0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBO0FBQUEsTUFDQSx1QkFBQyxPQUFFLFdBQVUsWUFBVyxxSkFBeEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUdBO0FBQUEsU0FQRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBUUE7QUFBQSxJQUVBLHVCQUFDLFNBQUksV0FBVSxpQkFDYjtBQUFBLDZCQUFDLFFBQUssSUFBRyxTQUFRLFdBQVUsZ0JBQ3pCLGlDQUFDLFFBQUssSUFBSTtBQUFBLFFBQUVDLGNBQWM7QUFBQSxRQUFHQyxXQUFXO0FBQUEsTUFBRSxHQUN4QyxpQ0FBQyxrQkFDQyxpQ0FBQyxlQUFZLElBQUk7QUFBQSxRQUFFQyxXQUFXO0FBQUEsUUFBVUMsR0FBRztBQUFBLE1BQUUsR0FDM0M7QUFBQSwrQkFBQyxTQUFJLFdBQVUsa0JBQ2IsaUNBQUMsc0JBQ0MsSUFBSTtBQUFBLFVBQUVDLFVBQVU7QUFBQSxVQUFJQyxPQUFPUixNQUFNLEdBQUc7QUFBQSxVQUFHUyxJQUFJO0FBQUEsUUFBRSxLQUQvQztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQ2lELEtBRm5EO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFJQTtBQUFBLFFBQ0EsdUJBQUMsY0FDQyxTQUFRLE1BQ1IsV0FBVSxNQUNWLElBQUk7QUFBQSxVQUFFQSxJQUFJO0FBQUEsVUFBR0QsT0FBTztBQUFBLFVBQVFFLFlBQVk7QUFBQSxRQUFPLEdBQ2hELHdDQUpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFNQTtBQUFBLFFBQ0EsdUJBQUMsY0FDQyxTQUFRLFNBQ1IsT0FBTSxrQkFDTixJQUFJO0FBQUEsVUFBRUQsSUFBSTtBQUFBLFFBQUUsR0FDYixtSEFKRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBT0E7QUFBQSxRQUNBLHVCQUFDLFNBQUksV0FBVSxvQkFDYixpQ0FBQyxVQUNDLFNBQVEsWUFDUixPQUFNLFdBQ04sSUFBSTtBQUFBLFVBQUVELE9BQU9SLE1BQU0sR0FBRztBQUFBLFFBQUUsR0FDekIsNEJBSkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQU1BLEtBUEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVFBO0FBQUEsV0E3QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQThCQSxLQS9CRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBZ0NBLEtBakNGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFrQ0EsS0FuQ0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQW9DQTtBQUFBLE1BRUEsdUJBQUMsUUFBSyxJQUFHLGNBQWEsV0FBVSxnQkFDOUIsaUNBQUMsUUFBSyxJQUFJO0FBQUEsUUFBRUcsY0FBYztBQUFBLFFBQUdDLFdBQVc7QUFBQSxNQUFFLEdBQ3hDLGlDQUFDLGtCQUNDLGlDQUFDLGVBQVksSUFBSTtBQUFBLFFBQUVDLFdBQVc7QUFBQSxRQUFVQyxHQUFHO0FBQUEsTUFBRSxHQUMzQztBQUFBLCtCQUFDLFNBQUksV0FBVSxrQkFDYixpQ0FBQyx1QkFDQyxJQUFJO0FBQUEsVUFBRUMsVUFBVTtBQUFBLFVBQUlDLE9BQU9SLE1BQU0sR0FBRztBQUFBLFVBQUdTLElBQUk7QUFBQSxRQUFFLEtBRC9DO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFDaUQsS0FGbkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUlBO0FBQUEsUUFDQSx1QkFBQyxjQUNDLFNBQVEsTUFDUixXQUFVLE1BQ1YsSUFBSTtBQUFBLFVBQUVBLElBQUk7QUFBQSxVQUFHRCxPQUFPO0FBQUEsVUFBUUUsWUFBWTtBQUFBLFFBQU8sR0FDaEQscUNBSkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQU1BO0FBQUEsUUFDQSx1QkFBQyxjQUNDLFNBQVEsU0FDUixPQUFNLGtCQUNOLElBQUk7QUFBQSxVQUFFRCxJQUFJO0FBQUEsUUFBRSxHQUNiLDRHQUpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFPQTtBQUFBLFFBQ0EsdUJBQUMsU0FBSSxXQUFVLG9CQUNiLGlDQUFDLFVBQ0MsU0FBUSxZQUNSLE9BQU0sV0FDTixJQUFJO0FBQUEsVUFBRUQsT0FBT1IsTUFBTSxHQUFHO0FBQUEsUUFBRSxHQUN6QixnQ0FKRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBTUEsS0FQRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBUUE7QUFBQSxXQTdCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBOEJBLEtBL0JGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFnQ0EsS0FqQ0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQWtDQSxLQW5DRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBb0NBO0FBQUEsU0EzRUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQTRFQTtBQUFBLE9BdkZGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0F3RkE7QUFFSjtBQUFDVyxLQTVGUVQ7QUE4RlQsZUFBZUE7QUFBSyxJQUFBUztBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsiS2l0Y2hlbk91dGxpbmVkSWNvbiIsIlJlc3RhdXJhbnRNZW51SWNvbiIsIkNhcmQiLCJDYXJkQWN0aW9uQXJlYSIsIkNhcmRDb250ZW50IiwiVHlwb2dyYXBoeSIsIkJ1dHRvbiIsImdyZWVuIiwiTGluayIsIkhvbWUiLCJib3JkZXJSYWRpdXMiLCJib3hTaGFkb3ciLCJ0ZXh0QWxpZ24iLCJwIiwiZm9udFNpemUiLCJjb2xvciIsIm1iIiwiZm9udFdlaWdodCIsIl9jIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiSG9tZS50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IEtpdGNoZW5PdXRsaW5lZEljb24gZnJvbSBcIkBtdWkvaWNvbnMtbWF0ZXJpYWwvS2l0Y2hlbk91dGxpbmVkXCI7XHJcbmltcG9ydCBSZXN0YXVyYW50TWVudUljb24gZnJvbSBcIkBtdWkvaWNvbnMtbWF0ZXJpYWwvUmVzdGF1cmFudE1lbnVcIjtcclxuaW1wb3J0IHtcclxuICBDYXJkLFxyXG4gIENhcmRBY3Rpb25BcmVhLFxyXG4gIENhcmRDb250ZW50LFxyXG4gIFR5cG9ncmFwaHksXHJcbiAgQnV0dG9uLFxyXG59IGZyb20gXCJAbXVpL21hdGVyaWFsXCI7XHJcbmltcG9ydCB7IGdyZWVuIH0gZnJvbSBcIkBtdWkvbWF0ZXJpYWwvY29sb3JzXCI7XHJcbmltcG9ydCB7IExpbmsgfSBmcm9tIFwicmVhY3Qtcm91dGVyLWRvbVwiO1xyXG5pbXBvcnQgXCIuLi9zdHlsZXMvSG9tZS5jc3NcIjtcclxuXHJcbmZ1bmN0aW9uIEhvbWUoKSB7XHJcbiAgcmV0dXJuIChcclxuICAgIDw+XHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiaGVyby1zZWN0aW9uXCI+XHJcbiAgICAgICAgPGgxIGNsYXNzTmFtZT1cIm1haW4tdGl0bGVcIj5cclxuICAgICAgICAgIFRyYW5zZm9ybSBZb3VyIEluZ3JlZGllbnRzIGludG8gRGVsaWNpb3VzIE1lYWxzXHJcbiAgICAgICAgPC9oMT5cclxuICAgICAgICA8cCBjbGFzc05hbWU9XCJzdWJ0aXRsZVwiPlxyXG4gICAgICAgICAgRGlzY292ZXIgcGVyc29uYWxpemVkIHJlY2lwZXMgYmFzZWQgb24gd2hhdCB5b3UgYWxyZWFkeSBoYXZlIGluIHlvdXJcclxuICAgICAgICAgIGtpdGNoZW4uIE5vIG1vcmUgd2FzdGVkIGluZ3JlZGllbnRzIG9yIGxhc3QtbWludXRlIGdyb2NlcnkgcnVucy5cclxuICAgICAgICA8L3A+XHJcbiAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJmZWF0dXJlLWNhcmRzXCI+XHJcbiAgICAgICAgPExpbmsgdG89XCIvY29va1wiIGNsYXNzTmFtZT1cImZlYXR1cmUtY2FyZFwiPlxyXG4gICAgICAgICAgPENhcmQgc3g9e3sgYm9yZGVyUmFkaXVzOiAzLCBib3hTaGFkb3c6IDMgfX0+XHJcbiAgICAgICAgICAgIDxDYXJkQWN0aW9uQXJlYT5cclxuICAgICAgICAgICAgICA8Q2FyZENvbnRlbnQgc3g9e3sgdGV4dEFsaWduOiBcImNlbnRlclwiLCBwOiA0IH19PlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJpY29uLWNvbnRhaW5lclwiPlxyXG4gICAgICAgICAgICAgICAgICA8UmVzdGF1cmFudE1lbnVJY29uXHJcbiAgICAgICAgICAgICAgICAgICAgc3g9e3sgZm9udFNpemU6IDQwLCBjb2xvcjogZ3JlZW5bNjAwXSwgbWI6IDIgfX1cclxuICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPFR5cG9ncmFwaHlcclxuICAgICAgICAgICAgICAgICAgdmFyaWFudD1cImg1XCJcclxuICAgICAgICAgICAgICAgICAgY29tcG9uZW50PVwiaDJcIlxyXG4gICAgICAgICAgICAgICAgICBzeD17eyBtYjogMiwgY29sb3I6IFwiIzMzM1wiLCBmb250V2VpZ2h0OiBcImJvbGRcIiB9fVxyXG4gICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICBDb29rIFNvbWV0aGluZyBEZWxpY2lvdXNcclxuICAgICAgICAgICAgICAgIDwvVHlwb2dyYXBoeT5cclxuICAgICAgICAgICAgICAgIDxUeXBvZ3JhcGh5XHJcbiAgICAgICAgICAgICAgICAgIHZhcmlhbnQ9XCJib2R5MlwiXHJcbiAgICAgICAgICAgICAgICAgIGNvbG9yPVwidGV4dC5zZWNvbmRhcnlcIlxyXG4gICAgICAgICAgICAgICAgICBzeD17eyBtYjogMyB9fVxyXG4gICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICBQZXJzb25hbGl6ZWQgcmVjaXBlIHJlY29tbWVuZGF0aW9ucyBiYXNlZCBvbiBhdmFpbGFibGVcclxuICAgICAgICAgICAgICAgICAgaW5ncmVkaWVudHMsIHByZWZlcmVuY2VzLCBhbmQgZGlldGFyeSBuZWVkcy5cclxuICAgICAgICAgICAgICAgIDwvVHlwb2dyYXBoeT5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYnV0dG9uLWNvbnRhaW5lclwiPlxyXG4gICAgICAgICAgICAgICAgICA8QnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgICAgdmFyaWFudD1cIm91dGxpbmVkXCJcclxuICAgICAgICAgICAgICAgICAgICBjb2xvcj1cInN1Y2Nlc3NcIlxyXG4gICAgICAgICAgICAgICAgICAgIHN4PXt7IGNvbG9yOiBncmVlbls2MDBdIH19XHJcbiAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICBGaW5kIFJlY2lwZXNcclxuICAgICAgICAgICAgICAgICAgPC9CdXR0b24+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8L0NhcmRDb250ZW50PlxyXG4gICAgICAgICAgICA8L0NhcmRBY3Rpb25BcmVhPlxyXG4gICAgICAgICAgPC9DYXJkPlxyXG4gICAgICAgIDwvTGluaz5cclxuXHJcbiAgICAgICAgPExpbmsgdG89XCIvaW52ZW50b3J5XCIgY2xhc3NOYW1lPVwiZmVhdHVyZS1jYXJkXCI+XHJcbiAgICAgICAgICA8Q2FyZCBzeD17eyBib3JkZXJSYWRpdXM6IDMsIGJveFNoYWRvdzogMyB9fT5cclxuICAgICAgICAgICAgPENhcmRBY3Rpb25BcmVhPlxyXG4gICAgICAgICAgICAgIDxDYXJkQ29udGVudCBzeD17eyB0ZXh0QWxpZ246IFwiY2VudGVyXCIsIHA6IDQgfX0+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImljb24tY29udGFpbmVyXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxLaXRjaGVuT3V0bGluZWRJY29uXHJcbiAgICAgICAgICAgICAgICAgICAgc3g9e3sgZm9udFNpemU6IDQwLCBjb2xvcjogZ3JlZW5bNjAwXSwgbWI6IDIgfX1cclxuICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPFR5cG9ncmFwaHlcclxuICAgICAgICAgICAgICAgICAgdmFyaWFudD1cImg1XCJcclxuICAgICAgICAgICAgICAgICAgY29tcG9uZW50PVwiaDJcIlxyXG4gICAgICAgICAgICAgICAgICBzeD17eyBtYjogMiwgY29sb3I6IFwiIzMzM1wiLCBmb250V2VpZ2h0OiBcImJvbGRcIiB9fVxyXG4gICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICBNYW5hZ2UgWW91ciBJbnZlbnRvcnlcclxuICAgICAgICAgICAgICAgIDwvVHlwb2dyYXBoeT5cclxuICAgICAgICAgICAgICAgIDxUeXBvZ3JhcGh5XHJcbiAgICAgICAgICAgICAgICAgIHZhcmlhbnQ9XCJib2R5MlwiXHJcbiAgICAgICAgICAgICAgICAgIGNvbG9yPVwidGV4dC5zZWNvbmRhcnlcIlxyXG4gICAgICAgICAgICAgICAgICBzeD17eyBtYjogMyB9fVxyXG4gICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICBLZWVwIHRyYWNrIG9mIHlvdXIgaW5ncmVkaWVudHMgYnkgYWRkaW5nIHRoZW0gbWFudWFsbHkgb3JcclxuICAgICAgICAgICAgICAgICAgc2Nhbm5pbmcgcmVjZWlwdHMgYW5kIGZvb2QgcGhvdG9zLlxyXG4gICAgICAgICAgICAgICAgPC9UeXBvZ3JhcGh5PlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJidXR0b24tY29udGFpbmVyXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxCdXR0b25cclxuICAgICAgICAgICAgICAgICAgICB2YXJpYW50PVwib3V0bGluZWRcIlxyXG4gICAgICAgICAgICAgICAgICAgIGNvbG9yPVwic3VjY2Vzc1wiXHJcbiAgICAgICAgICAgICAgICAgICAgc3g9e3sgY29sb3I6IGdyZWVuWzYwMF0gfX1cclxuICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgIFVwZGF0ZSBJbnZlbnRvcnlcclxuICAgICAgICAgICAgICAgICAgPC9CdXR0b24+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICA8L0NhcmRDb250ZW50PlxyXG4gICAgICAgICAgICA8L0NhcmRBY3Rpb25BcmVhPlxyXG4gICAgICAgICAgPC9DYXJkPlxyXG4gICAgICAgIDwvTGluaz5cclxuICAgICAgPC9kaXY+XHJcbiAgICA8Lz5cclxuICApO1xyXG59XHJcblxyXG5leHBvcnQgZGVmYXVsdCBIb21lO1xyXG4iXSwiZmlsZSI6IkM6L1VzZXJzL3NfbWFyL2NzMzIvU25hY2tTdGFjay9jbGllbnQvc3JjL2NvbXBvbmVudHMvSG9tZS50c3gifQ==